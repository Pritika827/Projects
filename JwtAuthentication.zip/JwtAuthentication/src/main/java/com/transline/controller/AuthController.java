//package com.transline.controller;
//
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.tranline.model.JwtRequest;
//import com.tranline.model.JwtResponse;
//import com.tranline.model.User;
//import com.transline.security.JwtHelper;
//import com.transline.service.UserService;
//import com.transline.service.CustomUserDetailServices;
//
//import ch.qos.logback.classic.Logger;
//
//@RestController
//@RequestMapping("/auth")
//public class AuthController {
//
//	@Autowired
//	private CustomUserDetailServices customUserDetailServices;
//	
//
//	@Autowired
//	private AuthenticationManager authenticationManager;
//
//	@Autowired
//	private JwtHelper jwtHelper;
//	
//	@Autowired
//	private UserService userService;
//
//	@PostMapping("/login")
//	public ResponseEntity<JwtResponse> login(@RequestBody JwtRequest request) {
//		authenticate(request.getEmail(), request.getPassword());
//
//		UserDetails userDetails = customUserDetailServices.loadUserByUsername(request.getUserName());
//		String token = jwtHelper.generateToken(userDetails);
//
//		JwtResponse response = JwtResponse.builder().jwtToken(token).userName(userDetails.getUsername()).build();
//
//		return new ResponseEntity<>(response, HttpStatus.OK);
//	}
//
//	private void authenticate(String userName, String password) {
//		UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userName,
//				password);
//
//		try {
//			authenticationManager.authenticate(authenticationToken);
//		} catch (BadCredentialsException e) {
//			throw new BadCredentialsException("Invalid Username or Password");
//		}
//	}
//
//	@ExceptionHandler(BadCredentialsException.class)
//	public ResponseEntity<String> handleBadCredentials() {
//		return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);
//	}
//	
//	@PostMapping("/create-user")
//	public User createUser(@RequestBody User user) {
//		return userService.createUser(user);
//	}
//
//}
