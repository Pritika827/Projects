

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;

@Entity
@Table(name = "users_table",indexes = {
	@Index(name = "user_email", columnList = "cmpCd, email", unique = true)		
})
@Data
@IdClass(value = UserId.class)
public class User implements UserDetails {

	@Id	
	private String cmpCd;

	@Id
	private String userId;
		
	@ManyToOne
	@JoinColumn(name = "cmpCd",insertable = false,updatable = false)
	private CompanyMst companyMst;
				
	private String offCd;
	
	@Column(nullable = false,unique = true)
	private String userName;
	
	@Column(nullable = false)
	private String email;
	private String password;
	
	private Boolean status;
	
	private String role;

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		SimpleGrantedAuthority authority= new SimpleGrantedAuthority(getRole());
		return List.of(authority);
	}

	@Override
	public String getUsername() {
		return this.email;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}


//	private boolean credentialNonExpired;
}
