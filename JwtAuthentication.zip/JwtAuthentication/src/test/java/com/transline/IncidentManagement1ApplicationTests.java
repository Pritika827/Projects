package com.transline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncidentManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
