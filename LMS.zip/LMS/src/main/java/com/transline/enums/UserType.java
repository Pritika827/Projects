package com.transline.enums;

public enum UserType {
    NORMAL,
    AUTHORIZED
}