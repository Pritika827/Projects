package com.transline.enums;

public enum LockerStatus {
	AVL, // Available -- uallocate
	ASG, // Assigned -- allocate
	UMT, // Under Maintenance
	FREEZE;
}
