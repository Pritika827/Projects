package com.transline.enums;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public enum Modules {

    // Reports
    OPERATION_REPORT(1),
    LOCKER_REQUESTS_REPORT(2),

    // Role Management
    NEW_ROLE(3),
    EDIT_ROLE(4),
    ROLE_LIST(5),

    // Office Management
    NEW_OFFICE(6),
    EDIT_OFFICE(7),
    OFFICE_LIST(8),

    // User Management
    NEW_USER(9),
    EDIT_USER(10),
    USER_LIST(11),

    // Locker Management
    CUSTOMER_ENTRY(12),
    NEW_LOCKER(13),//Admin
    LOCKER_ALLOCATION(14),
    LOCKER_LIST(15),
    ADD_NOMINEE(16),

    // Locker Entry
    LOCKER_ENTRY(17),

    // Locker Operation
    LOCKER_OPERATION(18);

    private final int code;

    Modules(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public static Modules fromCode(int code) {
        for (Modules status : Modules.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid code: " + code);
    }

    // Default Permissions Mapping based on role type
    public static String getDefaultPermissions(String roleType) {
        StringBuilder sb = new StringBuilder();
        for (Modules m : Modules.values()) {
            switch (m) {
                // Role Management
                case NEW_ROLE:
                case EDIT_ROLE:
                    switch (roleType) {
                        case "Admin":
                            sb.append("1");
                            break;
                        default:
                            sb.append("0");
                    }
                    break;

                case ROLE_LIST:
                    sb.append("1");
                    break;

                // Office Management
                case NEW_OFFICE:
                case EDIT_OFFICE:
                    switch (roleType) {
                        case "Admin":
                        case "HO(AU)":
                            sb.append("1");
                            break;
                        default:
                            sb.append("0");
                    }
                    break;

                case OFFICE_LIST:
                    sb.append("1");
                    break;

                // User Management
                case NEW_USER:
                case EDIT_USER:
                    switch (roleType) {
                        case "Admin":
                            sb.append("1");
                            break;
                        default:
                            sb.append("0");
                    }
                    break;

                case USER_LIST:
                    sb.append("1");
                    break;

                // Locker Management
                case CUSTOMER_ENTRY:
                case NEW_LOCKER:
                case LOCKER_ALLOCATION:
                case LOCKER_LIST:
                case ADD_NOMINEE:
                    sb.append("1");
                    break;

                // Locker Entry and Locker Operation
                case LOCKER_ENTRY:
                case LOCKER_OPERATION:
                    sb.append("0");
                    break;

                // Reports
                case OPERATION_REPORT:
                case LOCKER_REQUESTS_REPORT:
                    sb.append("1");
                    break;

                default:
                    sb.append("0");
                    break;
            }
        }
        return sb.toString();
    }
}


//public enum Modules {
//	
//	NEW_OFFICE(1), 
//	MODIFY_OFFICE(2), 
//	OFFICE_LIST(3),
//	
//	NEW_USER(4), 
//	MODIFY_USER(5), 
//	USERS_LIST(6),
//
//	NEW_ROLE(7), 
//	MODIFY_ROLE(8), 
//	ROLE_LIST(9),
//	
//	NEW_LOCKER_TYPE(10),
//	EDIT_LOCKER_TYPE(11),
//	LOCKER_TYPES_LIST(12),
//
//	NEW_CUSTOMER(13), 
//	MODIFY_CUSTOMER(14), 
//	CUSTOMER_LIST(15),
//
//	NEW_LOCKER(16), //Admin
//	MODIFY_LOCKER(17), //admin
//	LOCKER_LIST(18),
//	
//	NEW_NOMINEE(19),
//	MODIFY_NOMINEE(20),
//	NOMINEE_LIST(21),
//	
//	NEW_LOCKER_ALLOCATION(22),
//	MODIFY_LOCKER_ALLOCATION(23),
//	LOCKER_ALLOCATION_LIST(24),
//	
//	VIEW_LOCKER_ACCESS_LOGS(25),
//	
//	NEW_LOCKER_REQUEST(26),
//	MODIFY_LOCKER_REQUEST(27),
//	LOCKER_REQUEST_LIST(28)
//	
//	;
//
//	private final int code;
//	Modules(int code) {
//        this.code = code;
//    }
//    public int getCode() {
//        return code;
//    }
//
//    public static Modules fromCode(int code) {
//        for (Modules status : Modules.values()) {
//            if (status.getCode() == code) {
//                return status;
//            }
//        }
//        throw new IllegalArgumentException("Invalid code: " + code);
//    }
//    
//    public static String getDefaultPermissions(String roleType) {    	
//    	StringBuilder sb=new StringBuilder();
//    	for(Modules m:Modules.values()) {
//    		switch(m) {
//	    		case NEW_ROLE:
//	    		case MODIFY_ROLE:
//	    		case NEW_OFFICE:
//	    		case MODIFY_OFFICE:
//	    		case NEW_USER:
//	    		case MODIFY_USER:	    		
//	    			switch(roleType) {
//	    				case "HO(AU)":
//	    					sb.append("1");
//	    					break;
//	    				default:	
//	    					sb.append("0");
//	    			}
//	    			break;
//	    		
//	    		case ROLE_LIST:
//	    		case USERS_LIST:	    				    			
//	    		case OFFICE_LIST:
//	    		case NEW_CUSTOMER:
//	    		case MODIFY_CUSTOMER:	    				    			
//	    		case CUSTOMER_LIST:	
//	    		case NEW_LOCKER:	
//	    		case MODIFY_LOCKER:	
//	    		case LOCKER_LIST:	
//	    		case NEW_NOMINEE:	                
//	            case MODIFY_NOMINEE:
//	            case NOMINEE_LIST:
//	            case NEW_LOCKER_ALLOCATION:
//	            case MODIFY_LOCKER_ALLOCATION:
//	            case LOCKER_ALLOCATION_LIST:
//	            case VIEW_LOCKER_ACCESS_LOGS:
//	            case NEW_LOCKER_REQUEST:
//	            case MODIFY_LOCKER_REQUEST:
//	            case LOCKER_REQUEST_LIST:
//	    				sb.append("1");
//	    			break;
//	    		default:	    		
//					sb.append("0");
//	    			break;
//    		}
//    	} 
//    	return sb.toString();
//    }       
//}
//
