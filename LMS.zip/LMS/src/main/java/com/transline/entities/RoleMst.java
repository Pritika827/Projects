package com.transline.entities;

import org.hibernate.envers.Audited;
import com.transline.audit.Auditable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(
		uniqueConstraints = {
	    @UniqueConstraint(columnNames = {"cmp_cd", "role_type"}),
	    @UniqueConstraint(columnNames = {"cmp_cd", "role_desc"})
		}
	)
@Data
@EqualsAndHashCode(callSuper = true)
@Audited
public class RoleMst extends Auditable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false,length = 10)
	private String cmpCd;
	
	@Column(nullable = false)
	private String roleType;
	
	@Column(nullable = false)
	private String roleDesc;
	
	@Column(nullable = false)
	private String accessRights;  
}