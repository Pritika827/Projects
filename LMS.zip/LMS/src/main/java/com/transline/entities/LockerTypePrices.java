package com.transline.entities;

import java.time.LocalDateTime;
import org.hibernate.envers.Audited;
import com.transline.audit.Auditable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Audited
public class LockerTypePrices extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String cmpCd;

	@Column(nullable = false)
	private LocalDateTime startDate;
	
	private LocalDateTime endDate;

	@ManyToOne
	@JoinColumn(name = "lockerTypeId", referencedColumnName = "id")
	private LockerType lockerType;

	@Column(nullable = false)
	private String rentForUrban;

	@Column(nullable = false)
	private String rentForRural;

	@Column(nullable = false)
	private String regFee;

}
