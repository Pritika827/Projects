package com.transline.entities;

import java.time.LocalDateTime;

import org.hibernate.envers.Audited;

import com.transline.audit.Auditable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(
	uniqueConstraints = {
    @UniqueConstraint(columnNames = {"cmp_cd", "module_id"}),
    @UniqueConstraint(columnNames = {"cmp_cd", "module_name"})
	}
)
@Data
@EqualsAndHashCode(callSuper = true)
@Audited
public class ModuleMst extends Auditable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String cmpCd;
	
	@Column(nullable = false)
	private int moduleId;
	
	@Column(nullable = false)
	private String moduleName;
	
	@Column(nullable = false)
	private String status;
	
	@Column(nullable = false)
	private int parentId;
}
