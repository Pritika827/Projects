package com.transline.entities;


import java.time.LocalDateTime;

import org.hibernate.envers.Audited;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@EntityListeners(AuditingEntityListener.class)
@Audited
public class Company {
		
	@Id
	@Column(length = 10)
	private String cmpCd;

	@Column(nullable = false)
	private String cmpName;	
	
	@Column(nullable = false)
	private String cmpAdd;
	
	@Column(nullable = false)
	private String city;
	
	@Column(nullable = false)
	private String state;
	
	private String website;

	@Column(length = 255) 
	private String cmpLogo;

	@Column(nullable = false)
	private String email;
	
	@Column(nullable = false)
	private String phn1;
	
	private String phn2;
	
	private String status;
	
	private String faxNo;
	
	@Column(nullable = false)
	private String autoGenEmpId;

	@Column(nullable = false)
	private String oorn;//Owner Or Normal
		
	@Column(nullable = false)
	@CreatedDate
	private LocalDateTime createdAt;
	
	@Column(nullable = false)
	@CreatedBy
	private String createdBy;
	
//	@PrePersist
//	public void onPrePersist() {
//		this.createdAt=LocalDateTime.now();
//	}
				
}
