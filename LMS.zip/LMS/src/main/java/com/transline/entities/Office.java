package com.transline.entities;

import java.util.List;

import org.hibernate.annotations.JoinFormula;
import org.hibernate.envers.Audited;

import com.transline.audit.Auditable;
import com.transline.entities.ids.OfficeId;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(
		uniqueConstraints = {	    
		@UniqueConstraint(columnNames = {"cmp_cd", "off_cd"}),
	    @UniqueConstraint(columnNames = {"cmp_cd", "off_name"})
		}
	)
@Audited
public class Office extends Auditable{	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
		
	@Column(nullable=false,length = 10)
	private String cmpCd;
			
	@Column(nullable=false,length = 10)
	private String offCd;

	@Column(nullable = false,length = 100)
	private String offName;
									
	@Column(nullable = false)
	private String offAddress;
	
	@ManyToOne
	@JoinColumn(nullable = false)
	private OfficeType officeType;

	@Column(nullable = false,length = 10)
	private String ctlCd;
	
	private String email;

	private String phoneNo;

	private String contactPerson;

	private String disable;

	@Column(nullable = false)
	private String workingStatus; //RWO, WO,RO
	
	@Column(nullable=false)
	private String path;	
}
