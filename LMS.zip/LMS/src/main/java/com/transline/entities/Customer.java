package com.transline.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import java.util.List;
import java.util.Set;
import org.hibernate.envers.Audited;
import org.hibernate.validator.internal.util.logging.LoggerFactory;
import com.transline.EncryptionUtil;
import com.transline.audit.Auditable;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.Email;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Audited
@Table(
		name = "Customer",
		uniqueConstraints = {		
	    @UniqueConstraint(columnNames = {"cmp_cd", "pan_no"}),
	    @UniqueConstraint(columnNames = {"cmp_cd", "adhar_no"})
		}
	)
public class Customer extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private String cmpCd;

	@Column(nullable = false)
	private String offCd;

	@Column(nullable = false)
	private String fullName;

	@Column(nullable = false)
	private String fatherName;

	@Column(nullable = false)
	private String gender;

	@Column(nullable = false)
	private String maritalStatus;
	
	@Column(nullable = false)
	private String currentAddress;
	
	@Column(nullable = false)
	private String permanentAddress;

	@Column(nullable = false)
	private String panNo;

	@Column(nullable = false)
	private String adharNo;

	@Column(nullable = false)
	private String contactNo;

	@Column(nullable = false)
	private String emailId;
	
	@Transient
	private String panNo1;

	@Transient
	private String adharNo1;

	@Transient
	private String contactNo1;

	@Transient
	private String emailId1;

	@Column(name = "ac_no")
	private String accountNo;
	
//	private String allocatedLockerNo;
	
	@PreUpdate
	@PrePersist
	 public void encryptSensitiveData() {
		try {
			this.panNo = EncryptionUtil.encrypt2(this.panNo1);
			this.adharNo = EncryptionUtil.encrypt2(this.adharNo1);
			this.contactNo = EncryptionUtil.encrypt2(this.contactNo1);
			this.emailId = EncryptionUtil.encrypt2(this.emailId1);
		} catch (Exception e) {
			System.out.println("Error encrypting sensitive data");
			throw new RuntimeException("Failed to encrypt sensitive data", e);
		}
	}
	
	@PostLoad
	public void decryptSensitiveData() {
		try {
			if (this.panNo != null && !this.panNo.isEmpty()) {
				this.panNo1 = EncryptionUtil.decrypt2(this.panNo);
				System.out.println("Decrypted PAN: " + this.panNo); 
			}
			if (this.adharNo != null && !this.adharNo.isEmpty()) {
				this.adharNo1 = EncryptionUtil.decrypt2(this.adharNo);
			}
			if (this.contactNo != null && !this.contactNo.isEmpty()) {
				this.contactNo1 = EncryptionUtil.decrypt2(this.contactNo);
			}
			if (this.emailId != null && !this.emailId.isEmpty()) {
				this.emailId1 = EncryptionUtil.decrypt2(this.emailId);
			}
		} catch (Exception e) {
			System.out.println("Error decrypting sensitive data");
			throw new RuntimeException("Failed to decrypt sensitive data", e);
		}
	}
		
	public void setPanNo(String panNo) {
		this.panNo1 = panNo;
	}

	public void setAdharNo(String adharNo) {
		this.adharNo1 = adharNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo1 = contactNo;
	}

	public void setEmailId(String emailId) {
		this.emailId1 = emailId;
	}

	public String getPanNo() {
		return this.panNo1;
	}

	public String getAdharNo() {
		return this.adharNo1;
	}

	public String getContactNo() {
		return this.contactNo1;
	}

	public String getEmailId() {
		return this.emailId1;
	}

}
