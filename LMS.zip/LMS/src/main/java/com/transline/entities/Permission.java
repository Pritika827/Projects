package com.transline.entities;

import org.hibernate.envers.Audited;

import com.transline.audit.Auditable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Audited
public class Permission extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String cmpCd;
	@Column(nullable = true)
	private String name;
	@Column(nullable = true)
	private String parentRef;
	@Column(nullable = true)
	private String headingLevel; // Heading,Sub-Heading,Leaf
}
