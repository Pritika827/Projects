package com.transline.entities;

import java.time.LocalDateTime;

import org.hibernate.envers.Audited;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
@Audited
public class LoginSession {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(length = 10,nullable = false)
	private String cmpCd;
//	@Column(length = 10,nullable = false)
	private String offCd;
	@Column(length = 20, nullable = false)
	private String userId;
	@Column(length = 20, nullable = false)
	private String ipAddress;
	@Column(nullable = false)
	private LocalDateTime loginTime;

}
