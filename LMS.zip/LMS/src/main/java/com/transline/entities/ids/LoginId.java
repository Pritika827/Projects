package com.transline.entities.ids;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginId implements Serializable{
	private String cmpCd;
	private String userName;	
}
