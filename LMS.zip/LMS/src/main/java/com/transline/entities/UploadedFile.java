	package com.transline.entities;
	
	import java.time.LocalDateTime;
	
	import org.hibernate.envers.Audited;
	import org.springframework.data.annotation.CreatedBy;
	import org.springframework.data.annotation.CreatedDate;
	import org.springframework.data.jpa.domain.support.AuditingEntityListener;
	
	import jakarta.persistence.Column;
	import jakarta.persistence.Entity;
	import jakarta.persistence.EntityListeners;
	import jakarta.persistence.GeneratedValue;
	import jakarta.persistence.GenerationType;
	import jakarta.persistence.Id;
	import jakarta.persistence.MappedSuperclass;
	import jakarta.persistence.PrePersist;
	import jakarta.persistence.Table;
	import jakarta.persistence.UniqueConstraint;
	import lombok.Data;
	
	@Entity
	@Table(
			uniqueConstraints = {
		    @UniqueConstraint(columnNames = {"cmp_cd","ref_id", "file_type","file_name"})	    
			}
		)
	@Data
	@Audited
	public class UploadedFile{
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id;
		
		@Column(nullable = false,length = 10)
		private String cmpCd;		
		
		@Column(length=10,nullable = false)
		private String refId;	//like customerId
		
		@Column(length=20,nullable = false)
		private String refType; // e.g., "Customer", "Order", "Employee", etc.
		
		@Column(nullable = false)
		private String fileType;
		
		@Column(length=100,nullable = false)
		private String fileName;	
		
		@Column(length=100,nullable = false)
		private String filePath;
				
		private String fileDescription;
		
		private Long fileSize;
	
		@CreatedBy
		@Column(nullable = false)
		private String createdBy;
		
		@CreatedDate
		@Column(nullable = false)
		private LocalDateTime createdAt;
		
	}