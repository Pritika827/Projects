package com.transline.entities;

import java.time.LocalDateTime;

import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.transline.audit.Auditable;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Audited
public class LockerReq extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String cmpCd;
    private String offCd;
    private String fullName;
    private String emailId;
    private String contactNo;

    @ManyToOne
    @JoinColumn 
    private LockerType lockerType;

    private String currentAdd;
    
    @JsonFormat(pattern = "yyyy-mm-dd'T'hh:mm:ss")
    private LocalDateTime reqDate;
}

