package com.transline.entities;

import java.util.List;

import org.hibernate.annotations.JoinFormula;
import org.hibernate.envers.Audited;

import com.transline.audit.Auditable;
import com.transline.entities.ids.OffTypeId;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(
		uniqueConstraints = {	    
			@UniqueConstraint(columnNames = {"cmp_cd", "off_desc"}),
			@UniqueConstraint(columnNames = {"cmp_cd","off_type"}),
			@UniqueConstraint(columnNames = {"cmp_cd","off_level"})
		}
	)
@Data
@EqualsAndHashCode(callSuper = true)
@Audited
public class OfficeType extends Auditable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;		
		
	@Column(nullable = false,length = 10)
	private String cmpCd;
	
	@Column(nullable=false,length = 2)
	private String offType;
	
	@Column(nullable = false)
	private String offDesc;
		
	@Column(nullable = false)
	private Integer offLevel;	
}
