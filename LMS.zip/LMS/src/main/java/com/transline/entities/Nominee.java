package com.transline.entities;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(
	    uniqueConstraints = {	    	
    		//@UniqueConstraint(columnNames ={"cmp_cd","voterId"} ),
    		@UniqueConstraint(columnNames ={"cmp_cd","adharNo"} )
	    }
	)
public class Nominee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String cmpCd;

	private Long lockerId;
	
	@ManyToOne
	private Customer customer;

	private String nomineeName;

	private String relationship;

	private LocalDateTime dob;

	private String phoneNo;

	private String address;

//	private String voterId;

//	@Column(unique = true)
	private String adharNo;

	private LocalDateTime addedDate = LocalDateTime.now();

	private LocalDateTime updatedDate;

}