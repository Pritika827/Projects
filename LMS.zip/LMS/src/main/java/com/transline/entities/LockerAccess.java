package com.transline.entities;

import java.time.LocalDateTime;
import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.transline.audit.Auditable;
import com.transline.utils.CustomLocalDateTimeDeserializer;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Audited
public class LockerAccess extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String cmpCd;

	@ManyToOne
	@JsonBackReference
	private Locker locker;

	@ManyToOne
	@JsonBackReference
	private Customer customer;

	@JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
	@JsonFormat(pattern = "yyyy-mm-dd'T'hh:mm:ss")
	private LocalDateTime accessTimeIn;

	@JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
	@JsonFormat(pattern = "yyyy-mm-dd'T'hh:mm:ss")
	private LocalDateTime accessTimeOut;

}
