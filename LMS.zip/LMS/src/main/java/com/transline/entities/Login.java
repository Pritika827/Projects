package com.transline.entities;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.transline.audit.Auditable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import com.transline.entities.Office;

@Entity
@Table(
		uniqueConstraints = {		
	    @UniqueConstraint(columnNames = {"cmp_cd", "user_name"}),
	    @UniqueConstraint(columnNames = {"cmp_cd", "email"}),
	    @UniqueConstraint(columnNames = {"cmp_cd", "mobile_no"})
		}
	)
@Data
@Audited
public class Login extends Auditable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	
			
	@Column(nullable=false,length = 10)
	private String cmpCd;
		
	@Column(nullable=false,length = 20)
	private String userName;			//userName=userId
	
	@Column(nullable = false,length = 50)
	private String name;				//name=userName

	@Column(nullable = false)
	private String pwd;

	@Column(nullable = false)
	private String status;
		
	@ManyToOne(fetch = FetchType.EAGER)
	private Office office;
	
	@Column(nullable = false)
	private boolean disabled;
	
	private boolean blocked;
	
	private boolean expired;
	
	private boolean credentialExpired;
	
	private String userType;//N->Normal, A-> Authorised, W-> WebService User
	
//	private boolean defaultUser;
	
	@ManyToOne	
	private RoleMst roleMst;
	
//	@Pattern(regexp = "^(A|M|E)$", message = "Invalid CRM user type. Must be 'admin', 'manager', or 'executive'.")
//    private String CRMuserType;
	
	private String accessRights;
	
	private String email;
	
	private String mobileNo;
	
	private String custodianName;	
	
    private LocalDateTime passwordUpdatedDate; 
	
}
