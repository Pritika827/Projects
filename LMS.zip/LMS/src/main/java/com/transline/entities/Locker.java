package com.transline.entities;

import org.json.JSONObject;
import java.time.LocalDateTime;

import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.transline.audit.Auditable;
import com.transline.dtos.LockerDTO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.transline.entities.LockerType;
import com.transline.enums.LockerStatus;;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Audited
@Entity
@Table(
	    uniqueConstraints = {	    	
    		@UniqueConstraint(columnNames ={"cmp_cd","off_cd","locker_no"} ),
    		@UniqueConstraint(columnNames ={"cmp_cd","off_cd","location"} )
	    }
	)
public class Locker extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false,length = 10)
	private String cmpCd;
	
	@Column(nullable = false,length = 10)
	private String offCd;

	@Column(nullable = false)
	private String lockerNo;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private LockerType lockerType;
	
	@Column(nullable = false)
	private String location;
	
	@Column(nullable = false)
	@Enumerated(EnumType.STRING)
	private LockerStatus status; //AVL(Available) ASG(Assigned), UMT(Under Maintenance), FREEZE
	
	
	private LocalDateTime freezeDate;

	private String remarks;
	
//	@Column(columnDefinition = "TEXT")
//	private String remarks;
//
//	public JSONObject getRemarksJson() {
//		if (remarks != null) {
//			return new JSONObject(remarks);
//		}
//		return new JSONObject();
//	}
//
//	public void setRemarksJson(JSONObject remarksJson) {
//		this.remarks = remarksJson.toString();
//	}
}
