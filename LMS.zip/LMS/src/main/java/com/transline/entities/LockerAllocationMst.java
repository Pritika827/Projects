package com.transline.entities;

import jakarta.mail.Multipart;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.Set;

import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.transline.audit.Auditable;
import com.transline.enums.LockerStatus;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Audited
@Table(
		name = "LockerAllocationMst"
	  )
public class LockerAllocationMst extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private String cmpCd;

	private String offCd;

	@Column(nullable = false)
	private LocalDateTime allocatedAt;

	private LocalDateTime releasedAt;

	@Column(nullable = false)
	private String accessKey;

	private LocalDateTime expiringDate;
	
	//private String status;
	
	@Column(nullable = false)
	@Enumerated(EnumType.STRING)
	private LockerStatus status; //AVL(Available) ASG(Assigned), UMT(Under Maintenance), FREEZE
	
	@ManyToOne
	private Locker locker;
	
	@ManyToOne
	@JoinColumn(name = "customer_id",referencedColumnName = "id",insertable = false,updatable = false)
	private Customer customer;
	
	@Column(name = "customer_id",nullable = false)
	private Long customerId;
	
	private String secondaryCustomers;//[1232][9787][8675]
	
	private LocalDateTime startDate;

	private String billingCycle;

	private String rentAmt;
	
//	private LocalDateTime freezeDate;
//
//	private String remarks;

	
	//locker No, billing cycle(monthly,quatery,yearly), rent starting date, 
		//ac no ac type, doc , custodian Id, rules opratable by(one/two/any)
		
	
}
