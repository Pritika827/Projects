package com.transline;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.transline.dtos.NewCompanyDTO;
import com.transline.dtos.NewOfficeDTO;
import com.transline.dtos.OfficeDto;
import com.transline.entities.Company;
import com.transline.entities.Login;
import com.transline.entities.Office;
import com.transline.security.User;
import com.transline.servicesImp.CompanyService;

@EnableScheduling
@SpringBootApplication(scanBasePackages = "com.transline")
public class LockerManagementSystem implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(LockerManagementSystem.class, args);
		System.out.println("Application is running on port no. 8081..............");
	}

	@Autowired
	private CompanyService companyService;

	@Override
	public void run(String... args) throws Exception {				
		Login login = new Login();
        login.setCmpCd("TTPLS");
        login.setUserName("Pritika");
        login.setPwd("pritika123");
        login.setExpired(false);
        login.setBlocked(false);
        login.setCredentialExpired(false);
        login.setDisabled(false);
        		
		if (!companyService.isAlreadyExists("TTPLS")) {
			NewCompanyDTO companyDto = new NewCompanyDTO();
			companyDto.setCmpCd("TTPLS");
			companyDto.setCmpName("TTL");
			companyDto.setCmpAdd("123 Moti nagar, Delhi");
			companyDto.setCity("Delhi");
			companyDto.setState("Delhi");
			companyDto.setEmail("contactUs@ttl.com");
			companyDto.setPhn1("985623091");
			companyDto.setPhn2("985623092");
			companyDto.setFaxNo("456389");
			companyDto.setWebsite("www.ttl.com");

			NewOfficeDTO officeInfo = new NewOfficeDTO();
			officeInfo.setOffName("TTL Head Office");
			officeInfo.setOffAddress("123 Moti nagar, Delhi");
			officeInfo.setPhoneNo("985623091");
			officeInfo.setEmail("headoffice@ttl.com");
			officeInfo.setContactPerson("Mr.Gupta");
			officeInfo.setAuPassword("w^lc0me123");
			companyDto.setOffice_info(officeInfo);

			Map<String, String> result = companyService.insertCompany(companyDto);

			if (result.containsKey("Message")) {
				System.out.println(result.get("Message"));
			} else {
				System.out.println("Company Created: " + companyDto.getCmpName());
				System.out.println("Default Users:");
				result.forEach((key, value) -> System.out.println(key + ": " + value));
			}
		}

	}
}
