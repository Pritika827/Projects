package com.transline.utils;

public interface GenConstants {
	String SESSION_CURRENT_USER = "currentUser";
}
