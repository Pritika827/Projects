package com.transline.utils;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PasswordGenerator {

	private static final String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final String LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
	private static final String DIGITS = "0123456789";
	// private static final String SPECIAL_CHARACTERS = "!@#$%^&*()-_=+<>?";
	private static final String SPECIAL_CHARACTERS = "@#$^_";

	private static final SecureRandom random = new SecureRandom();

	public static String generatePassword() {
		int length = random.nextInt(8, 16); 
		StringBuilder password = new StringBuilder(length);
		password.append(getRandomCharacter(UPPERCASE)).append(getRandomCharacter(LOWERCASE))
				.append(getRandomCharacter(DIGITS)).append(getRandomCharacter(SPECIAL_CHARACTERS));
		String allCharacters = UPPERCASE + LOWERCASE + DIGITS + SPECIAL_CHARACTERS;
		for (int i = 4; i < length; i++) {
			password.append(getRandomCharacter(allCharacters));
		}
		List<Character> passwordChars = new ArrayList<>();
		for (char c : password.toString().toCharArray()) {
			passwordChars.add(c);
		}
		Collections.shuffle(passwordChars);
		StringBuilder finalPassword = new StringBuilder();
		for (char c : passwordChars) {
			finalPassword.append(c);
		}
		return finalPassword.toString();
	}

	private static char getRandomCharacter(String characters) {
		int index = random.nextInt(characters.length());
		return characters.charAt(index);
	}

}
