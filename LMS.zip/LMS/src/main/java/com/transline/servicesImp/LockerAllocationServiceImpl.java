package com.transline.servicesImp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.security.SecureRandom;
import java.time.LocalDateTime;

import com.transline.AuthUtils;
import com.transline.EncryptionUtil;
import com.transline.dtos.CustomerDTO;
import com.transline.dtos.CustomerNamesDTO;
import com.transline.dtos.LockerAllocationMstDTO;
import com.transline.dtos.LockerDTO;
import com.transline.dtos.NewFileDTO;
import com.transline.entities.Customer;
import com.transline.entities.Locker;
import com.transline.entities.LockerAllocationMst;
import com.transline.entities.LockerType;
import com.transline.enums.LockerStatus;
import com.transline.exceptions.DataNotSave;
import com.transline.exceptions.LockerAlreadyAllocatedException;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.CustomerRepository;
import com.transline.repositories.LockerAllocationRepository;
import com.transline.repositories.LockerRepository;
import com.transline.repositories.LoginRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;

@Service
public class LockerAllocationServiceImpl {

	private static final Logger logger = LoggerFactory.getLogger(LockerAllocationServiceImpl.class);

	@Autowired
	private LockerAllocationRepository allocationRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private LockerRepository lockerRepository;

	@Autowired
	private EmailService emailService;

	@Autowired
	private LockerAllocationRepository lockerAllocationMstRepository;

	@Autowired
	private UploadedFileServiceImpl uploadedFileService;

	@Autowired
	EntityManager entityManager;

	// ----------------------------------Model Mapper------------------------

	private LockerAllocationMst dtoToAllocation(LockerAllocationMstDTO dto) {
		LockerAllocationMst allocationMst = this.modelMapper.map(dto, LockerAllocationMst.class);
		return allocationMst;
	}

	private LockerAllocationMstDTO allocationToDto(LockerAllocationMst allocationMst) {
		LockerAllocationMstDTO dto = new LockerAllocationMstDTO();
		dto.setId(allocationMst.getId());
		dto.setCmpCd(allocationMst.getCmpCd());
		dto.setOffCd(allocationMst.getOffCd());
		dto.setAllocatedAt(allocationMst.getAllocatedAt());
		dto.setReleasedAt(allocationMst.getReleasedAt());
		dto.setExpiringDate(allocationMst.getExpiringDate());
		dto.setStatus(allocationMst.getStatus());
		dto.setCustId(allocationMst.getCustomerId());
		dto.setLockerId(allocationMst.getLocker().getId());
		dto.setSecondaryCustomers(allocationMst.getSecondaryCustomers());
		dto.setStartDate(allocationMst.getStartDate());
		dto.setBillingCycle(allocationMst.getBillingCycle());
		dto.setRentAmt(allocationMst.getRentAmt());
//		dto.setAccessKey(allocationMst.getAccessKey());
//		dto.setFreezeDate(allocationMst.getFreezeDate());
//		dto.setRemarks(allocationMst.getRemarks());

		// String customerName = allocationMst.getCustomer().getFullName();
		Long lockerId = allocationMst.getLocker().getId();
		return dto;
	}

// -------------------------------------------------------------------------------------

	public static String generateAccessKey() {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		Random random = new Random();
		StringBuilder accessKey = new StringBuilder();
		int[] charCount = new int[characters.length()];

		while (accessKey.length() < 6) {
			int index = random.nextInt(characters.length());
			if (charCount[index] < 2) {
				accessKey.append(characters.charAt(index));
				charCount[index]++;
			}
		}
		return accessKey.toString();
	}

//	public LockerAllocationMstDTO createLockerAllocation(LockerAllocationMstDTO dto, String cmp) {
//		Customer customer = customerRepository.findById(dto.getCustId())
//				.orElseThrow(() -> new ResourceNotFoundException("Customer not found", "id", dto.getCustId()));
//		Locker locker = lockerRepository.findById(dto.getLockerId())
//				.orElseThrow(() -> new ResourceNotFoundException("Locker not found", "id", dto.getLockerId()));
//		LockerAllocationMst allocationMst = this.dtoToAllocation(dto);
//		allocationMst.setCustomer(customer);
//		allocationMst.setLocker(locker);
//		
//		String accessKey = generateAccessKey();
//	    allocationMst.setAccessKey(accessKey);
//
//		LockerAllocationMst savedAllocation = allocationRepository.save(allocationMst);
//		logger.info("Locker allocation saved with ID: {}", savedAllocation.getId());
//
//		LockerAllocationMstDTO savedDto = this.allocationToDto(savedAllocation);
//		logger.info("Locker allocation successfully created. Access Key: {}", savedDto.getAccessKey());
//
//		return savedDto;
//	}

	public LockerAllocationMstDTO createLockerAllocation(LockerAllocationMstDTO dto, String cmp) {
		Customer customer = customerRepository.findById(dto.getCustId())
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found", "id", dto.getCustId()));
		Locker locker = lockerRepository.findById(dto.getLockerId())
				.orElseThrow(() -> new ResourceNotFoundException("Locker not found", "id", dto.getLockerId()));

		if (locker.getStatus() == LockerStatus.ASG) {
			throw new LockerAlreadyAllocatedException("Locker is already allocated");
		}
//		   if (locker.getStatus() == LockerStatus.FREEZE) {
//		        if (dto.getRemarks() == null || dto.getRemarks().trim().isEmpty()) {
//		            throw new IllegalArgumentException("Remarks are required when locker status is 'FREEZE'.");
//		        }
//		        if (dto.getFreezeDate() == null) {
//		            throw new IllegalArgumentException("Freeze date is required when locker status is 'FREEZE'.");
//		        }
//		    }

		LockerAllocationMst allocationMst = this.dtoToAllocation(dto);
		allocationMst.setCustomerId(dto.getCustId());
		allocationMst.setLocker(locker);
		allocationMst.setAllocatedAt(LocalDateTime.now());
		allocationMst.setStatus(LockerStatus.ASG);
		String accessKey;
		do {
			accessKey = generateAccessKey();
		} while (allocationRepository.existsByAccessKey(accessKey));
		allocationMst.setAccessKey(accessKey);

		double baseRent = 1000.0;
		double calculatedRent = baseRent;
		String billingCycle = dto.getBillingCycle();

		switch (billingCycle.toLowerCase()) {
		case "monthly":
			calculatedRent = baseRent / 12;
			break;
		case "quarterly":
			calculatedRent = baseRent / 4;
			break;
		case "half yearly":
			calculatedRent = baseRent / 6;
			break;
		case "yearly":
			calculatedRent = baseRent;
			break;
		default:
			throw new IllegalArgumentException("Invalid billing cycle: " + billingCycle);
		}
		allocationMst.setRentAmt(String.valueOf(calculatedRent));

		LockerAllocationMst savedAllocation = allocationRepository.save(allocationMst);
		String savedAccessKey = savedAllocation.getAccessKey();
		String emailSubject = "Your Locker Access Key";
		String emailMessage = "Dear " + customer.getFullName() + ",\n\n" + "Your locker access key is: "
				+ savedAccessKey + "\n\n" + "Thank you for using our service.";
		emailService.sendEmail(customer.getEmailId(), emailSubject, emailMessage);

		locker.setStatus(LockerStatus.ASG);
		lockerRepository.save(locker);

//		    customer.setAllocatedLockerNo(allocationMst.getLocker().getLockerNo());
//		    customerRepository.save(customer);

		List<NewFileDTO> files = new ArrayList<>();
//		    if (dto.getAgreementDoc() != null) {
//		        files.add(new NewFileDTO("agreementDoc", dto.getAgreementDoc()));
//		    }

		try {
			int savedFileCount = this.uploadedFileService.saveFiles(cmp, String.valueOf(savedAllocation.getId()),
					"LockerAllocation", files);
			if (savedFileCount != files.size()) {
				throw new DataNotSave("Error while saving Agreement document file");
			}
		} catch (Exception e) {
			logger.error("Failed to save Agreement document: " + e.getMessage());
		}

		LockerAllocationMstDTO savedDto = this.allocationToDto(savedAllocation);
		return savedDto;
	}

	public List<LockerAllocationMstDTO> getAllLockerAllocation() {
		List<LockerAllocationMst> allocationMst = this.allocationRepository.findAll();
		List<LockerAllocationMstDTO> allocationMstDTO = allocationMst.stream()
				.map(allocations -> this.allocationToDto(allocations)).collect(Collectors.toList());
		return allocationMstDTO;
	}

	public LockerAllocationMstDTO getLockerAllocationById(Long id) {
		LockerAllocationMst allocationMst = this.allocationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker allocation", "id", id));
		return this.allocationToDto(allocationMst);
	}

	public LockerAllocationMstDTO updateLockerAllocation(LockerAllocationMstDTO dto, Long id) {
		LockerAllocationMst allocationMst = allocationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker allocation", "id", id));
		allocationMst.setOffCd(dto.getOffCd());
		allocationMst.setAllocatedAt(dto.getAllocatedAt());
		allocationMst.setReleasedAt(dto.getReleasedAt());
		// allocationMst.setAccessKey(dto.getAccessKey());
		allocationMst.setExpiringDate(dto.getExpiringDate());
		allocationMst.setStatus(dto.getStatus());
//		allocationMst.setRemarks(dto.getRemarks());
//		allocationMst.setFreezeDate(dto.getFreezeDate());
		Customer customer = customerRepository.findById(dto.getCustId())
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found", "id", dto.getCustId()));

		Locker locker = lockerRepository.findById(dto.getLockerId())
				.orElseThrow(() -> new ResourceNotFoundException("Locker not found ", "id", dto.getLockerId()));

		allocationMst.setCustomer(customer);
		allocationMst.setLocker(locker);
		allocationMst = allocationRepository.save(allocationMst);
		return this.allocationToDto(allocationMst);
	}

	public void deleteLockerAllocation(Long id) {
		LockerAllocationMst allocationMst = this.allocationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker allocation", "id", id));

		Locker locker = allocationMst.getLocker();
		if (locker != null) {
			locker.setStatus(LockerStatus.AVL);
			lockerRepository.save(locker);
		}
		this.allocationRepository.delete(allocationMst);
	}

	public Map<String, String> getLockerDetailsByAccessKey(String accessKey) {
		List<Object[]> results = lockerAllocationMstRepository.findLockerDetailsByAccessKey(accessKey);
		if (!results.isEmpty()) {
			Object[] data = results.get(0);
			Map<String, String> lockerDetails = new HashMap<>();
			lockerDetails.put("lockerNo", (String) data[0]);
			lockerDetails.put("officeCode", (String) data[1]);
			lockerDetails.put("officeName", (String) data[2]);
			return lockerDetails;
		}
		throw new EntityNotFoundException("Locker details not found for accessKey: " + accessKey);
	}

	public List<CustomerNamesDTO> getCustomersByLocker(String cmpCd, Long lockerId) {
		return lockerAllocationMstRepository.getCustomersByLockerId(cmpCd, lockerId);
	}

}
