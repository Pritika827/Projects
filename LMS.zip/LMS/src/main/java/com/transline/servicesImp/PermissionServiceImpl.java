package com.transline.servicesImp;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.dtos.LockerAccessDTO;
import com.transline.dtos.PermissionDTO;
import com.transline.entities.Customer;
import com.transline.entities.Locker;
import com.transline.entities.LockerAccess;
import com.transline.entities.Permission;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.PermissionRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PermissionServiceImpl {

	@Autowired
	private PermissionRepository permissionRepository;

	@Autowired
	private ModelMapper modelMapper;

	private Permission dtoToPermission(PermissionDTO dto) {
		Permission permission = this.modelMapper.map(dto, Permission.class);
		return permission;
	}

	private PermissionDTO permissionToDto(Permission permission) {
		PermissionDTO dto = this.modelMapper.map(permission, PermissionDTO.class);
		return dto;
	}

	public PermissionDTO createPermission(PermissionDTO permissionDTO) {
		Permission permission = dtoToPermission(permissionDTO);
		System.out.println("Converted Permission Entity: " + permission);
		Permission savedPermission = permissionRepository.save(permission);
		permission.setName(permissionDTO.getName());
		permission.setParentRef(permissionDTO.getParentRef());
		permission.setHeadingLevel(permissionDTO.getHeadingLevel());
		System.out.println("Saved Permission Entity: " + savedPermission);

		return permissionToDto(savedPermission);
	}

	public List<PermissionDTO> getAllPermissions() {
		List<Permission> permission = this.permissionRepository.findAll();
		List<PermissionDTO> dto = permission.stream().map(p -> this.permissionToDto(p)).collect(Collectors.toList());
		return dto;
	}

	public PermissionDTO getPermissionById(Long id) {
		Permission permission = this.permissionRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Permission", "id", id));
		return this.permissionToDto(permission);
	}

	public PermissionDTO updatePermission(Long id, PermissionDTO dto) {
		Permission permission = permissionRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Permission", "id", id));
		permission.setName(dto.getName());
		permission.setParentRef(dto.getParentRef());
		permission.setHeadingLevel(dto.getHeadingLevel());
		permission = permissionRepository.save(permission);
		return permissionToDto(permission);
	}

	public void deletePermission(Long id) {
		Permission permission = this.permissionRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Permission", "id", id));
		this.permissionRepository.delete(permission);
	}

}
