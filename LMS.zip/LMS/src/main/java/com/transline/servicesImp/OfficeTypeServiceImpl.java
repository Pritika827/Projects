package com.transline.servicesImp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.transline.AuthUtils;
import com.transline.controllers.AdminController;
import com.transline.dtos.GetLockerId;
import com.transline.dtos.NewOfficeTypeDTO;
import com.transline.dtos.OffTypeDetailsDTO;
import com.transline.dtos.OfficeDto;
import com.transline.dtos.OfficeTypeDTO;
import com.transline.dtos.OfficeTypeDetailDTO;
import com.transline.entities.Company;
import com.transline.entities.Login;
import com.transline.entities.Office;
import com.transline.entities.OfficeType;
import com.transline.entities.RoleMst;
import com.transline.entities.ids.OffTypeId;
import com.transline.enums.Modules;
import com.transline.exceptions.DuplicateEntryException;
import com.transline.exceptions.OfficeTypeNotFoundException;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.LoginRepository;
import com.transline.repositories.OfficeTypeRepository;
import com.transline.repositories.RoleRepository;
import com.transline.utils.PasswordGenerator;

@Service
public class OfficeTypeServiceImpl  {
	
	private static final Logger logger=LoggerFactory.getLogger(OfficeTypeServiceImpl.class);


	@Autowired
	private OfficeTypeRepository officeTypeRepository;
	
	@Autowired
	private RoleRepository roleRepository;	

// ------------------------------------Model Mapper--------------------------------------------------------------
	
	public OfficeType dtoToOfficeType(OfficeTypeDTO dto) {
		OfficeType officeType=new OfficeType();
		officeType.setCmpCd(dto.getCmpCd());
		officeType.setOffType(dto.getOffType());
		officeType.setOffDesc(dto.getOffDesc());		
		officeType.setOffLevel(dto.getOffLevel());
		return officeType;
	}
	
	public OfficeTypeDTO officeTypeToDto(OfficeType o) {
		OfficeTypeDTO dto=new OfficeTypeDTO();
		dto.setCmpCd(o.getCmpCd());
		dto.setOffType(o.getOffType());
		dto.setOffDesc(o.getOffDesc());		
		dto.setOffLevel(o.getOffLevel());
		return dto;
	}
// --------------------------------------------------------------------------------------------------------------
	
	public OfficeType insertOfficeType(String cmpCd, NewOfficeTypeDTO dto) {
		if (officeTypeRepository.findByCmpCdAndOffType(cmpCd, dto.getOffType()).isPresent()) {
			throw new DuplicateEntryException("Resource already exists with offType: " + dto.getOffType());
		}
		OfficeType newOffType = new OfficeType();
		newOffType.setCmpCd(cmpCd);
		newOffType.setOffType(dto.getOffType());
		newOffType.setOffDesc(dto.getOffDesc());
		newOffType.setOffLevel(dto.getOffLevel());
		
		OfficeType savedOfficeType = this.officeTypeRepository.save(newOffType);				
		return savedOfficeType;
	}

	private List<RoleMst> createRolesForOfficeType(OfficeType officeType) {
	    String[] roles = { "AU", "NU" };
	    List<RoleMst> newRoles=new ArrayList();
	    for (String roleCode : roles) {
	        RoleMst role = new RoleMst();
	        role.setCmpCd(officeType.getCmpCd());
	        String roleType=String.format("%s(%s)",officeType.getOffType(),roleCode);
	        String roleDesc=String.format("%s(%s)",officeType.getOffDesc(),roleCode);
	        role.setRoleType(roleType);
	        role.setRoleDesc(roleDesc);	        
	        role.setAccessRights(Modules.getDefaultPermissions(roleType));
	        RoleMst newRole=roleRepository.save(role);
	        newRoles.add(newRole);
	    }
	    return newRoles;
	}

	public List<OfficeType> getOfficeTypes(String cmpCd) {		
		return officeTypeRepository.findByCmpCd(cmpCd);
	}
	
	public List<OffTypeDetailsDTO> getOfficeTypeDetails(String cmpCd) {
        List<Object[]> officeTypes = officeTypeRepository.getOffTypeAndOffDescCmpCd(cmpCd);
        return officeTypes.stream()
                .map(officeType -> new OffTypeDetailsDTO(
                		(String) officeType[0], 
                		(String) officeType[1],
                		(Integer) officeType[2]
                ))
                .collect(Collectors.toList());
    }
	

/*	    // Create two default users for the newly created office
 
	    List<Login> users = new ArrayList();
	    String cmpCd = dto.getCmpCd();
	    String newOffCd = dto.getOffType();
	    String roleAccRight = "1".repeat(Modules.values().length);
		RoleMst roleMst=new RoleMst();
		roleMst.setCmpCd(cmpCd);
		roleMst.setAccessRights(roleAccRight);
		roleMst.setRoleType("ADMIN");
		roleMst.setRoleDesc("Adminstrator");
		List<RoleMst> roles=List.of(roleMst);
		roleRepository.save(roleMst);
	  
	    // Authorized User
	    if (users.isEmpty()) {
	        String userId = newOffCd + 'A';
	        String password =PasswordGenerator.generatePassword();
	        
	        Login user = new Login();                                                                                                                                                
	        user.setCmpCd(cmpCd);
	        user.setOffice(newOffice);
	        user.setPwd(passwordEncoder.encode(password));
	        user.setUserName(userId);
	        user.setName(newOffice.getOffName() + "(AU)");
	        user.setDefaultUser(true);
	        user.setUserType("A");
	        user.setRoleMst(roleMst);
	        String userAccRight = "1".repeat(Modules.values().length);
	        user.setAccessRights(userAccRight);
	        user.setStatus("T");
	        Login savedUser = loginRepository.save(user);
	        savedUser.setPwd(password);  // Set plain password for display purposes
	        users.add(savedUser);
	    }

	    // Normal User
	    if (!users.isEmpty()) {
	        String userId = newOffCd + 'N';
	        String password =  PasswordGenerator.generatePassword();
	        
	        Login user = new Login();
	        user.setCmpCd(cmpCd);
	        user.setOffice(newOffice);
	        user.setPwd(passwordEncoder.encode(password));
	        user.setUserName(userId);
	        user.setName(newOffice.getOffName() + "(NU)");
	        user.setDefaultUser(true);
	        user.setUserType("N");
	        user.setRoleMst(roleMst);
	        String userAccRight = "1".repeat(Modules.values().length);
	        user.setAccessRights(userAccRight);
	        user.setStatus("T");
	        Login savedUser = loginRepository.save(user);
	        savedUser.setPwd(password);  // Set plain password for display purposes
	        users.add(savedUser);
	    }
	    HashMap<String, String> hmData = new HashMap<>();
	    hmData.put("Authorized User", String.format("( User ID : %s , Password : %s , Roles : %s )",
	            users.get(0).getUserName(), users.get(0).getPwd(), users.get(0).getRoleMst().getRoleType()));
	    hmData.put("Normal User", String.format("( User ID : %s , Password : %s , Roles : %s )",
	            users.get(1).getUserName(), users.get(1).getPwd(), users.get(1).getRoleMst().getRoleType()));
*/
	
	
//	@Override
//	public OfficeType insertOfficeType(OfficeTypeDTO dto) {
//		if(officeTypeRepository.findByCmpCdAndOffType(dto.getCmpCd(),dto.getOffType()).isPresent()) {
//			throw new DuplicateEntryException("Resource already exists with offType:"+dto.getOffType());
//		}
//		return this.officeTypeRepository.save(this.dtoToOfficeType(dto));		
//	}

	
//	public String findByCmpCdAndOfficeType(String cmpCd, String offType) {
//        return officeTypeRepository.findByCmpCdAndOfficeType(cmpCd, offType)
//            .orElseThrow(() -> new OfficeTypeNotFoundException("OfficeType not found for cmpCd: " + cmpCd + " and officeType: " + offType));
//    }
	
}

//// Retrieve OfficeType by composite key
//public Optional<OfficeType> getOfficeType(OffTypeId id) {
//	return officeTypeRepository.findById(id);
//}
//
//// Delete OfficeType by composite key
//public void deleteOfficeType(OffTypeId id) {
//	officeTypeRepository.deleteById(id);
//}
//
//// Retrieve OfficeTypes by description
//public OfficeType findByOffDesc(String offDesc) {
//	return officeTypeRepository.findByOffDesc(offDesc);
//}
//
//// Example: Retrieve OfficeTypes by level
//public List<OfficeType> findByOffLevel(Integer level) {
//	return officeTypeRepository.findByOffLevel(level);
//}
