package com.transline.servicesImp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.transline.AuthUtils;
import com.transline.dtos.GetLockerId;
import com.transline.dtos.LockerAllocateFreezeDetailDTO;
import com.transline.dtos.LockerAllocatedDTO;
import com.transline.dtos.LockerAllocationDetailsDTO;
import com.transline.dtos.LockerCustomerDTO;
import com.transline.dtos.LockerDTO;
import com.transline.dtos.LockerDetailsDTO;
import com.transline.dtos.LockerFreezeDTO;
import com.transline.dtos.LockerFreezeDetailDTO;
import com.transline.dtos.LockerTypeDTO;
import com.transline.dtos.LockerTypeDetailsDTO;
import com.transline.dtos.LockerTypePricesDTO;
import com.transline.dtos.LockerUnAllocateFreezeDTO;
import com.transline.dtos.LockerUnAllocationDTO;
import com.transline.dtos.LockerUnAllocationDetailDTO;
import com.transline.dtos.NewLockerRequestDTO;
import com.transline.entities.Company;
import com.transline.entities.Locker;
import com.transline.entities.LockerType;
import com.transline.entities.LockerTypePrices;
import com.transline.enums.LockerStatus;
import com.transline.exceptions.LockerLocationAlreadyExist;
import com.transline.exceptions.LockerNoAlreadyExist;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.LockerAllocationRepository;
import com.transline.repositories.LockerRepository;
import com.transline.repositories.LockerTypeRepository;
import com.transline.repositories.OfficeRepository;
import com.transline.security.User;

import jakarta.transaction.Transactional;

@Service
public class LockerService {

	private static final Logger logger = LoggerFactory.getLogger(LockerService.class);

	@Autowired
	private LockerRepository lockerRepository;

	@Autowired
	private OfficeService officeService;

	@Autowired
	private LockerTypeService lockerTypeService;

	@Autowired
	private LockerTypeRepository lockerTypeRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private LockerAllocationRepository allocationRepository;

	@Autowired
	private OfficeRepository officeRepository;

// ----------------------------------Model Mapper------------------------

	private Locker dtoToLocker(LockerDTO dto) {
		Locker locker = this.modelMapper.map(dto, Locker.class);
		return locker;
	}

	private LockerDTO lockerToDto(Locker locker) {
		LockerDTO dto = new LockerDTO();
		dto.setId(locker.getId());
		dto.setOffCd(locker.getOffCd());
		dto.setLockerNo(locker.getLockerNo());
		dto.setLockerType(locker.getLockerType().getType());
		dto.setLockerTypeId(locker.getLockerType().getId());
		dto.setLocation(locker.getLocation());
		dto.setStatus(locker.getStatus());
		dto.setFreezeDate(locker.getFreezeDate());
		// dto.setComment(locker.getRemarksJson().toString());
		return dto;
	}
// -------------------------------------------------------------------------------------

//	public LockerDTO createLocker(LockerDTO dto,String cmpCd) {
//		Locker locker = this.dtoToLocker(dto);
//		locker.setCmpCd(cmpCd);
//		Locker saveLocker = this.lockerRepository.save(locker);
//		return this.lockerToDto(saveLocker);
//	}

	// set multiple data
	public List<LockerDTO> createLockers(String cmpCd, NewLockerRequestDTO dto) {
		LockerType lockerType = lockerTypeRepository.findById(dto.getLockerTypeId())
				.orElseThrow(() -> new ResourceNotFoundException("LockerType", "lockerTypeId", dto.getLockerTypeId()));

		List<Locker> lockers = dto.getLockers().stream().map(newLockerDTO -> {
			lockerRepository.getByLockerNoOrLocation(cmpCd, dto.getOffCd(), newLockerDTO.getLockerNo(),
					newLockerDTO.getLocation()).ifPresent((locker) -> {
						if (newLockerDTO.getLocation().equalsIgnoreCase(locker.getLocation())) {
							String msg = String.format("Location: %s Already exists within the Office (%s)",
									newLockerDTO.getLocation(), dto.getOffCd());
							throw new LockerLocationAlreadyExist(msg);
						} else if (newLockerDTO.getLockerNo().equalsIgnoreCase(locker.getLockerNo())) {
							String msg = String.format("Locker No: %s Already exists ", newLockerDTO.getLockerNo(),
									dto.getOffCd());
							throw new LockerNoAlreadyExist(msg);
						}
					});

			Locker locker = new Locker();
			locker.setCmpCd(cmpCd);
			locker.setOffCd(dto.getOffCd());
			locker.setLockerNo(newLockerDTO.getLockerNo());
			locker.setLockerType(lockerType);
			locker.setLocation(newLockerDTO.getLocation());
			// locker.setStatus(newLockerDTO.getStatus());
			locker.setStatus(LockerStatus.AVL);

			return locker;
		}).collect(Collectors.toList());

		List<Locker> savedLockers = this.lockerRepository.saveAll(lockers);

		User user = AuthUtils.getCurrentUser();
		Map<String, String> offices = officeService.getOfficesMap(user.getCmpCd(), user.getOffCd());
		String officeName = offices.get(dto.getOffCd());
		return savedLockers.stream().map(locker -> {
			LockerDTO lockerDTO = this.lockerToDto(locker);
			lockerDTO.setOffName(officeName);
			return lockerDTO;
		}).collect(Collectors.toList());
	}

	public LockerDTO getLockerById(Long id) {
		Locker locker = this.lockerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker", "id", id));
		User user = AuthUtils.getCurrentUser();
		Map<String, String> offices = officeService.getOfficesMap(user.getCmpCd(), user.getOffCd());
		String officeName = offices.get(locker.getOffCd());
		LockerDTO lockerDTO = this.lockerToDto(locker);
		lockerDTO.setOffName(officeName);

		return lockerDTO;
	}

//	public LockerDTO updateLocker(String cmpCd, LockerDTO dto, Long id) {
//	    Locker locker = lockerRepository.findById(id)
//	            .orElseThrow(() -> new ResourceNotFoundException("Locker", "id", id));
//
//	    if (LockerStatus.FREEZE == dto.getStatus() ) {
//	    	
//	        if (dto.getComment() == null && dto.getComment().trim().isEmpty()) {
//	            throw new IllegalArgumentException("Remarks is required when locker status is 'FREEZE'.");
//	        }
//	        if (dto.getFreezeDate() == null ) {
//	        	 locker.setFreezeDate(LocalDateTime.now());   
//	        }
//	       // locker.setRemarks(dto.getRemarks());
//	        JSONObject remarksJson = new JSONObject();
//	        remarksJson.put("updatedBy", AuthUtils.getCurrentUser().getUsername());
//	        remarksJson.put("updatedOn", LocalDateTime.now().toString());
//	        remarksJson.put("comment", dto.getComment());
//
//	        // Set the remarks
//	        locker.setRemarksJson(remarksJson);
//	        locker.setFreezeDate(LocalDateTime.now());
//	        locker.setStatus(LockerStatus.FREEZE); 
//	    }
//	    if(dto.getStatus() !=null) {
//	    	locker.setStatus(dto.getStatus());
//	    }
//
//	    if (dto.getOffCd() != null) {
//	        locker.setOffCd(dto.getOffCd());
//	    }
//	    if (dto.getLockerNo() != null) {
//	        locker.setLockerNo(dto.getLockerNo());
//	    }
//
//	    if (dto.getLockerTypeId() != null) {
//	        LockerType lockerType = lockerTypeRepository.findById(dto.getLockerTypeId())
//	                .orElseThrow(() -> new ResourceNotFoundException("LockerType", "id", dto.getLockerTypeId()));
//	        locker.setLockerType(lockerType);
//	    }
//
//	    if (dto.getLocation() != null) {
//	        locker.setLocation(dto.getLocation());
//	    }
//
//	    if (dto.getComment() != null && !dto.getComment().trim().isEmpty()) {
//	        locker.setRemarks(dto.getComment());
//	    }
//	    if (dto.getFreezeDate() != null) {
//	        locker.setFreezeDate(dto.getFreezeDate());
//	    }
//	    locker = lockerRepository.save(locker);
//	    return this.lockerToDto(locker);
//	}

	public void deleteLocker(Long id) {
		Locker locker = this.lockerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("locker", "id", id));
		this.lockerRepository.delete(locker);
	}

	public List<LockerDTO> getAllLocker(String offCd) {
		User user = AuthUtils.getCurrentUser();
		logger.info("UserInfo:", user);

		List<Object[]> lockerData = new ArrayList<>();
		List<Locker> lockers = new ArrayList<>();
		if (offCd.isEmpty() || offCd.equalsIgnoreCase("ALL")) {
			List<String> officeCodes = officeService.getOfficeCodes(user.getCmpCd(), user.getOffCd());
			lockerData = lockerRepository.getLockersWithAllocationDetails(user.getCmpCd(), officeCodes);
		} else {
			lockers = lockerRepository.getLockersByOfficeCode(user.getCmpCd(), offCd);
		}

		Map<String, String> offices = officeService.getOfficesMap(user.getCmpCd(), user.getOffCd());
		Map<Long, LockerTypeDetailsDTO> lockerTypes = lockerTypeService.getLockerTypeAsMap(user.getCmpCd());
		logger.info("offices details" + offices);

		List<LockerDTO> lockerDTOs = new ArrayList<>();
		if (!lockerData.isEmpty()) {
			lockerDTOs = lockerData.stream().map(data -> {
				LockerDTO dto = new LockerDTO();
				Locker locker = (Locker) data[0];
				LocalDateTime allocatedAt = (LocalDateTime) data[1];
				dto = this.lockerToDto(locker);
				dto.setAllocatedAt(allocatedAt);
				dto.setOffName(offices.get(dto.getOffCd()));
				// dto.setLockerType(lockerTypes.get(dto.getLockerTypeId()));

				LockerTypeDetailsDTO lockerTypeDetails = lockerTypes.get(dto.getLockerTypeId());

				// Set locker type and dimension if available
				if (lockerTypeDetails != null) {
					dto.setLockerType(lockerTypeDetails.getLockerType());
					dto.setDimension(lockerTypeDetails.getDimension());
				}
				return dto;
			}).collect(Collectors.toList());
		} else {
			lockerDTOs = lockers.stream().map(lock -> {
				LockerDTO dto = this.lockerToDto(lock);
				dto.setOffName(offices.get(dto.getOffCd()));
				// dto.setLockerType(lockerTypes.get(dto.getLockerTypeId()));
				LockerTypeDetailsDTO lockerTypeDetails = lockerTypes.get(dto.getLockerTypeId());
				if (lockerTypeDetails != null) {
					dto.setLockerType(lockerTypeDetails.getLockerType());
					dto.setDimension(lockerTypeDetails.getDimension());
				}
				return dto;
			}).collect(Collectors.toList());
		}
		return lockerDTOs;
	}

	public List<GetLockerId> getLockerNoAndId(String cmpCd, String offCd, Long lockerTypeId) {
		List<Object[]> results = lockerRepository.getLockerNoAndIdByCmpCdAndLockerType(cmpCd, offCd, lockerTypeId);
		return results.stream().map(result -> new GetLockerId((Long) result[0], (String) result[1]))
				.collect(Collectors.toList());
	}

	public LockerAllocatedDTO getLockerAllocated(String cmpCd, String offCd) {
		Long totalLockers = lockerRepository.countTotalLockers(cmpCd, offCd);
		Long allocatedLockers = lockerRepository.countAllocatedLockers(cmpCd, offCd);
		List<LockerAllocationDetailsDTO> allocatedLockerDetails = lockerRepository.findAllocatedLockers(cmpCd, offCd);

		LockerAllocatedDTO allocated = new LockerAllocatedDTO();
		allocated.setTotalLockers(totalLockers);
		allocated.setLockers(allocatedLockers);
		allocated.setAllocatedLockerDetails(allocatedLockerDetails);
		return allocated;
	}

	public LockerUnAllocationDTO getLockerUnAllocated(String cmpCd, String offCd) {
		Long totalLockers = lockerRepository.countTotalLockers(cmpCd, offCd);
		Long allocatedLockers = lockerRepository.countUnAllocatedLockers(cmpCd, offCd);
		List<LockerUnAllocationDetailDTO> unAllocatedLockerDetails = lockerRepository.findUnAllocatedLockers(cmpCd,
				offCd);

		LockerUnAllocationDTO unAllocated = new LockerUnAllocationDTO();
		unAllocated.setTotalLockers(totalLockers);
		unAllocated.setLockers(allocatedLockers);
		unAllocated.setUnAllocatedLockerDetails(unAllocatedLockerDetails);
		return unAllocated;
	}

	public LockerUnAllocateFreezeDTO getLockerAllocatedFreeze(String cmpCd, String offCd) {
		Long totalLockers = lockerRepository.countTotalLockers(cmpCd, offCd);
		Long allocatedLockers = lockerRepository.countAllocatedFreezeLockers(cmpCd, offCd);
		List<LockerAllocateFreezeDetailDTO> afLockerDetails = lockerRepository.findAllocatedFreezeLockers(cmpCd, offCd);

		LockerUnAllocateFreezeDTO af = new LockerUnAllocateFreezeDTO();
		af.setTotalLockers(totalLockers);
		af.setLockers(allocatedLockers);
		af.setAfLockerDetails(afLockerDetails);
		return af;
	}

//	 public LockerFreezeDTO getLockerFreeze(String cmpCd, String offCd) {
//		 Long totalLockers = lockerRepository.countTotalLockers(cmpCd, offCd);
//	        Long allocatedLockers = lockerRepository.countFreezeLockers(cmpCd, offCd);
//	        List<LockerFreezeDetailDTO> freezeLockerDetails = lockerRepository.findFreezeLockers(cmpCd, offCd);
//
//	        LockerFreezeDTO freeze = new LockerFreezeDTO();
//	        freeze.setTotalLockers(totalLockers);
//	        freeze.setLockers(allocatedLockers);
//	        freeze.setFreezeLockerDetails(freezeLockerDetails);
//	        return freeze;
//	 }

	public Map<String, Long> getLockerCountsByStatus(String offCd) {
		List<Object[]> results = lockerRepository.countLockersByStatus(offCd);

		if (results.isEmpty()) {
			return Map.of("availableCount", 0L, "assignedCount", 0L, "underMaintenanceCount", 0L, "freezeCount", 0L);
		}

		Object[] result = results.get(0);
		Map<String, Long> counts = new HashMap<>();
		counts.put("availableCount", ((Number) result[1]).longValue());
		counts.put("assignedCount", ((Number) result[2]).longValue());
		counts.put("underMaintenanceCount", ((Number) result[3]).longValue());
		counts.put("freezeCount", ((Number) result[4]).longValue());
		return counts;
	}

	public List<String> getAllLockerNumbersByOffice(String cmpCd, String offCd) {
		return lockerRepository.getLockerNumbersByOfficeCode(cmpCd, offCd);
	}

	public List<LockerDetailsDTO> getAllLockerDetailsByOffice(String cmpCd, String offCd) {
		return lockerRepository.getLockerDetailsByOfficeCode(cmpCd, offCd);
	}

}
