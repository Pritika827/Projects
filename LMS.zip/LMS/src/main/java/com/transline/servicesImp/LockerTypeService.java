package com.transline.servicesImp;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.transline.controllers.AdminController;
import com.transline.dtos.LockerTypeDTO;
import com.transline.dtos.LockerTypeDetailsDTO;
import com.transline.dtos.UpdateLockerTypeDTO;
import com.transline.entities.Company;
import com.transline.entities.LockerType;
import com.transline.entities.LockerTypePrices;
import com.transline.enums.LockerStatus;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.CompanyRepository;
import com.transline.repositories.LockerRepository;
import com.transline.repositories.LockerTypeRepository;

@Service
public class LockerTypeService {

	private static final Logger logger = LoggerFactory.getLogger(LockerTypeService.class);

	@Autowired
	private LockerTypeRepository lockerTypeRepository;

	@Autowired
	private CompanyRepository companyRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private LockerRepository lockerRepository;

// ----------------------------------Model Mapper------------------------

	private LockerType dtoToLockerType(String cmpCd, LockerTypeDTO dto) {
		LockerType lockerType = this.modelMapper.map(dto, LockerType.class);
		lockerType.setCmpCd(cmpCd);
		return lockerType;
	}

	private LockerTypeDTO lockerTypeToDto(LockerType lockerType) {
		LockerTypeDTO dto = modelMapper.map(lockerType, LockerTypeDTO.class);
		return dto;
	}

// -------------------------------------------------------------------------------------

	public LockerTypeDTO createLockerType(String cmpCd, LockerTypeDTO dto) {
		try {
			LockerType lockerType = new LockerType();
			lockerType.setCmpCd(cmpCd);
			lockerType.setType(dto.getType());
			lockerType.setDescription(dto.getDescription());
			lockerType.setDimension(dto.getDimension());
			LockerType savedLockerType = this.lockerTypeRepository.save(lockerType);
			return this.lockerTypeToDto(savedLockerType);
		} catch (DataIntegrityViolationException ex) {
			throw new ResourceNotFoundException("Locker type with type " + dto.getType() + " already exits.");
		}
	}

	public List<LockerTypeDTO> getAllLockerType(String cmpCd) {
		List<LockerType> lockerTypes = this.lockerTypeRepository.findByCmpCd(cmpCd);
		List<LockerTypeDTO> lockerTypeDTOs = lockerTypes.stream().map(lockerType -> {
			long avlLockerCount = lockerRepository.countAvailableLockersByLockerTypeId(LockerStatus.AVL,
					lockerType.getId());
			LockerTypeDTO dto = new LockerTypeDTO();
			dto.setId(lockerType.getId());
			dto.setType(lockerType.getType());
			dto.setDescription(lockerType.getDescription());
			dto.setDimension(lockerType.getDimension());
			dto.setAvlLockerCount(avlLockerCount);
			return dto;
		}).collect(Collectors.toList());
		return lockerTypeDTOs;
	}

	public LockerTypeDTO getLockerTypeById(Long id) {
		LockerType lockerType = this.lockerTypeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker Type", "id", id));

		long avlLockerCount = lockerRepository.countAvailableLockersByLockerTypeId(LockerStatus.AVL, id);
		LockerTypeDTO dto = new LockerTypeDTO();
		dto.setId(lockerType.getId());
		dto.setType(lockerType.getType());
		dto.setDimension(lockerType.getDimension());
		dto.setDescription(lockerType.getDescription());
		dto.setAvlLockerCount(avlLockerCount);
		return dto;
	}

	public LockerTypeDTO updateLockerType(String cmpCd, UpdateLockerTypeDTO dto) {
		LockerType lockerType = lockerTypeRepository.findById(dto.getId())
				.orElseThrow(() -> new ResourceNotFoundException("LockerType", "id", dto.getId()));
		lockerType.setCmpCd(cmpCd);
		lockerType.setType(dto.getLockerType());
		lockerType.setDescription(dto.getDescription());
		lockerType.setDimension(dto.getDimension());

		LockerType updatedLockerType = lockerTypeRepository.save(lockerType);
		return lockerTypeToDto(updatedLockerType);
	}

	public void deleteLockerType(Long id) {
		LockerType lockerType = this.lockerTypeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker Type", "id", id));
		this.lockerTypeRepository.delete(lockerType);
	}

	public HashMap<Long, String> getLockerType(String cmpCd) {
		HashMap<Long, String> lockerTypeMap = new HashMap<>();
		lockerTypeRepository.getLockerIdAndName(cmpCd).stream().forEach((arr) -> {
			lockerTypeMap.put((Long) arr[0], (String) arr[1]);
		});
		return lockerTypeMap;
	}

	public HashMap<Long, LockerTypeDetailsDTO> getLockerTypeAsMap(String cmpCd) {
		HashMap<Long, LockerTypeDetailsDTO> lockerTypeMap = new HashMap<>();
		lockerTypeRepository.getLockerIdAndNameWithDimension(cmpCd).stream().forEach(arr -> {
			Long id = (Long) arr[0];
			String type = (String) arr[1];
			String dimension = (String) arr[2];
			// lockerTypeMap.put(id, type + " - " + dimension);
			LockerTypeDetailsDTO details = new LockerTypeDetailsDTO(type, dimension);
			lockerTypeMap.put(id, details);
		});
		return lockerTypeMap;
	}

}
