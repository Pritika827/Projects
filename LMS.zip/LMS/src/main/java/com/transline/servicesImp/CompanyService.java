package com.transline.servicesImp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.transline.AuthUtils;
import com.transline.dtos.NewCompanyDTO;
import com.transline.entities.Company;
import com.transline.entities.Login;
import com.transline.entities.ModuleMst;
import com.transline.entities.Office;
import com.transline.entities.OfficeType;
import com.transline.entities.RoleMst;
import com.transline.enums.Modules;
import com.transline.exceptions.ErrorResponse;
import com.transline.exceptions.GeneralException;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.CompanyRepository;
import com.transline.repositories.LoginRepository;
import com.transline.repositories.ModuleMstRepository;
import com.transline.repositories.OfficeRepository;
import com.transline.repositories.OfficeTypeRepository;
import com.transline.repositories.RoleRepository;
import com.transline.utils.PasswordGenerator;

import jakarta.transaction.Transactional;

@Service
public class CompanyService {

	private static final Logger logger = LoggerFactory.getLogger(CompanyService.class);

	private static final String UPLOAD_DIR = "logos/";

	@Autowired
	private CompanyRepository companyRepository;

	@Autowired
	private OfficeTypeRepository officeTypeRepository;

	@Autowired
	private ModuleMstRepository moduleMstRepository;

	@Autowired
	private OfficeRepository officeRepository;

	@Autowired
	private LoginRepository loginRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private RoleRepository roleRepository;

	public boolean isAlreadyExists(String cmpCd) {
		return companyRepository.existsById(cmpCd);
	}

	@Transactional
	public Map<String, String> insertCompany(NewCompanyDTO dto) {
		// Insert Data into Company
		Company company = new Company();
		company.setCmpCd(dto.getCmpCd());
		company.setCmpName(dto.getCmpName());
		company.setCmpAdd(dto.getCmpAdd());
		company.setCity(dto.getCity());
		company.setState(dto.getState());
		company.setAutoGenEmpId("F");
		company.setEmail(dto.getEmail());
		company.setPhn1(dto.getPhn1());
		company.setPhn2(dto.getPhn2());
		company.setFaxNo(dto.getFaxNo());
		company.setOorn("N");
		company.setWebsite(dto.getWebsite());
		Company savedCompany = companyRepository.save(company);

		String cmpCd = dto.getCmpCd();

		// Insert Data into ModuleMst
		List<ModuleMst> moduleMstList = Arrays.asList(Modules.values()).stream().map(module -> {
			ModuleMst m = new ModuleMst();
			m.setCmpCd(cmpCd);
			m.setModuleId(module.getCode());
			m.setModuleName(module.name().toString());
			m.setStatus("A");
			m.setParentId(0);
			return m;
		}).collect(Collectors.toList());
		moduleMstRepository.saveAll(moduleMstList);

		// Insert Data into RoleMst
		String roleAccRight = "1".repeat(Modules.values().length);
		RoleMst roleA = new RoleMst();
		roleA.setCmpCd(cmpCd);
		roleA.setAccessRights(roleAccRight);
		roleA.setRoleType("HO_AU");
		roleA.setRoleDesc("Adminstrator");
		List<RoleMst> roleAu = List.of(roleA);
		roleRepository.save(roleA);

//		String accessRights = roleAccRight.substring(0, 15) + "00" + roleAccRight.substring(17);
//		RoleMst roleN=new RoleMst();
//		roleN.setCmpCd(cmpCd);
//		roleN.setAccessRights(accessRights);
//		roleN.setRoleType("HO_NU");
//		roleN.setRoleDesc("Normal");
//		List<RoleMst> roleNu=List.of(roleN);
//		roleRepository.save(roleN);

		logger.info("[before Office Creation]");
		// Insert Office Type (HO-Head Office)
		OfficeType ot = new OfficeType();
		ot.setCmpCd(cmpCd);
		ot.setOffType("HO");
		ot.setOffDesc("Head Office");
		ot.setOffLevel(10);
		OfficeType savedOfficeType = officeTypeRepository.save(ot);

		// Create Head Office for Company
		// String newOffCd = dto.getOffice_info().getOffName().substring(0,
		// 2).toUpperCase() + "001";
		String offName = dto.getOffice_info().getOffName();
		String newOffCd = (offName != null && offName.length() >= 2 ? offName.substring(0, 2).toUpperCase()
				: offName.toUpperCase()) + "001";

		Office office = new Office();
		office.setCmpCd(cmpCd);
		office.setOffCd(newOffCd);
		office.setOfficeType(savedOfficeType);
		office.setCtlCd("HO");
		office.setWorkingStatus("RWO");
		office.setOffName(dto.getOffice_info().getOffName());
		office.setOffAddress(dto.getOffice_info().getOffAddress());
		office.setPhoneNo(dto.getOffice_info().getPhoneNo());
		office.setEmail(dto.getOffice_info().getEmail());
		office.setContactPerson(dto.getOffice_info().getContactPerson());
		office.setPath(newOffCd);
		Office savedOffice = officeRepository.save(office);

		// Create Two Default Users for Newly created Office
		List<Login> users = new ArrayList<>();
		if (users.isEmpty()) {
			String userId = newOffCd + 'A';
			String password = dto.getOffice_info().getAuPassword();
			if (password == null || password.isEmpty()) {
				// password=String.format("%d", Double.valueOf(100000 + Math.random() *
				// 1000000).intValue());
				password = PasswordGenerator.generatePassword();
			}
			Login user = new Login();
			user.setCmpCd(cmpCd);
			user.setOffice(savedOffice);
			user.setPwd(passwordEncoder.encode(password));
			user.setUserName(userId);
			user.setName(savedOffice.getOffName() + "(AU)");
			// user.setDefaultUser(true);
			user.setUserType("A");
			user.setRoleMst(roleA);
			String userAccRight = "1".repeat(Modules.values().length);
			user.setAccessRights(userAccRight);
			user.setStatus("T");
			Login savedUser = loginRepository.save(user);
			savedUser.setPwd(password);
			users.add(savedUser);
		}

		/*
		 * if(!users.isEmpty()) { String userId = newOffCd + 'N'; String password =
		 * dto.getOffice_info().getNuPassword(); if(password==null ||
		 * password.isEmpty()) { //password=String.format("%d", Double.valueOf(100000 +
		 * Math.random() * 1000000).intValue());
		 * password=password=PasswordGenerator.generatePassword(); }
		 * 
		 * Login user = new Login(); user.setCmpCd(cmpCd); user.setOffice(savedOffice);
		 * user.setPwd(passwordEncoder.encode(password)); user.setUserName(userId);
		 * user.setName(savedOffice.getOffName() + "(NU)"); //
		 * user.setDefaultUser(true); user.setUserType("N"); user.setRoleMst(roleN);
		 * String userAccRight = "1".repeat(Modules.values().length);
		 * user.setAccessRights(userAccRight); user.setStatus("T"); Login
		 * savedUser=loginRepository.save(user); savedUser.setPwd(password);
		 * users.add(savedUser); }
		 */

		// createCompanyWithOfficeAndUser(company, ot, office, moduleMstList, roles,
		// users);
		HashMap<String, String> hmData = new HashMap();
		// hmData.put("Company Mst", companyMstDto);
		// hmData.put("Authorised User", "( User ID : "+authorizedUserId+" , Passwprd :
		// " +authorizedPassword+", Role:"+authorizedRole+")");
		// hmData.put("Normal User", "( User ID : "+normalUserId+" , Passwprd : "
		// +normalPassword+",Role:"+normalRole+")");

		hmData.put("Authorized User", String.format("( User ID : %s , Password : %s , Roles : %s )",
				users.get(0).getUserName(), users.get(0).getPwd(), users.get(0).getRoleMst().getRoleType()));

//		hmData.put("Normal User",String.format(
//		"( User ID : %s , Password : %s , Roles : %s )"
//		, users.get(1).getUserName(),users.get(1).getPwd(), users.get(1).getRoleMst().getRoleType()
//		));

		return hmData;
	}

	public Company getCompany(String cmpCd) {
		Company company = companyRepository.findById(cmpCd).orElseThrow(
				() -> new ResourceNotFoundException("company mst with this not found no the server" + cmpCd));
		return company;
	}

	public List<Map<String, Object>> getCompanyList() {
		List<Object[]> companies = this.companyRepository.getCompanyList();
		List<Map<String, Object>> companyList = new ArrayList<>();
		companies.stream().forEach(arr -> {
			HashMap<String, Object> row = new HashMap<>();
			row.put("cmpCd", arr[0]);
			row.put("cmpName", arr[1]);
			row.put("status", arr[2]);
			companyList.add(row);
		});
		return companyList;
	}

	public NewCompanyDTO toDto(Company dto) {
		// Insert Data into Company
		NewCompanyDTO company = new NewCompanyDTO();
		company.setCmpCd(dto.getCmpCd());
		company.setCmpName(dto.getCmpName());
		company.setCmpAdd(dto.getCmpAdd());
		company.setCity(dto.getCity());
		company.setState(dto.getState());
		company.setEmail(dto.getEmail());
		company.setPhn1(dto.getPhn1());
		company.setPhn2(dto.getPhn2());
		company.setFaxNo(dto.getFaxNo());
		company.setWebsite(dto.getWebsite());
		return company;
	}

//	@Override
//	public CompanyMstDto updateCompanyMst(String cmpCd, CompanyMstDto companyMstDto, MultipartFile file)
//			throws java.io.IOException {
//		Company existingCompanyMst = this.companyRepository.findById(cmpCd)
//				.orElseThrow(() -> new ResourceNotFoundException("Compant Mst", "id", cmpCd));
//
//		if (file != null && !file.isEmpty()) {
//			try {
//				String companyName = companyMstDto.getCmpName(); // Assuming you have this field
//				if (companyName == null || companyName.isEmpty()) {
//					throw new IllegalArgumentException("Company name must be provided.");
//				}
//				String sanitizedCompanyName = companyName.replaceAll("[^a-zA-Z0-9]", "_");
//				String fileExtension = getFileExtension(file.getOriginalFilename());
//				String fileName = sanitizedCompanyName + fileExtension;
//
//				Path filePath = Paths.get(UPLOAD_DIR + fileName);
//				Files.createDirectories(filePath.getParent());
//				Files.write(filePath, file.getBytes());
//
//				existingCompanyMst.setCmpLogo(filePath.toString());
//			} catch (IOException e) {
//				throw new RuntimeException("Failed to store file", e);
//			}
//		}
//		if (companyMstDto.getCmpName() == null || companyMstDto.getCmpName().length() < 2) {
//			throw new IllegalArgumentException("Company name must be at least 2 characters long.");
//		}
//		String prefix = companyMstDto.getCmpName().substring(0, 2).toUpperCase();
//		Integer maxNumber = companyRepository.findMaxNumberForPrefix(prefix).orElse(0);
//		Integer nextNumber = maxNumber + 1;
//		String formattedNumber = String.format("%05d", nextNumber);
//
////		String code = prefix + formattedNumber;
////		existingCompanyMst.setCmpCd(code);	
//
//		existingCompanyMst.setCmpName(companyMstDto.getCmpName());
//		existingCompanyMst.setCmpAdd(companyMstDto.getCmpAdd());
//		existingCompanyMst.setCity(companyMstDto.getCity());
//		existingCompanyMst.setState(companyMstDto.getState());
//		existingCompanyMst.setWebsite(companyMstDto.getWebsite());
//		existingCompanyMst.setEmail(companyMstDto.getEmail());
//		existingCompanyMst.setPhn1(companyMstDto.getPhn1());
//		existingCompanyMst.setPhn2(companyMstDto.getPhn2());
//
//		Company updatedcompanyMst = this.companyRepository.save(existingCompanyMst);
//
//		return this.toDto(updatedcompanyMst);
//	}

}
