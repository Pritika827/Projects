package com.transline.servicesImp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.transline.dtos.RoleDto;
import com.transline.dtos.RoleResDto;
import com.transline.entities.RoleMst;
import com.transline.exceptions.DuplicateEntryException;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.RoleRepository;

import jakarta.validation.ConstraintViolationException;

@Service
public class RoleServiceImpl {

	private static final Logger logger = LoggerFactory.getLogger(RoleServiceImpl.class);

	@Autowired
	private RoleRepository roleRepository;

//---------------------Model Mapper---------------------------------
	@Autowired
	private ModelMapper modelMapper;

	private RoleMst dtoToRole(RoleDto roleDto) {
		RoleMst roleMst = this.modelMapper.map(roleDto, RoleMst.class);
		return roleMst;
	}

	public RoleDto roleToDto(RoleMst roleMst) {
		RoleDto roleDto = this.modelMapper.map(roleMst, RoleDto.class);
		return roleDto;
	}
// ---------------------------------------------------------------------------------------------

	public RoleDto saveRole(RoleDto roleDto) {
		try {
			RoleMst roleMst = this.dtoToRole(roleDto);
			RoleMst saveRole = this.roleRepository.save(roleMst);
			return this.roleToDto(saveRole);
		} catch (DataIntegrityViolationException e) {
			if (e.getCause() instanceof ConstraintViolationException) {
				ConstraintViolationException cause = (ConstraintViolationException) e.getCause();
				throw new DuplicateEntryException("RoleType already exists for this company.");
			} else {
				throw e;
			}
		}
	}

	public RoleDto getRoleById(Long id) {
		RoleMst roleMst = this.roleRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("role", "id", id));
		return this.roleToDto(roleMst);
	}

	public List<RoleDto> getAllRole() {
		List<RoleMst> roleMsts = this.roleRepository.findAll();
		List<RoleDto> roleDtos = roleMsts.stream().map(r -> this.roleToDto(r)).collect(Collectors.toList());
		return roleDtos;
	}

	public void deleteRole(Long id) {
		RoleMst roleMst = this.roleRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("role", "id", id));
		this.roleRepository.delete(roleMst);
	}

	public RoleDto updateRole(Long id, RoleDto roleDto) {
		RoleMst roleMst = this.roleRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("role", "id", id));
		roleMst.setRoleType(roleDto.getRoleType());
		roleMst.setRoleDesc(roleDto.getRoleDesc());
		roleMst.setAccessRights(roleDto.getAccessRights());

		RoleMst updatedRole = this.roleRepository.save(roleMst);
		RoleDto roleDto2 = this.roleToDto(updatedRole);
		return roleDto2;
	}

	public List<RoleResDto> getIdAndRoleTypes(String cmpCd) {
		List<Object[]> results = roleRepository.findIdAndRoleType(cmpCd);
		List<RoleResDto> roleDTOs = new ArrayList<>();

		for (Object[] result : results) {
			Long id = (Long) result[0];
			String roleType = (String) result[1];
			roleDTOs.add(new RoleResDto(id, roleType));
		}

		return roleDTOs;
	}

}
