package com.transline.servicesImp;

import java.io.IOException;
import java.time.LocalDateTime;

import org.modelmapper.ModelMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.transline.dtos.CustomerDTO;
import com.transline.dtos.CustomerEnrollDtlsDTO;
import com.transline.dtos.LockerDTO;
import com.transline.entities.Customer;
import com.transline.entities.CustomerEnrollDtls;
import com.transline.entities.Locker;
import com.transline.exceptions.DataNotSave;
import com.transline.repositories.CustomerEnrollDtlsRepository;
import com.transline.repositories.CustomerRepository;

import ch.qos.logback.classic.Logger;

@Service
public class CustomerEnrollDtlsServiceImpl {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CustomerEnrollDtlsServiceImpl.class);

	@Autowired
	private CustomerEnrollDtlsRepository dtlsRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ModelMapper modelMapper;

// ----------------------------------Model Mapper------------------------

	private CustomerEnrollDtls dtoToEnroll(CustomerEnrollDtlsDTO dto) {
		CustomerEnrollDtls dtls = this.modelMapper.map(dto, CustomerEnrollDtls.class);
		return dtls;
	}

	private CustomerEnrollDtlsDTO enrollToDto(CustomerEnrollDtls dtls) {
		CustomerEnrollDtlsDTO dto = modelMapper.map(dtls, CustomerEnrollDtlsDTO.class);
		return dto;
	}
// -------------------------------------------------------------------------------------

	public CustomerEnrollDtlsDTO saveEnrollmentDetails(CustomerEnrollDtlsDTO dto, String cmpCd,
			MultipartFile templateFile) {
		try {
			Customer customer = customerRepository.findById(dto.getCustomerId())
					.orElseThrow(() -> new RuntimeException("Customer not found"));

			byte[] templateBytes = templateFile.getBytes();

			CustomerEnrollDtls enrollmentDetails = this.dtoToEnroll(dto);
			enrollmentDetails.setId(dto.getId());
			enrollmentDetails.setCmpCd(cmpCd);
			enrollmentDetails.setFingerId(dto.getFingerId());
			enrollmentDetails.setTemplate(templateBytes);
			enrollmentDetails.setTemplateSize((long) templateBytes.length);
			enrollmentDetails.setCustomer(customer);
			enrollmentDetails.setCreatedAt(LocalDateTime.now());
			enrollmentDetails.setCreatedBy(dto.getCreatedBy());

			CustomerEnrollDtls saveEnroll = this.dtlsRepository.save(enrollmentDetails);

//          Customer savedCustomer = this.customerRepository.save(customer);
//          return this.customerToDto(savedCustomer);

			return this.enrollToDto(saveEnroll);

		} catch (IOException e) {
			throw new DataNotSave("Failed to save enrollment details", e);
		}
	}

}
