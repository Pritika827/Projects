package com.transline.servicesImp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import com.transline.controllers.AdminController;
import com.transline.entities.LockerType;
import com.transline.exceptions.DataNotSave;

import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

	private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

	@Autowired
	private JavaMailSender mailSender;

	public void sendOtpEmail(String toEmail, String otp) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(toEmail);
		message.setSubject("Your OTP Code");
		message.setText("Your OTP code is: " + otp + "\nThis code is valid for 5 minutes.");
		mailSender.send(message);
	}

	public void sendEmail(String to, String subject, String message) {
		try {
			MimeMessage mimeMessage = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(message);
			mailSender.send(mimeMessage);
		} catch (Exception e) {
			throw new DataNotSave("Failed to send email to " + to, e);
		}
	}

	public void sendLockerAvailabilityEmail(String toEmail, LockerType lockerType, long availableLockers) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(toEmail);
		message.setSubject("Locker Availability Notification");
		message.setText("There are " + availableLockers + " lockers of type " + lockerType
				+ " available. Please book your locker now.");
		mailSender.send(message);
	}

	public void sendLockerAllocationEmail(String toEmail, LockerType lockerType, String lockerNo) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(toEmail);
		message.setSubject("Locker Allocation Notification");
		message.setText("Your locker of type " + lockerType + " (Locker No: " + lockerNo
				+ ") has been successfully allocated.");
		mailSender.send(message);
	}

	public void sendNoLockersAvailableEmail(String toEmail, LockerType lockerType) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(toEmail);
		message.setSubject("No Lockers Available");
		message.setText("Sorry, there are no lockers available of type " + lockerType + " at the moment.");
		mailSender.send(message);
	}
}
