package com.transline.servicesImp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.transline.AuthUtils;
import com.transline.EncryptionUtil;
import com.transline.controllers.AdminController;
import com.transline.entities.Locker;
import com.transline.entities.LockerAllocationMst;
import com.transline.entities.Otp;
import com.transline.exceptions.OtpException;
import com.transline.repositories.LockerAllocationRepository;
import com.transline.repositories.LockerRepository;
import com.transline.repositories.OtpRepository;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class OtpService {

	private static final Logger logger = LoggerFactory.getLogger(OtpService.class);

	@Autowired
	private OtpRepository otpRepository;

	@Autowired
	private LockerRepository lockerRepository;
	@Autowired
	private LockerAllocationRepository lockerAllocationMstRepository;

	@Autowired
	private JavaMailSender javaMailSender;

	public void sendOtp(String to, String otp) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(to);
		message.setSubject("Your OTP Code");
		message.setText("Your OTP is: " + otp);
		javaMailSender.send(message);
	}

	public String generateAndSendOtp(String lockerNo, String offCd) {
		Locker locker = lockerRepository.findByLockerNoAndOffCd(lockerNo, offCd);
		if (locker == null) {
			throw new RuntimeException("Locker not found");
		}
		LockerAllocationMst allocation = lockerAllocationMstRepository.findByLocker(locker);
		if (allocation == null || allocation.getCustomer() == null) {
			throw new RuntimeException("Locker is not allocated to any customer");
		}
		String email = allocation.getCustomer().getEmailId();
		// EncryptionUtil.decrypt2(customer.getEmailId())
		System.out.print(email);
		String otp = String.valueOf((int) (Math.random() * 900000) + 100000); // 6-digit OTP
		Otp otpEntity = new Otp();
		otpEntity.setEmail(email);
		otpEntity.setOtp(otp);
		otpEntity.setExpiryTime(LocalDateTime.now().plusMinutes(5));
		otpRepository.save(otpEntity);

		sendOtp(email, otp);
		return "OTP sent successfully";
	}

	public boolean verifyOtp(String email, String otp) {
		Optional<Otp> otpRecord = otpRepository.findByEmailAndOtp(email, otp);
		if (otpRecord.isEmpty()) {
			throw new OtpException("Invalid OTP");
		}
		Otp otpEntity = otpRecord.get();
		if (otpEntity.getExpiryTime().isBefore(LocalDateTime.now())) {
			throw new OtpException("OTP has expired");
		}
		if (otpEntity.getIsVerified()) {
			throw new OtpException("OTP has already been used");
		}
		otpEntity.setIsVerified(true);
		otpRepository.save(otpEntity);
		return true;
	}

}
