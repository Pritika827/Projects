package com.transline.servicesImp;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.dtos.CustomerDTO;
import com.transline.dtos.NomineeDTO;
import com.transline.entities.Customer;
import com.transline.entities.Nominee;
import com.transline.exceptions.NomineeException;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.CustomerRepository;
import com.transline.repositories.NomineeRepository;
import ch.qos.logback.classic.Logger;

@Service
public class NomineeServiceImpl {

	private static final Logger logger = (Logger) LoggerFactory.getLogger(NomineeServiceImpl.class);

	@Autowired
	private NomineeRepository nomineeRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ModelMapper modelMapper;

// ----------------------------------Model Mapper------------------------

	private Nominee dtoToNominee(NomineeDTO dto) {
		Nominee nominee = this.modelMapper.map(dto, Nominee.class);
		return nominee;
	}

	private NomineeDTO nomineeToDto(Nominee nominee) {
		NomineeDTO dto = this.modelMapper.map(nominee, NomineeDTO.class);
		return dto;
	}

// ----------------------------------------------------------------------

	public NomineeDTO createNominee(NomineeDTO dto, String cmpCd) {
		Customer customer = customerRepository.findById(dto.getCustomerId())
				.orElseThrow(() -> new RuntimeException("Customer not found"));
		long existingNomineeCount = nomineeRepository.countByLockerIdAndCustomerId(dto.getLockerId(),
				dto.getCustomerId());
		if (existingNomineeCount >= 2) {
			throw new NomineeException("Two nominees already created for this locker and customer.");
		}
		if (nomineeRepository.existsByAdharNo(dto.getAdharNo())) {
			throw new NomineeException("A nominee with this Aadhar number already exists.");
		}
		Nominee nominee = this.dtoToNominee(dto);
		nominee.setCmpCd(cmpCd);
		nominee.setCustomer(customer);
		nominee.setAddedDate(LocalDateTime.now());
		Nominee savedNominee = this.nomineeRepository.save(nominee);
		return this.nomineeToDto(savedNominee);
	}

	public List<NomineeDTO> getAllNominee() {
		List<Nominee> nominee = this.nomineeRepository.findAll();
		return nominee.stream().map(this::nomineeToDto).collect(Collectors.toList());
	}

	public NomineeDTO getNomineeById(Long id) {
		Nominee nominee = this.nomineeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Nominee", "id", id));
		return this.nomineeToDto(nominee);
	}

	public NomineeDTO updateNominee(NomineeDTO dto, Long id) {
		Customer customer = this.customerRepository.findById(dto.getCustomerId())
				.orElseThrow(() -> new ResourceNotFoundException("Customer", "id", dto.getCustomerId()));

		Nominee nominee = this.nomineeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Nominee", "id", id));

		nominee.setLockerId(dto.getLockerId());
		nominee.setCustomer(customer);
		nominee.setNomineeName(dto.getNomineeName());
		nominee.setRelationship(dto.getRelationship());
		nominee.setDob(dto.getDob());
		nominee.setPhoneNo(dto.getPhoneNo());
		nominee.setAddress(dto.getAddress());
		nominee.setAdharNo(dto.getAdharNo());
		// nominee.setAddedDate(dto.getAddedDate());
		nominee.setUpdatedDate(LocalDateTime.now());
		nominee = nomineeRepository.save(nominee);
		return this.nomineeToDto(nominee);
	}

	public void deleteNominee(Long id) {
		Nominee nominee = this.nomineeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Nominee", "id", id));
		this.nomineeRepository.delete(nominee);
	}

}
