package com.transline.servicesImp;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.controllers.AdminController;
import com.transline.repositories.ModuleMstRepository;

@Service
public class ModuleMstServiceImpl {

	private static final Logger logger = LoggerFactory.getLogger(ModuleMstServiceImpl.class);

	@Autowired
	private ModuleMstRepository moduleMstRepository;

	public String getModAccessRights(String cmpCd) {
		StringBuilder sb = new StringBuilder();
		List<Object[]> list = moduleMstRepository.getModuleIdWithStatus(cmpCd);
		list.forEach(arr -> sb.append("A".equalsIgnoreCase((String) arr[1]) ? 1 : 0));
		return sb.toString();
	}

}
