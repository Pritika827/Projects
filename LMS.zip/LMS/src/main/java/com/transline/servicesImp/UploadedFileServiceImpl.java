package com.transline.servicesImp;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
//import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.transline.AuthUtils;
import com.transline.dtos.FileObject;
import com.transline.dtos.NewFileDTO;
import com.transline.dtos.UploadsDto;
import com.transline.entities.UploadedFile;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.UploadsRepository;
import com.transline.utils.ShortUniqueIdGenerator;

import jakarta.servlet.ServletContext;
import jakarta.transaction.Transactional;

@Service
public class UploadedFileServiceImpl  {

	private static final String UPLOAD_DIR = "uploads/";
	private static final Logger logger = LoggerFactory.getLogger(UploadedFileServiceImpl.class);

	@Autowired
	private ServletContext servletContext;

	@Autowired
	private UploadsRepository uploadsRepository;

	@Autowired
	private ModelMapper modelMapper;

//-------------------------------- Model Mapper-------------------------------------------------------

	private UploadsDto toDto(UploadedFile uploadedFile) {
		return modelMapper.map(uploadedFile, UploadsDto.class);
	}

	private UploadedFile toEntity(UploadsDto uploadsDto) {
		return modelMapper.map(uploadsDto, UploadedFile.class);
	}

//-----------------------------------------------------------------------------------------------------	 

	private String getFileExtension(String filename) {
		int dotIndex = filename.lastIndexOf(".");
		return dotIndex >= 0 ? filename.substring(dotIndex) : "";
	}

	public UploadsDto saveUploadFile(UploadsDto uploadsDto, MultipartFile file) {
		if (file != null && !file.isEmpty()) {
			try {
				String shortUniqueId = ShortUniqueIdGenerator.generateShortUniqueId();
				String fileExtension = getFileExtension(file.getOriginalFilename());
				String fileName = shortUniqueId + fileExtension;

				Path filePath = Paths.get(UPLOAD_DIR + fileName);
				Files.createDirectories(filePath.getParent());
				Files.write(filePath, file.getBytes());

				uploadsDto.setFilePath(filePath.toString());
				uploadsDto.setFileSize(String.valueOf(file.getSize()));
				uploadsDto.setFileDescription("Uploaded file: " + file.getOriginalFilename());

			} catch (IOException e) {
				throw new RuntimeException("Failed to store file", e);
			}
		}

		UploadedFile uploadsEntity = toEntity(uploadsDto);

		System.out.println("Uploads Entity before save: " + uploadsEntity.toString());
		UploadedFile savedEntity = uploadsRepository.save(uploadsEntity);
		System.out.println("Uploads Entity after save: " + savedEntity.toString());

		return toDto(savedEntity);
	}

	public UploadsDto getUploadFileById(int uploadId) {
		UploadedFile uploadedFile = uploadsRepository.findById(uploadId).orElseThrow(
				() -> new ResourceNotFoundException("upload file with id not found on the server" + uploadId));
		return this.toDto(uploadedFile);
	}

	public List<UploadsDto> getAllUploadFile() {
		List<UploadedFile> uploadedFile = this.uploadsRepository.findAll();
		List<UploadsDto> uploadsDtos = uploadedFile.stream().map(upload -> this.toDto(upload))
				.collect(Collectors.toList());
		return uploadsDtos;
	}

	public UploadsDto updateUploadFile(int uploadId, UploadsDto uploadsDto, MultipartFile file) {
//		// Retrieve the existing upload record by its ID
//		UploadedFile existingUpload = this.uploadsRepository.findById(uploadId)
//				.orElseThrow(() -> new ResourceNotFoundException("Upload", "id", uploadId));
//
//		// Check if the refId matches the existing record's refId
//		if (!existingUpload.getRefId().equals(uploadsDto.getRefId())) {
//			throw new IllegalArgumentException("Provided refId does not match the existing record.");
//		}
//
//		// If a new file is uploaded, update the file path and other file details
//		if (file != null && !file.isEmpty()) {
//			try {
//				// Generate a unique file name using ShortUniqueIdGenerator
//				String shortUniqueId = ShortUniqueIdGenerator.generateShortUniqueId();
//				String fileExtension = getFileExtension(file.getOriginalFilename());
//				String fileName = shortUniqueId + fileExtension;
//
//				// Define the file path for saving the uploaded file
//				Path filePath = Paths.get(UPLOAD_DIR + fileName);
//
//				// Create directories if they don't exist
//				Files.createDirectories(filePath.getParent());
//
//				// Save the file to the file system
//				Files.write(filePath, file.getBytes());
//
//				// Update the file-related information in the entity
//				existingUpload.setFilePath(filePath.toString());
//				existingUpload.setFileSize(String.valueOf(file.getSize()));
//				existingUpload.setFileDescription("Uploaded file: " + file.getOriginalFilename());
//
//			} catch (IOException e) {
//				throw new RuntimeException("Failed to store file", e);
//			}
//		}
//
//		// Update other fields of the Uploads entity
//		existingUpload.setFileType(uploadsDto.getUploadType());
//		existingUpload.setCreatedBy(uploadsDto.getCreatedBy());
//
//		// Save the updated entity to the repository
//		UploadedFile updatedUpload = this.uploadsRepository.save(existingUpload);

		// Convert the updated Uploads entity to UploadsDto and return it
		return null;
	}

	public void deleteUploadById(int uploadId) {
		UploadedFile uploadedFile = this.uploadsRepository.findById(uploadId).orElseThrow(
				() -> new ResourceNotFoundException("upload file with given id is not found on server!!" + uploadId));
		this.uploadsRepository.delete(uploadedFile);
	}

	@Transactional
	public int saveFiles(String cmpCd, String entityId, String entityType, List<NewFileDTO> files) {
		String rootPath = servletContext.getRealPath("/");
		String dirPath = rootPath.concat("MySavedFiles_" + cmpCd.toUpperCase());
		logger.info(dirPath);
		File destDir = new File(dirPath);
		if (!destDir.isDirectory()) {
			destDir.mkdirs();
		}

		List<File> savedFiles = new ArrayList<>();
		List<UploadedFile> uploadedFiles = new ArrayList<>();
		files.stream().forEach(nf -> {
			String oldFileName = nf.getFile().getOriginalFilename();
			String ext = oldFileName.substring(oldFileName.lastIndexOf(".") + 1);
			String newFileName = String.format("%s_%s_%s.%s", cmpCd, entityId, nf.getFileType(), ext);
			UploadedFile uf = new UploadedFile();
			uf.setCmpCd(cmpCd);
			uf.setRefId(entityId);
			uf.setRefType(entityType);
			uf.setFileName(newFileName);
			uf.setFileType(nf.getFileType());
			uf.setFilePath(nf.getFile().getOriginalFilename());
			uf.setFileDescription(nf.getFile().getOriginalFilename());
			uf.setFileSize(nf.getFile().getSize());
			uf.setCreatedAt(LocalDateTime.now());
			uf.setCreatedBy(AuthUtils.getCurrentUser().getUsername());

			File newFile = new File(destDir, uf.getFileName());
			try {
				nf.getFile().transferTo(newFile);
				savedFiles.add(newFile);
				uploadedFiles.add(uf);
			} catch (IOException ex) {

			}
		});
		if (savedFiles.size() == files.size()) {
			try {
				List<UploadedFile> savedUploadedFiles = this.uploadsRepository.saveAll(uploadedFiles);
				return savedUploadedFiles.size();
			} catch (Exception ex) {
				for (File file : savedFiles)
					file.delete();
			}
		} else {
			for (File file : savedFiles)
				file.delete();
		}

		return 0;
	}
}
