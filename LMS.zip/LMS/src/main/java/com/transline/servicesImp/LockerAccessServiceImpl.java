package com.transline.servicesImp;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.transline.dtos.LockerAccessDTO;
import com.transline.dtos.LockerAllocationMstDTO;
import com.transline.entities.Customer;
import com.transline.entities.Locker;
import com.transline.entities.LockerAccess;
import com.transline.entities.LockerAllocationMst;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.CustomerRepository;
import com.transline.repositories.LockerAccessRepository;
import com.transline.repositories.LockerRepository;


@Service
public class LockerAccessServiceImpl {

	private static final Logger logger = LoggerFactory.getLogger(LockerAccessServiceImpl.class);

	@Autowired
	private LockerAccessRepository accessRepository;

	@Autowired
	private LockerRepository lockerRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private EmailService emailService;

// ----------------------------------Model Mapper------------------------

	private LockerAccess dtoToAccess(LockerAccessDTO dto) {
		LockerAccess access = this.modelMapper.map(dto, LockerAccess.class);
		return access;
	}

	private LockerAccessDTO accessToDto(LockerAccess access) {
		LockerAccessDTO dto = new LockerAccessDTO();
		dto.setId(access.getId());
		dto.setCmpCd(access.getCmpCd());
		dto.setCustId(access.getCustomer().getId());
		if (access.getCustomer() != null) {
			dto.setCustId(access.getCustomer().getId());
		} else {
			System.out.println("Customer is null for LockerAccess ID: " + access.getId());
			new ResourceNotFoundException("Customer is null for LockerAccess ID: " + access.getId());
		}
		dto.setLockerId(access.getLocker().getId());
		if (access.getLocker() != null) {
			dto.setLockerId(access.getLocker().getId());
		} else {
			System.out.println("Locker is null for LockerAccess ID: " + access.getId());
			new ResourceNotFoundException("Locker is null for LockerAccess ID: " + access.getId());
		}

		dto.setLockerNo(access.getLocker().getLockerNo());
		dto.setCustomerName(access.getCustomer().getFullName());
		dto.setAccessTimeIn(access.getAccessTimeIn());
		dto.setAccessTimeOut(access.getAccessTimeOut());

		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		String accessTimeInFormatted = dto.getAccessTimeIn() != null
				? dto.getAccessTimeIn().toLocalTime().format(timeFormatter)
				: null;
		String accessTimeOutFormatted = dto.getAccessTimeOut() != null
				? dto.getAccessTimeOut().toLocalTime().format(timeFormatter)
				: null;

		dto.setAccessTimeInFormatted(accessTimeInFormatted);
		dto.setAccessTimeOutFormatted(accessTimeOutFormatted);
		return dto;
	}

// -------------------------------------------------------------------------------------

	public LockerAccessDTO createLockerAccess(LockerAccessDTO dto, String cmpCd) {
		Customer customer = customerRepository.findById(dto.getCustId())
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found", "id", dto.getCustId()));

		Locker locker = lockerRepository.findById(dto.getLockerId())
				.orElseThrow(() -> new ResourceNotFoundException("Locker not found ", "id", dto.getLockerId()));

		LockerAccess access = this.dtoToAccess(dto);
		access.setCustomer(customer);
		access.setLocker(locker);
		access.setAccessTimeIn(LocalDateTime.now());
		LockerAccess savedAccess = this.accessRepository.save(access);
		try {
			String emailSubject = "Locker access notification";
			String emailBody = String.format(
					"Dear %s,\n\nYou have accessed locker no: %s at %s.\n\nThank you,\nLocker Management Team",
					customer.getFullName(), locker.getLockerNo(), access.getAccessTimeIn());
			emailService.sendEmail(customer.getEmailId(), emailSubject, emailBody);

		} catch (Exception e) {
			logger.info("Failed to sent email notification" + e.getMessage());
		}
		return this.accessToDto(savedAccess);
	}

	public List<LockerAccessDTO> getAllLockerAccess() {
		List<LockerAccess> access = this.accessRepository.findAll();
		List<LockerAccessDTO> accessDTOs = access.stream().map(acc -> this.accessToDto(acc))
				.collect(Collectors.toList());
		return accessDTOs;
	}

	public LockerAccessDTO getLockerAccessById(Long id) {
		LockerAccess accessDTO = this.accessRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker access", "id", id));
		return this.accessToDto(accessDTO);
	}

	public LockerAccessDTO updateLockerAccess(LockerAccessDTO dto, Long id) {
		LockerAccess access = accessRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker access", "id", id));
		if (dto.getCustId() != null) {
			Customer customer = customerRepository.findById(dto.getCustId())
					.orElseThrow(() -> new ResourceNotFoundException("Customer not found", "id", dto.getCustId()));
			access.setCustomer(customer);
		}
		if (dto.getLockerId() != null) {
			Locker locker = lockerRepository.findById(dto.getLockerId())
					.orElseThrow(() -> new ResourceNotFoundException("Locker not found", "id", dto.getLockerId()));
			access.setLocker(locker);
		}
		if (dto.getAccessTimeIn() != null) {
			access.setAccessTimeIn(dto.getAccessTimeIn());
		}
		if (dto.getAccessTimeOut() != null) {
			access.setAccessTimeOut(dto.getAccessTimeOut());
		}
		access = accessRepository.save(access);
		return this.accessToDto(access);
	}

	public void deleteLockerAccess(Long id) {
		LockerAccess access = this.accessRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker access", "id", id));
		this.accessRepository.delete(access);
	}

	public Map<String, Object> getTodayAccessDetails() {
		List<LockerAccess> accessRecords = accessRepository.findTodayAccessDetails();

		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

		List<LockerAccessDTO> accessDetails = accessRecords.stream().map(record -> {
			String accessTimeInFormatted = record.getAccessTimeIn() != null
					? record.getAccessTimeIn().toLocalTime().format(timeFormatter)
					: null;
			String accessTimeOutFormatted = record.getAccessTimeOut() != null
					? record.getAccessTimeOut().toLocalTime().format(timeFormatter)
					: null;

			return new LockerAccessDTO(record.getId(), record.getCmpCd(),
					record.getCustomer() != null ? record.getCustomer().getId() : null,
					record.getLocker() != null ? record.getLocker().getId() : null,
					record.getLocker() != null ? record.getLocker().getLockerNo() : null,
					record.getCustomer() != null ? record.getCustomer().getFullName() : null,
					record.getAccessTimeIn() != null ? record.getAccessTimeIn() : null,
					record.getAccessTimeOut() != null ? record.getAccessTimeOut() : null, accessTimeInFormatted,
					accessTimeOutFormatted);
		}).collect(Collectors.toList());

		long totalAccessCount = accessRepository.countTodayAccessDetails();
		Map<String, Object> response = new HashMap<>();
		response.put("totalAccessCount", totalAccessCount);
		response.put("accessDetails", accessDetails);
		return response;
	}

	public List<LockerAccessDTO> getAccessRecordsBetweenDates(LocalDate fromDate, LocalDate toDate) {
		List<LockerAccess> accessRecords = accessRepository.findAllByAccessTimeBetween(fromDate, toDate);
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		return accessRecords.stream().map(record -> {
			String accessTimeInFormatted = record.getAccessTimeIn() != null
					? record.getAccessTimeIn().toLocalTime().format(timeFormatter)
					: null;
			String accessTimeOutFormatted = record.getAccessTimeOut() != null
					? record.getAccessTimeOut().toLocalTime().format(timeFormatter)
					: null;

			String accessTimeInDate = record.getAccessTimeIn() != null
					? record.getAccessTimeIn().toLocalDate().format(dateFormatter)
					: null;
			String accessTimeOutDate = record.getAccessTimeOut() != null
					? record.getAccessTimeOut().toLocalDate().format(dateFormatter)
					: null;

			return new LockerAccessDTO(record.getId(), record.getCmpCd(),
					record.getCustomer() != null ? record.getCustomer().getId() : null,
					record.getLocker() != null ? record.getLocker().getId() : null,
					record.getLocker() != null ? record.getLocker().getLockerNo() : null,
					record.getCustomer() != null ? record.getCustomer().getFullName() : null,
					record.getAccessTimeIn() != null ? record.getAccessTimeIn() : null,
					record.getAccessTimeOut() != null ? record.getAccessTimeOut() : null, accessTimeInFormatted,
					accessTimeOutFormatted, accessTimeInDate, accessTimeInDate);
		}).collect(Collectors.toList());
	}

	public LockerAccess checkLockerAccessById(Long id) {
		return accessRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker access", "id", id));
	}

//	 @Scheduled(fixedRate = 10000) 
//	 public void checkLockerAccessTime() {
//	        List<LockerAccess> allAccess = accessRepository.findAll();
//	        
//	        for (LockerAccess access : allAccess) {
//	            if (access.getAccessTimeIn() != null) {
//	                LocalDateTime currentTime = LocalDateTime.now();
//	                Duration duration = Duration.between(access.getAccessTimeIn(), currentTime);
//	                long minutes = duration.toMinutes();
// 	                
//	                if (minutes >= 2 && minutes < 3) {
//	                	 System.out.println("Access time exceeded 2 minutes for locker no " + access.getLocker().getLockerNo());
//	    			} else if (minutes >= 3 && minutes < 5) {
//	    				 System.out.println("Access time exceeded 3 minutes for locker no " + access.getLocker().getLockerNo());
//	    			} else if (minutes >= 5) {
//	    				 System.out.println("Access time exceeded 5 minutes for locker no " + access.getLocker().getLockerNo());
//	    			}
//	                
//	            }
//	        }
//	    }

}
