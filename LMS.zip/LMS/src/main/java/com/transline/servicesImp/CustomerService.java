package com.transline.servicesImp;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.transline.AuthUtils;
import com.transline.EncryptionUtil;
import com.transline.dtos.CustomerDTO;
import com.transline.dtos.FileObject;
import com.transline.dtos.LockerDTO;
import com.transline.dtos.NewCustomerDTO;
import com.transline.dtos.NewFileDTO;
import com.transline.dtos.UploadsDto;
import com.transline.entities.Customer;
import com.transline.entities.Locker;
import com.transline.entities.UploadedFile;
import com.transline.exceptions.DataNotSave;
import com.transline.exceptions.DuplicateEntryException;
import com.transline.exceptions.DuplicatePanOrAadharException;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.CustomerRepository;
import com.transline.repositories.UploadsRepository;
import com.transline.security.User;

import jakarta.servlet.ServletContext;
import jakarta.transaction.Transactional;
import jakarta.validation.ConstraintViolationException;

@Service
public class CustomerService {
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);
	
    private static final String UPLOAD_DIR ="C:/uploads/";
      
    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private UploadedFileServiceImpl uploadedFileService;

    @Autowired
	private OfficeService officeService;
    
    @Autowired
    private ModelMapper modelMapper;

// --------------------------- Model Mapper -----------------------------

	private Customer dtoToCustomer(CustomerDTO dto) {
		Customer customer = this.modelMapper.map(dto, Customer.class);
		return customer;
	}

	private Customer dtoToCustomer(String cmpCd, NewCustomerDTO dto) {
		Customer customer = new Customer();
		customer.setCmpCd(cmpCd);
		customer.setOffCd(dto.getOffCd());
		customer.setFullName(dto.getFullName());
		customer.setFatherName(dto.getFatherName());
		customer.setGender(dto.getGender());
		customer.setMaritalStatus(dto.getMaritalStatus());
		customer.setCurrentAddress(dto.getCurrentAddress());
		customer.setPermanentAddress(dto.getPermanentAddress());
		customer.setEmailId(dto.getEmailId());
		customer.setContactNo(dto.getContactNo());
		customer.setPanNo(dto.getPanNo());
		customer.setAdharNo(dto.getAdharNo());
		customer.setAccountNo(dto.getAccountNo());
		customer.setCurrentAddress(dto.getCurrentAddress());
		customer.setPermanentAddress(dto.getPermanentAddress());
	//	customer.setAllocatedLockerNo(dto.getAllocatedLockerNo());
		return customer;
	}

	private CustomerDTO customerToDto(Customer customer) {
		CustomerDTO dto = new CustomerDTO();
		dto.setId(customer.getId());
		dto.setCmpCd(customer.getCmpCd());
		dto.setOffCd(customer.getOffCd());
		dto.setFullName(customer.getFullName());
		dto.setFatherName(customer.getFatherName());
		dto.setGender(customer.getGender());
		dto.setMaritalStatus(customer.getMaritalStatus());
		dto.setPanNo(customer.getPanNo());
		dto.setAdharNo(customer.getAdharNo());
		dto.setContactNo(customer.getContactNo());
		dto.setEmailId(customer.getEmailId());
		dto.setAccountNo(customer.getAccountNo());
		dto.setCurrentAddress(customer.getCurrentAddress());
		dto.setPermanentAddress(customer.getPermanentAddress());
	//	dto.setAllocatedLockerNo(customer.getAllocatedLockerNo());
		return dto;
	}

// --------------------------------------- --------------------------
   
//	public boolean checkForDuplicatePanOrAadhar(String panNo, String adharNo) {
//	    boolean isPanDuplicate = customerRepository.existsByPanNo(panNo);//T
//	    boolean isAadharDuplicate = customerRepository.existsByAdharNo(adharNo);//F
//	    return isPanDuplicate || isAadharDuplicate;
//	   // T || F = T
//	}

    public CustomerDTO createCustomer(String cmpCd, NewCustomerDTO dto) {
    	Customer customer = this.dtoToCustomer(cmpCd, dto);
    	User user=AuthUtils.getCurrentUser();
    	String encryptedPanNo = EncryptionUtil.encrypt2(customer.getPanNo());
    	String encryptedAdharNo = EncryptionUtil.encrypt2(customer.getAdharNo());
    	logger.info("encryptedPanNo"+encryptedPanNo);
        if (customerRepository.existsByCmpCdAndPanNo(user.getCmpCd(), encryptedPanNo)) {
            throw new DuplicateEntryException("PAN number already exists.");
        }
        if (customerRepository.existsByCmpCdAndAdharNo(user.getCmpCd(), encryptedAdharNo)) {
            throw new DuplicateEntryException("Aadhaar number already exists.");
        }
        
        try {
        Customer savedCustomer = this.customerRepository.save(customer);     
        List<NewFileDTO> files = new ArrayList<>();
        files.add(new NewFileDTO("photo", dto.getPhoto()));
        files.add(new NewFileDTO("signature", dto.getSignature()));
        files.add(new NewFileDTO(dto.getIdProofType(), dto.getIdProofFile()));
        files.add(new NewFileDTO(dto.getAddressProofType(), dto.getAddressProofFile()));
        
        int savedFileCount = this.uploadedFileService.saveFiles(cmpCd, String.valueOf(savedCustomer.getId()), "Customer", files);
        if (savedFileCount != files.size()) {
            throw new DataNotSave("Error while saving File");
        }
        return this.customerToDto(savedCustomer);
        }catch (ConstraintViolationException e) {
            throw new DuplicateEntryException("Duplicate data error: " + e.getConstraintViolations());
        }
    }

 
	public List<CustomerDTO> getAllCustomer() {
		User user = AuthUtils.getCurrentUser();
		List<Customer> customers = this.customerRepository.findAll();
		Map<String, String> offices = officeService.getOfficesMap(user.getCmpCd(), user.getOffCd());

		return customers.stream().map(customer -> {
			CustomerDTO dto = customerToDto(customer);
			String offCd = customer.getOffCd();
			if (offCd != null) {
				String offName = offices.get(dto.getOffCd());
				dto.setOffName(offName);
			} else {
				logger.warn("Customer with null offCd: {}", customer);
				dto.setOffName(null);
			}
			return dto;
		}).collect(Collectors.toList());
	}
    
    



	public CustomerDTO getCustomerById(Long id) {
		Customer customer = this.customerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer", "id", id));

		CustomerDTO dto = this.customerToDto(customer);
		User user = AuthUtils.getCurrentUser();
		Map<String, String> offices = officeService.getOfficesMap(user.getCmpCd(), user.getOffCd());
		logger.info("Offices map: {}", offices);

		String offCd = customer.getOffCd();
		if (offCd != null) {
			String offName = offices.get(offCd);
			dto.setOffName(offName);
		} else {
			logger.warn("Customer with null offCd: {}", customer);
			dto.setOffName(null);
		}
		return dto;
	}
     

	public CustomerDTO updateCustomer(CustomerDTO dto, Long id) {
		Customer customer = this.customerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer", "id", id));
		customer.setOffCd(dto.getOffCd());
		customer.setFullName(dto.getFullName());
		customer.setGender(dto.getGender());
		customer.setMaritalStatus(dto.getMaritalStatus());
		customer.setPanNo(dto.getPanNo());
		customer.setAdharNo(dto.getAdharNo());
		customer.setContactNo(dto.getContactNo());
		customer.setEmailId(dto.getEmailId());
		customer.setAccountNo(dto.getAccountNo());
		customer = customerRepository.save(customer);
		return this.customerToDto(customer);
	}

	public void deleteCustomer(Long id) {
		Customer customer = this.customerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer", "id", id));
		this.customerRepository.delete(customer);
	}

	public List<CustomerDTO> getCustomerByContactNo(String contactNo) {
	    String encryptedContactNo = EncryptionUtil.encrypt2(contactNo);
	    List<Customer> customers = customerRepository.getCustomerByContactNo(
	            AuthUtils.getCurrentUser().getCmpCd(), encryptedContactNo);

	    Map<String, String> offices = officeService.getOfficesMap(
	            AuthUtils.getCurrentUser().getCmpCd(), AuthUtils.getCurrentUser().getOffCd());
	    return customers.stream().map(customer -> {
	        CustomerDTO dto = customerToDto(customer);
	        String offCd = customer.getOffCd();
	        if (offCd != null) {
	            String offName = offices.get(offCd);
	            dto.setOffName(offName);
	        } else {
	            logger.warn("Customer with null offCd: {}", customer);
	            dto.setOffName(null);
	        }
	        return dto;
	    }).collect(Collectors.toList());
	}


	public List<Customer> updateCustomersSensitiveData() {
		List<Customer> list = customerRepository.findAll();
		int count = 0;
		list = list.stream().map(customer -> {
			String email = customer.getEmailId();
			String contactNo = customer.getContactNo();
			String adhar = customer.getAdharNo();
			String pan = customer.getPanNo();

			email = EncryptionUtil.decrypt(email);
			contactNo = EncryptionUtil.decrypt(contactNo);
			adhar = EncryptionUtil.decrypt(adhar);
			pan = EncryptionUtil.decrypt(pan);

			email = EncryptionUtil.encrypt2(email);
			contactNo = EncryptionUtil.encrypt2(contactNo);
			adhar = EncryptionUtil.encrypt2(adhar);
			pan = EncryptionUtil.encrypt2(pan);

			customer.setEmailId(email);
			customer.setAdharNo(adhar);
			customer.setContactNo(contactNo);
			customer.setPanNo(pan);
			return customer;
		}).collect(Collectors.toList());

		return customerRepository.saveAll(list);
	}
	
	public Map<String, Object> getCustomerDetails(String cmpCd, String offCd) {
		List<Customer> customers = customerRepository.findAllByCompanyAndOffice(cmpCd, offCd);
		long totalCustomers = customerRepository.countByCompanyAndOffice(cmpCd, offCd);
		Map<String, Object> response = new HashMap<>();
		response.put("totalCustomers", totalCustomers);
		response.put("customerDetails", customers);
		return response;
	}

}
