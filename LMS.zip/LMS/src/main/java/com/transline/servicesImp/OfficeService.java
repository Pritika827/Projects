package com.transline.servicesImp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Pair;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.transline.AuthUtils;
import com.transline.controllers.AdminController;
import com.transline.dtos.CodeAndNameDTO;
import com.transline.dtos.NewOfficeDTO;
import com.transline.dtos.OfficeDto;
import com.transline.dtos.OfficeListItemDTO;
import com.transline.dtos.OfficeTypeDTO;
import com.transline.dtos.OfficeTypeDetailDTO;
import com.transline.entities.Company;
import com.transline.entities.Login;
import com.transline.entities.Office;
import com.transline.entities.OfficeType;
import com.transline.entities.RoleMst;
import com.transline.entities.ids.OffTypeId;
import com.transline.entities.ids.OfficeId;
import com.transline.enums.Modules;
import com.transline.exceptions.DuplicateOfficeNameException;
import com.transline.exceptions.LockerLocationAlreadyExist;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.CompanyRepository;
import com.transline.repositories.LoginRepository;
import com.transline.repositories.OfficeRepository;
import com.transline.repositories.OfficeTypeRepository;
import com.transline.repositories.RoleRepository;
import com.transline.utils.PasswordGenerator;

import jakarta.mail.MessagingException;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Service
public class OfficeService {

	private static final Logger logger = LoggerFactory.getLogger(OfficeService.class);

	@Autowired
	private OfficeRepository officeRepository;

	@Autowired
	private OfficeTypeRepository officeTypeRepository;

	@Autowired
	private CompanyRepository companyRepository;

	@Autowired
	private LoginRepository loginRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private EmailService emailService;

	@Autowired
	private RoleRepository roleRepository;
// -----------------Model Mapper--------------------------------------------------------------
	@Autowired
	private ModelMapper modelMapper;

//	public Office dtoToOffice(String cmpCd, OfficeDto dto) {
//		OfficeType officeType=officeTypeRepository.findById(new OffTypeId(cmpCd,dto.getOffType()))
//		.orElseThrow(() -> new ResourceNotFoundException("OfficeType", "offType", dto.getOffType()));
//		
//		Office offices = new Office();
//		offices.setCmpCd(AuthUtils.getCurrentUser().getCmpCd());
//		offices.setOffCd(dto.getOffCd());			
//		offices.setOffName(dto.getOffName());
//		offices.setOffType(officeType);
//		offices.setOffAddress(dto.getOffAddress());
//		offices.setCtlCd(dto.getCtlCd());
//		offices.setEmail(dto.getEmail());
//		offices.setPhoneNo(dto.getPhoneNo());
//		offices.setContactPerson(dto.getContactPerson());
//		offices.setDisable(dto.getDisable());
//		offices.setWorkingStatus(dto.getWorkingStatus());
//		offices.setPath(dto.getPath());
//			
//		return offices;
//	}
//
//	public OfficeDto officeToDto(Office office) {
//		OfficeDto officeDto = new OfficeDto();
//		officeDto.setOffCd(office.getOffCd());
//		officeDto.setOffName(office.getOffName());
//		officeDto.setOffType(office.getOffType().getOfficeType());
//		officeDto.setOffAddress(office.getOffAddress());
//		officeDto.setCtlCd(office.getCtlCd());
//		officeDto.setEmail(office.getEmail());
//		officeDto.setPhoneNo(office.getPhoneNo());
//		officeDto.setContactPerson(office.getContactPerson());
//		officeDto.setDisable(office.getDisable());
//		officeDto.setWorkingStatus(office.getWorkingStatus());
//		officeDto.setPath(office.getPath());
//		
//		return officeDto;
//	}

// ---------------------------------------------------------------------------------------------

	public String generateNextOffCd(String cmpCd, String offName) {
		String prefix = offName.substring(0, 2);
		String oldOffCd = officeRepository.getMaxOffCd(cmpCd, prefix);
		if (oldOffCd == null) {
			oldOffCd = prefix + "000";
		}
		String part = oldOffCd.substring(prefix.length());
		String numericPart = String.format("%03d", Integer.parseInt(part) + 1); // Extract numeric part
		return prefix + numericPart;
	}

	public OfficeResponse saveOffice(String cmpCd, NewOfficeDTO dto) {
		if (officeRepository.existsByOffName(dto.getOffName())) {
			throw new IllegalArgumentException("Office name already exists: " + dto.getOffName());
		}
		Office newOffice = new Office();
		BeanUtils.copyProperties(dto, newOffice);
		String offType = dto.getOffType();
		if (offType == null) {
			offType = "HO";
		}
		try {
			logger.info("Searching OfficeType with cmpCd: {} and offType: {}", cmpCd, offType);

			OfficeType officeType = officeTypeRepository.findByCmpCdAndOffType(cmpCd, offType)
					.orElseThrow(() -> new ResourceNotFoundException("OfficeType", "offType", dto.getOffType()));
			Office parentOffice = officeRepository.findByCmpCdAndOffCd(cmpCd, dto.getCtlCd())
					.orElseThrow(() -> new ResourceNotFoundException("Office", "offCd", dto.getCtlCd()));
			newOffice.setOfficeType(officeType);
			String newOffCd = generateNextOffCd(cmpCd, dto.getOffName());
			newOffice.setOffCd(newOffCd);
			newOffice.setCmpCd(cmpCd);
			newOffice.setPath(parentOffice.getPath() + "/" + newOffCd);

			Office savedOffice = officeRepository.save(newOffice);
			List<Login> users = createDefaultUsersForOffice(cmpCd, savedOffice, dto);
			OfficeResponse response = new OfficeResponse();
			response.setOffice(savedOffice);

			// response.setUsers(users);
			Map<String, String> userDetails = new HashMap<>();
			if (users.size() >= 2) {
				Login userA = users.get(0);
				Login userN = users.get(1);
				String roleA = userA.getRoleMst() != null ? userA.getRoleMst().getRoleType() : "No Role";
				String roleN = userN.getRoleMst() != null ? userN.getRoleMst().getRoleType() : "No Role";
				userDetails.put("Authorized User", String.format("( User ID : %s , Password : %s , Roles : %s )",
						userA.getUserName(), userA.getPwd(), roleA));
				userDetails.put("Normal User", String.format("( User ID : %s , Password : %s , Roles : %s )",
						userN.getUserName(), userN.getPwd(), roleN));
			} else {
				logger.error("Not enough users created.");
			}

			response.setUserDetails(userDetails);
			return response;
		} catch (Exception e) {
			logger.error("Error while saving office: " + e.getMessage(), e);
			throw new RuntimeException("Failed to save office");
		}
	}

	private List<Login> createDefaultUsersForOffice(String cmpCd, Office savedOffice, NewOfficeDTO dto) {
		List<Login> users = new ArrayList<>();

		// Create Authorized User (A)
		String userIdA = savedOffice.getOffCd() + 'A';
		String passwordA = dto.getAuPassword();
		if (passwordA == null || passwordA.isEmpty()) {
			passwordA = PasswordGenerator.generatePassword();
		}
		String accessRightAu = "1".repeat(Modules.values().length);
//		RoleMst roleA=new RoleMst();
//		roleA.setCmpCd(cmpCd);
//		roleA.setAccessRights(accessRightAu);
//		roleA.setRoleType("HO_AU");
//		roleA.setRoleDesc("Administrator");
//		roleRepository.save(roleA);

		RoleMst roleA = roleRepository.findByCmpCdAndRoleType(cmpCd, "HO_AU")
				.orElseThrow(() -> new ResourceNotFoundException("RoleMst", cmpCd, "HO_AU"));

		Login userA = new Login();
		userA.setRoleMst(roleA);
		userA.setCmpCd(cmpCd);
		userA.setOffice(savedOffice);
		userA.setPwd(passwordEncoder.encode(passwordA));
		userA.setUserName(userIdA);
		userA.setName(savedOffice.getOffName() + "(AU)");
		// userA.setDefaultUser(true);
		userA.setUserType("A");
		userA.setAccessRights(accessRightAu);
		userA.setStatus("T");
		Login savedUserA = loginRepository.save(userA);
		users.add(savedUserA);

		// Create Normal User (N)
		String userIdN = savedOffice.getOffCd() + 'N';
		String passwordN = dto.getNuPassword();
		if (passwordN == null || passwordN.isEmpty()) {
			passwordN = PasswordGenerator.generatePassword();
		}

		String accessRightNu = accessRightAu.substring(0, 15) + "00" + accessRightAu.substring(17);
//		RoleMst roleN=new RoleMst();
//		roleN.setCmpCd(cmpCd);
//		roleN.setAccessRights(accessRightNu);
//		roleN.setRoleType("HO_NU");
//		roleN.setRoleDesc("Normal");
//		roleRepository.save(roleN);

		RoleMst roleN = roleRepository.findByCmpCdAndRoleType(cmpCd, "HO_NU")
				.orElseThrow(() -> new ResourceNotFoundException("RoleMst", cmpCd, "HO_NU"));

		Login userN = new Login();
		userN.setCmpCd(cmpCd);
		userN.setRoleMst(roleN);
		userN.setOffice(savedOffice);
		userN.setPwd(passwordEncoder.encode(passwordN));
		userN.setUserName(userIdN);
		userN.setName(savedOffice.getOffName() + "(NU)");
		// userN.setDefaultUser(true);
		userN.setUserType("N");
		userN.setAccessRights(accessRightNu);
		userN.setStatus("T");
		Login savedUserN = loginRepository.save(userN);
		users.add(savedUserN);
		return users;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class OfficeResponse {
		private Office office;
		// private List<Login> users;
		private Map<String, String> userDetails;
	}

	public List<Office> getAllOffices(String cmpCd) {
		return this.officeRepository.findByCmpCd(cmpCd);
	}

	public Office getOfficeById(Long offId) {
		Office office = this.officeRepository.findById(offId)
				.orElseThrow(() -> new ResourceNotFoundException("Office", "offId", offId));
		return office;
	}

	public Office updateOfficeDto(Long offId, OfficeDto officeDto) {
		if (officeRepository.existsByOffName(officeDto.getOffName())) {
			throw new IllegalArgumentException("Office name already exists: " + officeDto.getOffName());
		}
		Office office = this.officeRepository.findById(offId)
				.orElseThrow(() -> new ResourceNotFoundException("office", "offCd", offId));
		office.setOffName(officeDto.getOffName());
		office.setOffAddress(officeDto.getOffAddress());
		office.setCtlCd(officeDto.getCtlCd());
		office.setEmail(officeDto.getEmail());
		office.setPhoneNo(officeDto.getPhoneNo());
		office.setContactPerson(officeDto.getContactPerson());
		office.setDisable(officeDto.getDisable());
		office.setWorkingStatus(officeDto.getWorkingStatus());
		office = officeRepository.save(office);
		return office;
	}

	public Office getOfficeByOffCd(String cmpCd, String offCd) {
		return this.officeRepository.findByCmpCdAndOffCd(cmpCd, offCd)
				.orElseThrow(() -> new ResourceNotFoundException("office", "offCd", offCd));
	}

	public void deleteOffice(Long offId) {
		// dont delete but change the office status to disabled
	}

	private List<Map<String, Object>> processOfficeList(String cmpCd, String offCd, boolean fetchName,
			List workingStatusTypes) {
		List<Map<String, Object>> officeList = new ArrayList<>();
		if (fetchName) {
			List<Object[]> objectlist = officeRepository.getOfficeHierarchyDetail(cmpCd, offCd, workingStatusTypes);
			objectlist.stream().forEach(arr -> {
				HashMap<String, Object> row = new HashMap<>();
				row.put("offCd", arr[0]);
				row.put("offName", arr[1]);
				row.put("offType", arr[2]);
				row.put("offTypeDesc", arr[3]);
				row.put("workingStatus", arr[4]);
				String workingStatus = (String) arr[4];
				switch (workingStatus) {
				case "RO":
					workingStatus = "Reporting Office";
					break;
				case "WO":
					workingStatus = "Working Office";
					break;
				case "RWO":
					workingStatus = "Reporting Working Office";
					break;
				}
				row.put("workingStatusName", workingStatus);
				row.put("ctlCd", arr[5]);
				row.put("ctlName", arr[6]);
				officeList.add(row);
			});
		} else {
			List<Object[]> objectlist = officeRepository.getOfficeHierarchyCodeAndName(cmpCd, offCd,
					workingStatusTypes);
			objectlist.stream().forEach(arr -> {
				HashMap<String, Object> row = new HashMap<>();
				row.put("offCd", arr[0]);
				row.put("offName", arr[1]);
				officeList.add(row);
			});
		}
		return officeList;
	}

	public List<Map<String, Object>> getAllOfficesList(String cmpCd, String offCd) {
		return processOfficeList(cmpCd, offCd, false, List.of("RWO", "RO", "WO"));
	}

	public List<Map<String, Object>> getOfficesList(String cmpCd, String offCd) {
		return processOfficeList(cmpCd, offCd, false, List.of("RWO", "RO"));
	}

	public List<Map<String, Object>> getWorkingOfficesList(String cmpCd, String offCd) {
		return processOfficeList(cmpCd, offCd, false, List.of("RWO", "WO"));
	}

	public List<OfficeListItemDTO> getOfficeListReport(String cmpCd, String offCd) {
		return officeRepository.getOfficeListReport(cmpCd, offCd, List.of("RWO", "WO"));
	}

	public List<String> getOfficeCodes(String cmpCd, String offCd) {
		return officeRepository.getOfficeHierarchyCode(cmpCd, offCd, List.of("RO", "RWO"));
	}

	public Map<String, String> getOfficesMap(String cmpCd, String offCd) {
		Map<String, String> map = new HashMap();
		officeRepository.getAllOfficeCodeAndName(cmpCd).stream().forEach(arr -> map.put(arr[0], arr[1]));
		return map;
	}

	public List<OfficeTypeDetailDTO> getOfficeTypeDetails(String cmpCd) {
		List<Object[]> officeDetails = officeRepository.findOfficeDetailsByCmpCd(cmpCd);

		return officeDetails.stream().map(result -> new OfficeTypeDetailDTO((Long) result[0], // id
				(String) result[1], // offCd
				(String) result[2], // offName
				(String) result[3] // officeType
		)).collect(Collectors.toList());
	}

}
