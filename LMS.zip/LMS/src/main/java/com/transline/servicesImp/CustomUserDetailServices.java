package com.transline.servicesImp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import com.transline.entities.Login;
import com.transline.repositories.LoginRepository;
import com.transline.security.User;

@Service
public class CustomUserDetailServices implements UserDetailsService {

	private Logger logger = LoggerFactory.getLogger(CustomUserDetailServices.class);

	@Autowired
	private LoginRepository loginRepository;

	@Autowired
	private ModuleMstServiceImpl moduleMstService;

	@Override
	public UserDetails loadUserByUsername(String usernameToken) throws UsernameNotFoundException {
		logger.info(usernameToken);
		String cmpCd = usernameToken.split("::")[0];
		String userName = usernameToken.split("::")[1];

		Login login = loginRepository.findByCmpCdAndUserName(cmpCd, userName);
		if (login == null) {
			throw new UsernameNotFoundException("User not found with userName: " + userName + " and cmpCd: " + cmpCd);
		}
		String modAccessRights = moduleMstService.getModAccessRights(cmpCd);
		return new User(login, modAccessRights);
	}

}
