package com.transline.servicesImp;

import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.AuthUtils;
import com.transline.dtos.LockerTypePricesDTO;
import com.transline.entities.LockerType;
import com.transline.entities.LockerTypePrices;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.LockerTypePricesRepository;
import com.transline.repositories.LockerTypeRepository;

@Service
public class LockerTypePricesService {

	private static final Logger logger = LoggerFactory.getLogger(LockerTypePricesService.class);

	@Autowired
	private LockerTypePricesRepository lockerTypePricesRepository;

	@Autowired
	private LockerTypeRepository lockerTypeRepository;

	@Autowired
	private ModelMapper modelMapper;

	private LockerTypePrices dtoToDtls(LockerTypePricesDTO dtlsDTO) {
		LockerTypePrices lockerTypeDtls = this.modelMapper.map(dtlsDTO, LockerTypePrices.class);
		return lockerTypeDtls;
	}

	private LockerTypePricesDTO dtlsToDto(LockerTypePrices typeDtls) {
		LockerTypePricesDTO dtlsDTO = modelMapper.map(typeDtls, LockerTypePricesDTO.class);
		return dtlsDTO;
	}

	public LockerTypePricesDTO createLockerTypeDtls(LockerTypePricesDTO dtlsDTO, String cmpCd) {
		LockerTypePrices typeDtls = this.dtoToDtls(dtlsDTO);
		typeDtls.setCmpCd(cmpCd);
		LockerTypePrices saveDtls = this.lockerTypePricesRepository.save(typeDtls);
		return this.dtlsToDto(typeDtls);
	}

	public List<LockerTypePricesDTO> getAllLokerType() {
		List<LockerTypePrices> typeDtls = this.lockerTypePricesRepository.findAll();
		List<LockerTypePricesDTO> typeDtlsDTOs = typeDtls.stream().map(dtls -> this.dtlsToDto(dtls))
				.collect(Collectors.toList());
		return typeDtlsDTOs;
	}

	public LockerTypePricesDTO getLockerTypeDtlsById(Long id) {
		LockerTypePrices typeDtls = this.lockerTypePricesRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker type details", "id", id));
		return this.dtlsToDto(typeDtls);
	}

	public LockerTypePricesDTO updatedLockerTypeDtls(LockerTypePricesDTO dtlsDTO, Long id) {
		LockerTypePrices typeDtls = this.lockerTypePricesRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker type details", "id", id));
		typeDtls.setStartDate(dtlsDTO.getStartDate());
		typeDtls.setEndDate(dtlsDTO.getEndDate());
		// typeDtls.setLockerType(dtlsDTO.getLockerTypeId());

		LockerType lockerType = lockerTypeRepository.findById(dtlsDTO.getLockerTypeId())
				.orElseThrow(() -> new ResourceNotFoundException("Locker type", "id", dtlsDTO.getLockerTypeId()));
		typeDtls.setLockerType(lockerType);
		typeDtls.setRentForUrban(dtlsDTO.getRentForUrban());
		typeDtls.setRentForRural(dtlsDTO.getRentForRural());
		typeDtls.setRegFee(dtlsDTO.getRegFee());

		return this.dtlsToDto(typeDtls);
	}

	public void deleteLockertypeDtls(Long id) {
		LockerTypePrices lockerTypeDtls = lockerTypePricesRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Locker type details", "id", id));
		this.lockerTypePricesRepository.delete(lockerTypeDtls);
	}

	public LockerTypePricesDTO getCurrentPrices(Long lockerTypeId) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		List<LockerTypePrices> list = lockerTypePricesRepository.getCurrentPrices(cmpCd, lockerTypeId);

		if (list.isEmpty()) {
			throw new ResourceNotFoundException("Locker Prices Not Found for given lockerType");
		}
        LockerTypePrices latestPrice = list.get(list.size() - 1);
        return new LockerTypePricesDTO(
        		latestPrice.getId(),
        		latestPrice.getLockerType().getId(),
        		latestPrice.getRentForUrban(),
        		latestPrice.getRentForRural(),
        		latestPrice.getRegFee(),
        		latestPrice.getStartDate(),
        		latestPrice.getEndDate()         
        );
    }
}
