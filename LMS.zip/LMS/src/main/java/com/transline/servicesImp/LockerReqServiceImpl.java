package com.transline.servicesImp;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.transline.AuthUtils;
import com.transline.dtos.CustomerDTO;
import com.transline.dtos.LockerAccessDTO;
import com.transline.dtos.LockerReqDTO;
import com.transline.dtos.LockerTypeDetailsDTO;
import com.transline.entities.Locker;
import com.transline.entities.LockerAccess;
import com.transline.entities.LockerReq;
import com.transline.entities.LockerType;
import com.transline.enums.LockerStatus;
import com.transline.exceptions.DuplicateEntryException;
import com.transline.exceptions.EmailDeliveryException;
import com.transline.exceptions.LockerLocationAlreadyExist;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.LockerRepository;
import com.transline.repositories.LockerReqRepository;
import com.transline.repositories.LockerTypeRepository;
import com.transline.security.User;

import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class LockerReqServiceImpl {

	private static final Logger logger = LoggerFactory.getLogger(LockerReqServiceImpl.class);

	@Autowired
	private LockerReqRepository reqRepository;

	@Autowired
	private LockerTypeRepository lockerTypeRepository;

	@Autowired
	private EmailService emailService;

	@Autowired
	private LockerRepository lockerRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private OfficeService officeService;

	@Autowired
	private LockerTypeService lockerTypeService;

// ----------------------------------Model Mapper------------------------

	private LockerReq dtoToReq(LockerReqDTO dto) {
		LockerReq lockerReq = this.modelMapper.map(dto, LockerReq.class);
		return lockerReq;
	}

	private LockerReqDTO reqToDto(LockerReq lockerReq) {
		LockerReqDTO dto = modelMapper.map(lockerReq, LockerReqDTO.class);
		return dto;
	}
// -----------------------------------------------------------------------

	public LockerReqDTO createLockerReq(LockerReqDTO dto, String cmpCd) {
		LockerReq lockerReq = this.dtoToReq(dto);
		if (dto.getLockerTypeId() != null) {
			LockerType lockerType = lockerTypeRepository.findById(dto.getLockerTypeId())
					.orElseThrow(() -> new IllegalArgumentException("Invalid LockerType ID: " + dto.getLockerTypeId()));
			lockerReq.setLockerType(lockerType);
		} else {
			throw new IllegalArgumentException("LockerType ID cannot be null");
		}

		String emailSubject = "Locker Request Submitted";
		String emailMessage = String.format(
				"Dear %s,\n\nYour locker request has been successfully submitted. "
						+ "We will notify you as soon as a locker becomes available.\n\nThank you!",
				lockerReq.getFullName());

		try {
			emailService.sendEmail(dto.getEmailId(), emailSubject, emailMessage);
		} catch (MailException e) {
			String errorMsg = "Failed to send email to " + dto.getEmailId()
					+ ". The email address may be incorrect or unreachable.";
			throw new EmailDeliveryException(errorMsg, e);
		}

		LockerReq savedReq = this.reqRepository.save(lockerReq);
		// notifyUsersOnLockerAvailability(dto.getLockerTypeId());
		return this.reqToDto(savedReq);
	}

	public void notifyUsersOnLockerAvailability(Long lockerTypeId) {
		long availableLockersCount = lockerRepository.countAvailableLockers(lockerTypeId);
		System.out.println("Available lockers count for lockerTypeId " + lockerTypeId + ": " + availableLockersCount);

		// if (availableLockersCount > 0) {
		List<LockerReq> pendingRequests = reqRepository.findAll();
		for (LockerReq request : pendingRequests) {
			if (availableLockersCount > 0) {
				// Locker locker = lockerRepository.findFirstAvailableLocker(lockerTypeId);
				String emailSubject = "Locker Availability Notification";
				String emailMessage = String.format(
						"Dear %s,\n\nWe are happy to inform you, that according to your request. "
								+ "we have %s available locker. Please book your locker\n\nThank you!",
						request.getFullName(), availableLockersCount);
				try {
					emailService.sendEmail(request.getEmailId(), emailSubject, emailMessage);
				} catch (MailException e) {
					String errorMsg = "Failed to send email to " + request.getEmailId()
							+ ". The email address may be incorrect or unreachable.";
					throw new EmailDeliveryException(errorMsg, e);
				}
				// availableLockersCount--;
				reqRepository.save(request);
			} else {

				String emailSubject = "Locker Availability Notification";
				String emailMessage = String.format(
						"Dear %s,\n\nWe are regret to inform you,We do not have available locker for %s size."
								+ "If we have,we will notify you.\n\nThank you!",
						request.getFullName(), request.getLockerType().getType());
				try {
					emailService.sendEmail(request.getEmailId(), emailSubject, emailMessage);
				} catch (MailException e) {
					String errorMsg = "Failed to send email to " + request.getEmailId()
							+ ". The email address may be incorrect or unreachable.";
					throw new EmailDeliveryException(errorMsg, e);
				}
				reqRepository.save(request);
			}
		}
	}

	public List<LockerReqDTO> findAllLockerReqs() {
		List<LockerReq> reqRecords = reqRepository.findAll();
		User user = AuthUtils.getCurrentUser();
		Map<String, String> offices = officeService.getOfficesMap(user.getCmpCd(), user.getOffCd());
		Map<Long, String> lockerTypes = lockerTypeService.getLockerType(user.getCmpCd());

		return reqRecords.stream().map(record -> {
			LockerReqDTO dto = reqToDto(record);
			String offCd = record.getOffCd();
			if (offCd != null) {
				String offName = offices.get(dto.getOffCd());
				String lockerType = lockerTypes.get(dto.getLockerTypeId());
				dto.setOffName(offName);
				dto.setLockerType(lockerType);
			} else {
				logger.warn("Customer with null offCd: {}", record);
				dto.setOffName(null);
			}
			return dto;
		}).collect(Collectors.toList());

	}

	public List<LockerReqDTO> findAllByAccessTimeBetween(LocalDate fromDate, LocalDate toDate) {
		List<LockerReq> reqRecords;
		if (fromDate != null && toDate != null) {
			reqRecords = reqRepository.findAllByReqDateBetween(fromDate, toDate);
		} else {
			if (fromDate != null) {
				reqRecords = reqRepository.findAllByReqDateAfter(fromDate);
			} else if (toDate != null) {
				reqRecords = reqRepository.findAllByReqDateBefore(toDate);
			} else {
				reqRecords = reqRepository.findAll();
			}
		}
		User user = AuthUtils.getCurrentUser();
		Map<String, String> offices = officeService.getOfficesMap(user.getCmpCd(), user.getOffCd());
		Map<Long, String> lockerTypes = lockerTypeService.getLockerType(user.getCmpCd());

		return reqRecords.stream().map(record -> {
			LockerReqDTO dto = reqToDto(record);

			String offCd = record.getOffCd();
			if (offCd != null) {
				String offName = offices.get(dto.getOffCd());
				String lockerType = lockerTypes.get(dto.getLockerTypeId());
				dto.setOffName(offName);
				dto.setLockerType(lockerType);
			} else {
				logger.warn("Customer with null offCd: {}", record);
				dto.setOffName(null);
			}
			return dto;
		}).collect(Collectors.toList());

	}

}
