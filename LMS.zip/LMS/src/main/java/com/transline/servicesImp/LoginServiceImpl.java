package com.transline.servicesImp;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.transline.AuthUtils;
import com.transline.controllers.AdminController;
import com.transline.dtos.LockerAccessDTO;
import com.transline.dtos.LoginDTO;
import com.transline.dtos.NewCompanyDTO;
import com.transline.entities.Customer;
import com.transline.entities.LockerAccess;
import com.transline.entities.Login;
import com.transline.entities.Office;
import com.transline.entities.PasswordHistory;
import com.transline.entities.RoleMst;
import com.transline.entities.ids.LoginId;
import com.transline.enums.Modules;
import com.transline.exceptions.DataNotSave;
import com.transline.exceptions.DuplicateEntryException;
import com.transline.exceptions.EmailDeliveryException;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.LoginRepository;
import com.transline.repositories.OfficeRepository;
import com.transline.repositories.PasswordHistoryRepository;
import com.transline.repositories.RoleRepository;
import com.transline.utils.PasswordGenerator;

@Service
public class LoginServiceImpl {

	private static final Logger logger = LoggerFactory.getLogger(LoginServiceImpl.class);

	@Autowired
	private LoginRepository loginRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private OfficeRepository officeRepository;
	
	@Autowired
	private PasswordHistoryRepository historyRepository;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private ModelMapper modelMapper;
	
	private Login dtoToLogin(LoginDTO dto) {
		Login login = this.modelMapper.map(dto, Login.class);
		return login;
	}

	private LoginDTO loginToDto(Login login) {
		LoginDTO dto = new LoginDTO();
		
		dto.setId(login.getId());
		dto.setCmpCd(login.getCmpCd());
		dto.setUserName(login.getUserName());
		dto.setName(login.getName());
		dto.setPwd(login.getPwd());
		dto.setStatus(login.getStatus());
		dto.setOfficeId(login.getOffice().getId());
		if(login.getOffice() != null) {
			dto.setOfficeId(login.getOffice().getId());
		}else {
			new ResourceNotFoundException("Office not found with id:"+login.getOffice().getId());
		}
		dto.setDisabled(login.isDisabled());
		dto.setBlocked(login.isBlocked());
		dto.setBlocked(login.isBlocked());
		dto.setCredentialExpired(login.isCredentialExpired());
		dto.setRoleId(login.getRoleMst().getId());
		if(login.getRoleMst() != null) {
			dto.setRoleId(login.getRoleMst().getId());
		}else {
			new ResourceNotFoundException("Role not found with id:"+login.getRoleMst().getId());
		}		
		dto.setAccessRights(login.getAccessRights());
		dto.setEmail(login.getEmail());
		dto.setMobileNo(login.getMobileNo());
		dto.setPasswordUpdatedDate(login.getPasswordUpdatedDate());
		return dto;
	}


	public LoginDTO createLogin(LoginDTO dto,String cmpCd) {
		Office office = officeRepository.findById(dto.getOfficeId())
		        .orElseThrow(() -> new ResourceNotFoundException("Office id", "id", dto.getOfficeId()));

		RoleMst roleMst = roleRepository.findById(dto.getRoleId())
				.orElseThrow(() -> new ResourceNotFoundException("Role id", "id", dto.getRoleId()));

		if (dto.getOfficeId() == null) {
		    throw new IllegalArgumentException("Office ID is required and cannot be null"+dto.getOfficeId());
		}
		if (dto.getRoleId() == null) {
		    throw new IllegalArgumentException("Role ID is required and cannot be null"+dto.getRoleId());
		}
		
	    if (loginRepository.existsByEmail(dto.getEmail())) {
	        throw new IllegalArgumentException("Email already exists: " + dto.getEmail());
	    }

	    if (loginRepository.existsByMobileNo(dto.getMobileNo())) {
	        throw new IllegalArgumentException("Mobile number already exists: " + dto.getMobileNo());
	    }
		Login login = this.dtoToLogin(dto);	
		
		String userType = dto.getUserType();
		String prefix = (dto.getName() != null && dto.getName().length() >= 2)
		                ? dto.getName().substring(0, 2).toUpperCase()
		                : dto.getName().toUpperCase();
		String baseUId = prefix + "001"; 
		logger.info("Initial baseUId is: " + baseUId);

		int counter = 1;
		boolean exists = loginRepository.existsByUserName(baseUId);
		logger.info("Exists check for " + baseUId + ": " + exists);

		while (exists) {
		    counter++;
		    baseUId = prefix + String.format("%03d", counter);
		    exists = loginRepository.existsByUserName(baseUId);
		    logger.info("Updated baseUId is: " + baseUId);
		}

		String uId = baseUId; 
		logger.info("Final uId is: " + uId);
		String userId="";
		if (userType.equals("AUTHORIZED")) {
			 userId = uId + "A";
			login.setUserName(userId);
			String accessRight = dto.getAccessRights() != null ? dto.getAccessRights()
					: "1".repeat(Modules.values().length);
			login.setAccessRights(accessRight);
		} else if (userType.equals("NORMAL")) {
			 userId = uId + "N";
			login.setUserName(userId);
			String accessRight = dto.getAccessRights() != null ? dto.getAccessRights()
					: "1".repeat(Modules.values().length).substring(13) + "0"
							+ "1".repeat(Modules.values().length - 17);
			login.setAccessRights(accessRight);
		} else if (userType.equals("WEBUSER")) {
			 userId = uId + "W";
			login.setUserName(userId);
			String accessRight = dto.getAccessRights() != null ? dto.getAccessRights()
					: "0".repeat(Modules.values().length);
			login.setAccessRights(accessRight);
		}
		login.setUserName(userId);
		login.setName(dto.getName());
		String password = dto.getPwd();
	    if (password == null || password.isEmpty()) {
	        password = PasswordGenerator.generatePassword();
	    } else {
	        if (!password.equals(dto.getConfirmPwd())) {
	            throw new IllegalArgumentException("Password and Confirm Password do not match");
	        }
	    }
	    login.setPwd(passwordEncoder.encode(password));
		login.setStatus("T");		
		login.setOffice(office);
		login.setUserType(userType);
		login.setRoleMst(roleMst);
		login.setEmail(dto.getEmail());
		login.setMobileNo(dto.getMobileNo());
		login.setCustodianName(dto.getCustodianName());
		
	    if (loginRepository.existsByUserName(dto.getUserName())) {
	        throw new IllegalArgumentException("UserName already exists: " + dto.getUserName());
	    }
	    
	    try {
		String emailSubject = "User Password notification";
		String emailBody = String.format(
				"Dear %s,\n\n your company code is %s"
				+ "\n\nYour password is %s"
				+ "and your userId is %s\n\nThank you,\nLocker Management Team",
				dto.getName(),dto.getCmpCd(), password,userId);
		emailService.sendEmail(dto.getEmail(), emailSubject, emailBody);
	    }catch (MailException e) {
			throw new DataNotSave("mail not sent");
		}
	    
		Login savedUser = this.loginRepository.save(login);
		savedUser.setPwd(password);
		return this.loginToDto(savedUser);
	}	

	public LoginDTO changePassword(String cmpCd, String email, String newPassword) {
	    Login login = loginRepository.findByEmail(email)
	            .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
	    if (passwordEncoder.matches(newPassword, login.getPwd())) {
	        throw new DuplicateEntryException("New password cannot be the same as the current password.");
	    }
	    if (isPasswordInHistory(login, newPassword)) {
	        throw new DuplicateEntryException("New password cannot be the same as any of the previous passwords.");
	    }
	    String encodedPassword = passwordEncoder.encode(newPassword);
	    login.setPwd(encodedPassword); 
	    PasswordHistory passwordHistory = new PasswordHistory();
	    passwordHistory.setNewPassword(encodedPassword);
	    passwordHistory.setLogin(login);  
	    historyRepository.save(passwordHistory); 
	    login.setPasswordUpdatedDate(LocalDateTime.now());
	    loginRepository.save(login);

	    String emailSubject = "Your password has been changed";
	    String emailBody = "Dear " + login.getName() + ",\n\nYour password has been successfully updated.\n\nThank you!";
	    emailService.sendEmail(login.getEmail(), emailSubject, emailBody);

	    return loginToDto(login);
	}

	public boolean isPasswordInHistory(Login login, String newPassword) {
	    String encodedNewPassword = passwordEncoder.encode(newPassword);
	    List<PasswordHistory> history = historyRepository.findByLogin(login);
	    for (PasswordHistory historyEntry : history) {
	        if (historyEntry.getNewPassword().equals(encodedNewPassword)) {
	            return true;  // Password is already in history, cannot reuse
	        }
	    }
	    // If no match is found, the password is not in history
	    return false;
	}
	 
//	 public String getPasswordExpirationStatus(String email) {
//		 Login login = loginRepository.findByEmail(email)
//		            .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
//		   
//	        LocalDateTime passwordUpdatedDate = login.getPasswordUpdatedDate();
//	        if (passwordUpdatedDate == null) {
//	            throw new ResourceNotFoundException("Password was never updated.");
//	        }
//	        long daysSinceUpdate = ChronoUnit.DAYS.between(passwordUpdatedDate, LocalDateTime.now());
//
//	        if (daysSinceUpdate >= 90) {
//	            return "Your password expired " + (daysSinceUpdate - 90) + " days ago. Please update it.";
//	        }
//
//	        long daysLeft = 90 - daysSinceUpdate;
//	        if (daysLeft <= 1) {
//	            return "Your password will expire in 1 day. Please change it.";
//	        } else if (daysLeft <= 2) {
//	            return "Your password will expire in 2 days. Please change it.";
//	        } else if (daysLeft <= 7) {
//	            return "Your password will expire in 7 days. Please change it.";
//	        } else if (daysLeft <= 10) {
//	            return "Your password will expire in 10 days. Please change it.";
//	        }
//	        return "Your password is valid for " + daysLeft + " more days.";
//	    }


}
