package com.transline.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.transline.AuthUtils;
import com.transline.dtos.CustomerNamesDTO;
import com.transline.dtos.LockerAllocationMstDTO;
import com.transline.entities.Customer;
import com.transline.servicesImp.LockerAllocationServiceImpl;
import com.transline.utils.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/Lockerallocation")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related locker allocation ")
public class LockerAllocationController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LockerAllocationController.class);

	@Autowired
	private LockerAllocationServiceImpl serviceImpl;

	@PostMapping
	@Operation(summary = "create locker allocation", description = "Add a new locker allocation in LMS")
	public ResponseEntity<LockerAllocationMstDTO> createAllocation(@Valid @ModelAttribute LockerAllocationMstDTO dto) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		dto.setCmpCd(cmpCd);
		return ResponseEntity.status(HttpStatus.CREATED).body(serviceImpl.createLockerAllocation(dto, cmpCd));
	}
	
//	@PostMapping
//	public ResponseEntity<LockerAllocationMstDTO> createAllocation(
//	        @RequestParam("data") LockerAllocationMstDTO dto, 
//	        @RequestParam(value = "agreementDoc", required = false) MultipartFile agreementDoc) {
//	    String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
//	    dto.setCmpCd(cmpCd);
//	    
//    return ResponseEntity.status(HttpStatus.CREATED).body(serviceImpl.createLockerAllocation(dto, cmpCd));
//	}

	@GetMapping("{id}")
	@Operation(summary = "Get locker allocation by ID", description = "Retrieve a locker allocation by their ID")
	public ResponseEntity<LockerAllocationMstDTO> getLockerAllocationById(@PathVariable Long id) {
		return ResponseEntity.ok(this.serviceImpl.getLockerAllocationById(id));
	}

	@GetMapping
	@Operation(summary = "Get all locker allocation details", description = "Retrieve a list of all locker allocation details")
	public ResponseEntity<List<LockerAllocationMstDTO>> getAllAllocationDetails() {
		return ResponseEntity.ok(this.serviceImpl.getAllLockerAllocation());
	}

	@PatchMapping("/{id}")
	@Operation(summary = "Update locker allocation details", description = "Update an existing locker allocation details by their ID")
	public ResponseEntity<LockerAllocationMstDTO> updateAllocationDetails(
			@ModelAttribute LockerAllocationMstDTO allocationMstDTO, @PathVariable Long id) {
		LockerAllocationMstDTO updateAllocation = serviceImpl.updateLockerAllocation(allocationMstDTO, id);
		return ResponseEntity.ok(updateAllocation);
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Delete locker allocation type details", description = "Delete a locker allocation type details by their ID")
	public ResponseEntity<ApiResponse> deleteAllocation(@PathVariable Long id) {
		this.serviceImpl.deleteLockerAllocation(id);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Locker allocation deleted successfully", true),
				HttpStatus.OK);
	}

	@GetMapping("/details")
	public ResponseEntity<?> getLockerDetails(@RequestParam String accessKey) {
		try {
			Map<String, String> lockerDetails = serviceImpl.getLockerDetailsByAccessKey(accessKey);
			return ResponseEntity.ok(lockerDetails);
		} catch (EntityNotFoundException ex) {
			Map<String, String> errorResponse = new HashMap<>();
			errorResponse.put("error", "Invalid access key");
			errorResponse.put("message", ex.getMessage());
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
		}
	}

	@GetMapping("/customersByLocker")
	public List<CustomerNamesDTO> getCustomersByLockerId(@RequestParam Long lockerId) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		return serviceImpl.getCustomersByLocker(cmpCd, lockerId);
	}
}
