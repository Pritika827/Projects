package com.transline.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.AuthUtils;
import com.transline.dtos.LockerAccessDTO;
import com.transline.dtos.LoginDTO;
import com.transline.dtos.PasswordChangeReqDTO;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.servicesImp.LoginServiceImpl;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/login")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related create user ")
public class LoginController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	private LoginServiceImpl loginServiceImpl;
	
	@PostMapping
	public ResponseEntity<LoginDTO> createLoginUser(@Valid @RequestBody LoginDTO dto) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		dto.setCmpCd(cmpCd);
		logger.info("login dto is: " + dto);
		return ResponseEntity.status(HttpStatus.CREATED).body(loginServiceImpl.createLogin(dto, cmpCd));
	}
	
	@PutMapping("/changePassword/{email}")
    public ResponseEntity<LoginDTO> changePassword(@PathVariable String email, 
                            @RequestBody PasswordChangeReqDTO passwordChangeRequest) {
        try {
        	String cmpCd=AuthUtils.getCurrentUser().getCmpCd();
            LoginDTO updatedUser = loginServiceImpl.changePassword(cmpCd,email, passwordChangeRequest.getNewPassword());
            return ResponseEntity.ok(updatedUser);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(null);
        }
    }
	
//	@GetMapping("/passwordExpiration/{email}")
//    public ResponseEntity<String> getPasswordExpirationStatus(@PathVariable String email) {
//        try {
//            String expirationStatus = loginServiceImpl.getPasswordExpirationStatus(email);
//            return ResponseEntity.ok(expirationStatus);
//        } catch (ResourceNotFoundException ex) {
//            return ResponseEntity.notFound().build();
//        }
//    }

}
