package com.transline.controllers;

import java.util.List;
import java.util.Map;
import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.transline.AuthUtils;
import com.transline.dtos.NewOfficeDTO;
import com.transline.dtos.OfficeDto;
import com.transline.dtos.OfficeListItemDTO;
import com.transline.dtos.OfficeTypeDetailDTO;
import com.transline.entities.Office;
import com.transline.repositories.OfficeRepository;
import com.transline.repositories.OfficeTypeRepository;
import com.transline.servicesImp.OfficeService;
import com.transline.servicesImp.OfficeService.OfficeResponse;
import com.transline.servicesImp.OfficeTypeServiceImpl;
import com.transline.utils.ApiResponse;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/office")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
public class OfficeController {

	private static final Logger LOGGER = LoggerFactory.getLogger(OfficeController.class);

	@Autowired
	private OfficeService officeService;

	@Autowired
	private OfficeTypeServiceImpl officeTypeService;

	@Autowired
	private OfficeTypeRepository officeTypeRepository;

	@PostMapping
	public ResponseEntity<OfficeResponse> createOffice(@Valid @RequestBody NewOfficeDTO dto) {
		try {
			String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
			OfficeResponse officeResponse = officeService.saveOffice(cmpCd, dto);
			return new ResponseEntity<>(officeResponse, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/getWorkingOffices")
	public ResponseEntity<List<Map<String, Object>>> getWorkingOffices(
			@RequestParam(required = false, defaultValue = "") String offCd) {
		if (offCd.isEmpty()) {
			offCd = AuthUtils.getCurrentUser().getOffCd();
		}
		return ResponseEntity
				.ok(this.officeService.getWorkingOfficesList(AuthUtils.getCurrentUser().getCmpCd(), offCd));
	}

	@GetMapping("/getReportingOffices")
	public ResponseEntity<List<Map<String, Object>>> getReportingOffices(
			@RequestParam(required = false, defaultValue = "") String offCd) {
		if (offCd.isEmpty()) {
			offCd = AuthUtils.getCurrentUser().getOffCd();
		}
		return ResponseEntity.ok(this.officeService.getOfficesList(AuthUtils.getCurrentUser().getCmpCd(), offCd));
	}

	@GetMapping("/getAllOffices")
	public ResponseEntity<List<Map<String, Object>>> getAllOffices(
			@RequestParam(required = false, defaultValue = "") String offCd) {
		if (offCd.isEmpty()) {
			offCd = AuthUtils.getCurrentUser().getOffCd();
		}
		return ResponseEntity.ok(this.officeService.getAllOfficesList(AuthUtils.getCurrentUser().getCmpCd(), offCd));
	}

	@GetMapping("/getOfficesList")
	public ResponseEntity<List<OfficeListItemDTO>> getOfficeListReport(
			@RequestParam(required = false, defaultValue = "") String offCd) {
		if (offCd.isEmpty()) {
			offCd = AuthUtils.getCurrentUser().getOffCd();
		}
		return ResponseEntity.ok(this.officeService.getOfficeListReport(AuthUtils.getCurrentUser().getCmpCd(), offCd));
	}

	@GetMapping("/{offCd}")
	public ResponseEntity<Office> getOfficeById(@PathVariable String offCd) {
		return ResponseEntity.ok(this.officeService.getOfficeByOffCd(AuthUtils.getCurrentUser().getCmpCd(), offCd));
	}

	@GetMapping
	public ResponseEntity<List<Office>> getAllOfficeDetails() {
		return ResponseEntity.ok(this.officeService.getAllOffices(AuthUtils.getCurrentUser().getCmpCd()));
	}

	@PutMapping("/{id}")
	public ResponseEntity<Office> updateOffice(@RequestBody OfficeDto officeDto, @PathVariable Long id) {
		Office updatedOffice = this.officeService.updateOfficeDto(id, officeDto);
		return ResponseEntity.ok(updatedOffice);

	}

	@DeleteMapping("{offCd}")
	public ResponseEntity<ApiResponse> deleteOffice(@PathVariable Long offId) {
		this.officeService.deleteOffice(offId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Office deleted successfully", true), HttpStatus.OK);
	}

	@GetMapping("/details")
	public List<OfficeTypeDetailDTO> getOfficeTypeDetails() {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		return officeService.getOfficeTypeDetails(cmpCd);
	}

//	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/secure-endpoint")
	public ResponseEntity<String> getSecureData() {
		System.out.println("Authorities: ");
		org.springframework.security.core.Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		System.out.println("Authorities: " + auth.getAuthorities());
		return ResponseEntity.ok("This is a secure data accessible only by ADMIN.");
	}
}
