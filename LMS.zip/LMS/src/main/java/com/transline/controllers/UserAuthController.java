package com.transline.controllers;

import java.sql.Date;
import java.text.SimpleDateFormat;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.transline.dtos.JwtRequest;
import com.transline.dtos.JwtResponse;
import com.transline.repositories.CompanyRepository;
import com.transline.repositories.LoginRepository;
import com.transline.security.JwtHelper;
import com.transline.servicesImp.CustomUserDetailServices;
import ch.qos.logback.classic.Logger;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
public class UserAuthController {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(UserAuthController.class);

	@Autowired
	private CustomUserDetailServices userDetailsService;

	@Autowired
	private AuthenticationManager manager;

	@Autowired
	private JwtHelper helper;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private CompanyRepository companyRepository;

	@Autowired
	private LoginRepository loginRepository;

//    @Autowired
//    private UserService userService;

	private Logger logger = (Logger) LoggerFactory.getLogger(UserAuthController.class);

	@PostMapping("/login")
	public ResponseEntity login(@Valid @RequestBody JwtRequest request) {
		logger.info(request.toString());
//		this.doAuthenticate(request.getUserId(), request.getPassword(), request.getCmpCd());
		String usernameToken = request.getCmpCd() + "::" + request.getUserName();

		UserDetails userDetails = userDetailsService.loadUserByUsername(usernameToken);
		logger.info(userDetails.toString());

		if (userDetails.getPassword().equals(passwordEncoder.encode(request.getPassword()))) {
			String token = this.helper.generateToken(usernameToken);
			long expirationTime = System.currentTimeMillis() + this.helper.getTokenValidity() * 1000;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String time = sdf.format(new Date(expirationTime));

			String name = loginRepository.findNameByCmpCdAndUserName(request.getCmpCd(), request.getUserName());
			String roleType = loginRepository.findRoleTypeByCmpCdAndUserName(request.getCmpCd(), request.getUserName());
			logger.info("Name: " + name);
			logger.info("role type:" + roleType);
			JwtResponse response = JwtResponse.builder().token(token).expirationTime(time).fullName(name)
					.roleType(roleType).build();
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			throw new BadCredentialsException(" Invalid Username or Password  !!");
		}
	}

}
