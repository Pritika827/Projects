package com.transline.controllers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.transline.exceptions.DataNotSave;
import com.transline.exceptions.DateException;
import com.transline.exceptions.DuplicateEntryException;
import com.transline.exceptions.DuplicateOfficeNameException;
import com.transline.exceptions.DuplicatePanOrAadharException;
import com.transline.exceptions.EmailDeliveryException;
import com.transline.exceptions.ErrorResponse;
import com.transline.exceptions.GeneralException;
import com.transline.exceptions.LockerAlreadyAllocatedException;
import com.transline.exceptions.LockerLocationAlreadyExist;
import com.transline.exceptions.LockerNoAlreadyExist;
import com.transline.exceptions.NomineeException;
import com.transline.exceptions.OfficeTypeNotFoundException;
import com.transline.exceptions.OtpException;
import com.transline.exceptions.PasswordNotMatch;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.utils.ApiResponse;

import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ApiResponse> resourceNotFoundExceptionHandler(ResourceNotFoundException ex) {
		String msg = ex.getMessage();
		ApiResponse apiResponse = new ApiResponse(msg, false);
		return new ResponseEntity<ApiResponse>(apiResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		Map<String, String> resp = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach((error) -> {
			String fieldName = ((FieldError) error).getField();
			String meassage = error.getDefaultMessage();
			resp.put(fieldName, meassage);
		});
		return new ResponseEntity<Object>(resp, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(IllegalArgumentException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(BadCredentialsException.class)
	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ResponseBody
	public ErrorResponse handleBadCredentialsException(BadCredentialsException ex) {
		return new ErrorResponse(HttpStatus.UNAUTHORIZED.value(), ex.getMessage());
	}

	@ExceptionHandler(GeneralException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ErrorResponse handleGeneralException(GeneralException ex) {
		return new ErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getMessage());
	}

	@ExceptionHandler(OfficeTypeNotFoundException.class)
	public ResponseEntity<String> handleOfficeTypeNotFound(OfficeTypeNotFoundException ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(LockerAlreadyAllocatedException.class)
	public ResponseEntity<ApiResponse> handleLockerAlreadyAllocatedException(LockerAlreadyAllocatedException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DuplicatePanOrAadharException.class)
	public ResponseEntity<Object> handleDuplicatePanOrAadhar(DuplicatePanOrAadharException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(LockerLocationAlreadyExist.class)
	public ResponseEntity<Object> handleLockerLocationRuntimeException(LockerLocationAlreadyExist ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(LockerNoAlreadyExist.class)
	public ResponseEntity<Object> handleLockerNoRuntimeException(LockerNoAlreadyExist ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DuplicateOfficeNameException.class)
	public ResponseEntity<Object> handleOfficeNameRuntimeException(DuplicateOfficeNameException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(PasswordNotMatch.class)
	public ResponseEntity<Object> handlePwdRuntimeException(PasswordNotMatch ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DateException.class)
	public ResponseEntity<Object> handleDateException(DateException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(NomineeException.class)
	public ResponseEntity<Object> handleNomineeException(NomineeException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DuplicateEntryException.class)
	public ResponseEntity<Object> handleDuplicateEntryException(DuplicateEntryException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DataNotSave.class)
	public ResponseEntity<Object> handleDataNotSave(DataNotSave ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(OtpException.class)
	public ResponseEntity<Object> handleOtpException(OtpException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(EmailDeliveryException.class)
	public ResponseEntity<Object> handleEmailDeliveryException(EmailDeliveryException ex) {
		ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<Object> handleDataIntegrityViolationException(DataIntegrityViolationException ex) {
		String message = extractViolationMessage(ex);
		ApiResponse apiResponse = new ApiResponse(message, false);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	private String extractViolationMessage(DataIntegrityViolationException ex) {
		String message = ex.getMessage();
		if (message.contains("Violation of UNIQUE KEY constraint")) {
			String[] parts = message.split("Cannot insert duplicate key in object.");
			String[] values = parts[1].split("\\)");
			String[] keys = values[0].split(", ");
//            String companyCode = keys[0];
//            String officeName = keys[1];
			return String.format("Cannot insert duplicate key in object.");
		}
		return "A database error occurred.";
	}

//	@ExceptionHandler(ConstraintViolationException.class)
//    public ResponseEntity<String> handleConstraintViolationException(ConstraintViolationException ex) {
//        String message = "Duplicate data detected: " + extractConstraintDetails(ex.getMessage());
//        return ResponseEntity.status(HttpStatus.CONFLICT).body(message);
//    }
//	
//	private String extractConstraintDetails(String exceptionMessage) {
//        if (exceptionMessage.contains("UNIQUE KEY constraint")) {
//            String[] parts = exceptionMessage.split("UNIQUE KEY constraint");
//            return parts.length > 1 ? parts[1].trim() : "Duplicate key";
//        }
//        return exceptionMessage;
//    }
}
