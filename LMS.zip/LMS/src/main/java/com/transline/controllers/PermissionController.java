package com.transline.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.AuthUtils;
import com.transline.dtos.NomineeDTO;
import com.transline.dtos.PermissionDTO;
import com.transline.servicesImp.PermissionServiceImpl;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/permission")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related user Permission ")
public class PermissionController {

	@Autowired
	private PermissionServiceImpl serviceImpl;

	@PostMapping
	@Operation(summary = "Create permission", description = "Add permission in LMS")
	public ResponseEntity<PermissionDTO> createPermission(@Valid @RequestBody PermissionDTO dto) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		dto.setCmpCd(cmpCd);
		PermissionDTO savedPermission = serviceImpl.createPermission(dto);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedPermission);
	}

	@GetMapping("{id}")
	@Operation(summary = "Get permission by ID", description = "Retrieve a permission by their ID")
	public ResponseEntity<PermissionDTO> getPermissionById(@PathVariable Long id) {
		return ResponseEntity.ok(this.serviceImpl.getPermissionById(id));
	}

	@GetMapping
	@Operation(summary = "Get all permission details", description = "Retrieve a list of all permission details")
	public ResponseEntity<List<PermissionDTO>> getAllPermission() {
		return ResponseEntity.ok(this.serviceImpl.getAllPermissions());
	}

	@PutMapping("/{id}")
	@Operation(summary = "Update permission details", description = "Update an existing permission details by their ID")
	public ResponseEntity<PermissionDTO> updatePermission(@RequestBody PermissionDTO dto,
			@PathVariable Long id){
		PermissionDTO updatePermission=serviceImpl.updatePermission(id, dto);
		return ResponseEntity.ok(updatePermission);		
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Delete permission details", description = "Delete a permission details by their ID")
	public ResponseEntity<ApiResponse> deletePermission(@PathVariable Long id) {
		this.serviceImpl.deletePermission(id);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Permission deleted successfully", true), HttpStatus.OK);
	}

}
