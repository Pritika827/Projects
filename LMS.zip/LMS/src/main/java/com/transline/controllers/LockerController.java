package com.transline.controllers;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.transline.AuthUtils;
import com.transline.EncryptionUtil;
import com.transline.dtos.CustomerDTO;
import com.transline.dtos.GetLockerId;
import com.transline.dtos.LockerAccessDTO;
import com.transline.dtos.LockerAllocatedDTO;
import com.transline.dtos.LockerCustomerDTO;
import com.transline.dtos.LockerDTO;
import com.transline.dtos.LockerDTOListWrapper;
import com.transline.dtos.LockerDetailsDTO;
import com.transline.dtos.LockerFreezeDTO;
import com.transline.dtos.LockerTypeDTO;
import com.transline.dtos.LockerTypePricesDTO;
import com.transline.dtos.LockerUnAllocateFreezeDTO;
import com.transline.dtos.LockerUnAllocationDTO;
import com.transline.dtos.NewLockerRequestDTO;
import com.transline.dtos.OtpVerificationResDTO;
import com.transline.entities.Customer;
import com.transline.entities.Locker;
import com.transline.entities.LockerAccess;
import com.transline.entities.LockerAllocationMst;
import com.transline.exceptions.OtpException;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repositories.CustomerRepository;
import com.transline.repositories.LockerAccessRepository;
import com.transline.repositories.LockerAllocationRepository;
import com.transline.repositories.LockerRepository;
import com.transline.security.User;
import com.transline.servicesImp.CustomerService;
import com.transline.servicesImp.LockerAccessServiceImpl;
import com.transline.servicesImp.LockerService;
import com.transline.servicesImp.OfficeService;
import com.transline.servicesImp.OtpService;
import com.transline.utils.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/locker")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related locker ")
public class LockerController {

	private static final Logger logger = LoggerFactory.getLogger(LockerController.class);

	@Autowired
	private LockerService lockerService;
	
	@Autowired
	private OfficeService officeService;
	
	@Autowired
    private OtpService otpService;
	
	@Autowired
	private LockerRepository lockerRepository;
	
	@Autowired
	private LockerAllocationRepository lockerAllocationMstRepository;
	
	@Autowired
	private LockerAccessServiceImpl accessServiceImpl;
	
	@Autowired
	private LockerAccessRepository accessRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CustomerService customerService;

	@PostMapping
	@Operation(summary = "Create multiple lockers", description = "Add multiple lockers in LMS")
	public ResponseEntity<Object> createLockers(@Valid @RequestBody NewLockerRequestDTO newLockerRequest) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		try {
		List<LockerDTO> savedLockers = lockerService.createLockers(cmpCd, newLockerRequest);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedLockers);
	//	return ResponseEntity.ok(savedLockers);
		} catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
        }
	}

	@GetMapping("{id}")
	@Operation(summary = "Get locker by ID", description = "Retrieve a locker by their ID")
	public ResponseEntity<LockerDTO> getLockerById(@PathVariable Long id) {
		return ResponseEntity.ok(this.lockerService.getLockerById(id));
	}

	@GetMapping
	@Operation(summary = "Get all locker details", description = "Retrieve a list of all locker details")
	public ResponseEntity<List<LockerDTO>> getAllLockerDetails(@RequestParam(required=false,defaultValue = "ALL") String offCd) {		
		return ResponseEntity.ok(this.lockerService.getAllLocker(offCd));			
	}

//	@PutMapping("/allocated/{id}")
//	public ResponseEntity<LockerDTO> updateLocker(@RequestBody LockerDTO dto, @PathVariable Long id) {
//			String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
//			LockerDTO updatedLocker = lockerService.updateLocker(cmpCd, dto, id);
//			return ResponseEntity.ok(updatedLocker);		
//	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Delete locker type details", description = "Delete a locker type details by their ID")
	public ResponseEntity<ApiResponse> deleteLocker(@PathVariable Long id) {
		this.lockerService.deleteLocker(id);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Locker details deleted successfully", true),
				HttpStatus.OK);
	}
	
	 @GetMapping("/getLockerNos")
	 public ResponseEntity<List<GetLockerId>> getLockerNoAndId(@RequestParam Long lockerTypeId,
	    		@RequestParam String offCd) {
	     String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
	     if (cmpCd == null) {
	        return ResponseEntity.badRequest().body(null);	
	     }
	      //only unAllocated
	    List<GetLockerId> lockers = lockerService.getLockerNoAndId(cmpCd,offCd, lockerTypeId);
        return ResponseEntity.ok(lockers);
	    }
	 
	 @GetMapping("/allocated")
	 public ResponseEntity<LockerAllocatedDTO> getLockerAllocated() {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();  
		String offCd = AuthUtils.getCurrentUser().getOffCd();
		System.out.println(offCd);
		LockerAllocatedDTO allocated = lockerService.getLockerAllocated(cmpCd, offCd);
	    return ResponseEntity.ok(allocated);
	    }//status remarks -- locker allocation
	 
	 @GetMapping("/unAllocated")
	 public ResponseEntity<LockerUnAllocationDTO> getLockerUnAllocated() {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();  
		String offCd = AuthUtils.getCurrentUser().getOffCd();
		LockerUnAllocationDTO allocated = lockerService.getLockerUnAllocated(cmpCd, offCd);
	    return ResponseEntity.ok(allocated);
	    }
	 
	 @GetMapping("/AllocatedFreeze")
	 public ResponseEntity<LockerUnAllocateFreezeDTO> getLockerAllocatedFreeze() {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();  
		String offCd = AuthUtils.getCurrentUser().getOffCd();
		LockerUnAllocateFreezeDTO allocated = lockerService.getLockerAllocatedFreeze(cmpCd, offCd);
	    return ResponseEntity.ok(allocated);
	    }
	 
//	 @GetMapping("/freeze")
//	 public ResponseEntity<LockerFreezeDTO> getLockerFreeze(){
//		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();  
//		String offCd = AuthUtils.getCurrentUser().getOffCd();
//		LockerFreezeDTO freeze=lockerService.getLockerFreeze(cmpCd, offCd);
//		return ResponseEntity.ok(freeze);
//	 }
	 

	@PostMapping("/generate-otp")
	public ResponseEntity<String> generateOtp(@RequestParam String lockerNo) {
		String offCd=AuthUtils.getCurrentUser().getOffCd();
		Locker locker = lockerRepository.findByLockerNoAndOffCd(lockerNo, offCd);
		if (locker == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Locker not not found");
		}
		String message = otpService.generateAndSendOtp(lockerNo,offCd);
		return ResponseEntity.ok(message);
	}
	
	
	 
//	 @PostMapping("/verify-otp")
//	 public ResponseEntity<OtpVerificationResDTO> verifyOtp(@RequestParam String lockerNo, @RequestParam String otp) {
//	     Locker locker = lockerRepository.findByLockerNo(lockerNo);
//	     if (locker == null) {
//	         throw new RuntimeException("Locker not found");
//	     }
//	     LockerAllocationMst allocation = lockerAllocationMstRepository.findByLocker(locker);
//	     if (allocation == null || allocation.getCustomer() == null) {
//	         throw new RuntimeException("Locker is not allocated to any customer");
//	     }
//	     String email = allocation.getCustomer().getEmailId();
//	     try {
//	         boolean isVerified = otpService.verifyOtp(email, otp);
//	         if (isVerified) {
//	        	 OtpVerificationResDTO responseDTO = new OtpVerificationResDTO(
//	                 "OTP verified successfully", 
//	                 locker, 
//	                 allocation.getCustomer()
//	             );
//	             return ResponseEntity.ok(responseDTO);
//	         }
//	     } catch (RuntimeException ex) {
//	         return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
//	             new OtpVerificationResDTO("Verification failed", null, null)
//	         );
//	     }
//	     return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
//	         new OtpVerificationResDTO("Verification failed", null, null)
//	     );
//	 }
	
	public Long getTotalFinancialYearEntries(Long lockerId, Long customerId) {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime startOfYear;
		LocalDateTime endOfYear;
		if (now.getMonthValue() >= Month.APRIL.getValue()) {
			startOfYear = LocalDateTime.of(now.getYear(), Month.APRIL, 1, 0, 0);
			endOfYear = LocalDateTime.of(now.getYear() + 1, Month.MARCH, 31, 23, 59, 59);
		} else {
			startOfYear = LocalDateTime.of(now.getYear() - 1, Month.APRIL, 1, 0, 0);
			endOfYear = LocalDateTime.of(now.getYear(), Month.MARCH, 31, 23, 59, 59);
		}
		return accessRepository.countAccessEntriesInFinancialYear(lockerId, customerId, startOfYear, endOfYear);
		}

	 @PostMapping("/verify-otp")
	 public ResponseEntity<OtpVerificationResDTO> verifyOtp(@RequestParam String lockerNo,
	         @RequestParam String otp) {
		 String offCd=AuthUtils.getCurrentUser().getOffCd();
		 Locker locker = lockerRepository.findByLockerNoAndOffCd(lockerNo,offCd);		
	     if (locker == null) {
	         throw new ResourceNotFoundException("Locker not found");
	     }
	     LockerAllocationMst allocation = lockerAllocationMstRepository.findByLocker(locker);
	     if (allocation == null || allocation.getCustomer() == null) {
	         throw new ResourceNotFoundException("Locker is not allocated to any customer");
	     }
	     
	     String email = allocation.getCustomer().getEmailId();
	     Customer customer=allocation.getCustomer();
	     CustomerDTO dto0 = new CustomerDTO();
	     dto0.setId(customer.getId());
	     dto0.setCmpCd(customer.getCmpCd());
	     dto0.setOffCd(customer.getOffCd());
	     dto0.setFullName(customer.getFullName());
	     dto0.setFatherName(customer.getFatherName());
	     dto0.setGender(customer.getGender());
	     dto0.setMaritalStatus(customer.getMaritalStatus());
	     dto0.setPanNo(customer.getPanNo());
	     dto0.setAdharNo(customer.getAdharNo());
	     dto0.setContactNo(customer.getContactNo());
	     dto0.setEmailId(customer.getEmailId());
	     dto0.setPermanentAddress(customer.getPermanentAddress());
	     dto0.setCurrentAddress(customer.getCurrentAddress());
	     dto0.setAccountNo(customer.getAccountNo());     
	     try {
	         boolean isVerified = otpService.verifyOtp(email, otp);
	         if (isVerified) {
	             List<LockerAccess> lastFiveAccesses = accessRepository
	                     .findTop5ByLockerOrderByAccessTimeInDesc(locker);
	             
	             List<LockerAccessDTO> lastFiveAccessesDTO = lastFiveAccesses.stream()
	                     .map(access -> convertToLockerAccessDTO(access))
	                     .collect(Collectors.toList());
	             Long totalFinancialYearEntries = getTotalFinancialYearEntries(locker.getId(),customer.getId()); 
	             OtpVerificationResDTO responseDTO = new OtpVerificationResDTO(
	                     "OTP verified successfully", 
	                     locker,
	                     dto0, 
	                     lastFiveAccessesDTO,
	                     totalFinancialYearEntries
	             );
	             return ResponseEntity.ok(responseDTO);
	         }
	     } catch (OtpException ex) {
	           throw new OtpException("Invalid OTP, Please check and try again ");
	     }
	     return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
	             .body(new OtpVerificationResDTO("Verification failed", null, null, null,null));
	 }
	 		

	private LockerAccessDTO convertToLockerAccessDTO(LockerAccess access) {
		LockerAccessDTO dto = new LockerAccessDTO();
		dto.setId(access.getId());
		dto.setCmpCd(access.getCmpCd());
		dto.setCustId(access.getCustomer().getId());
		dto.setLockerId(access.getLocker().getId());
		dto.setLockerNo(access.getLocker().getLockerNo());
		dto.setCustomerName(access.getCustomer().getFullName());
		dto.setAccessTimeIn(access.getAccessTimeIn());
		dto.setAccessTimeOut(access.getAccessTimeOut());
		return dto;
	}

	@GetMapping("/status-count")
	public ResponseEntity<Map<String, Long>> getLockerCountsByStatus() {
		String offCd = AuthUtils.getCurrentUser().getOffCd();
		System.out.print(offCd);
		Map<String, Long> counts = lockerService.getLockerCountsByStatus(offCd);
		return ResponseEntity.ok(counts);
	}

	@GetMapping("/lockerNumber")
	public ResponseEntity<List<String>> getLockerNumbersByOffice(@RequestParam String offCd) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		List<String> lockerNumbers = lockerService.getAllLockerNumbersByOffice(cmpCd, offCd);
		return ResponseEntity.ok(lockerNumbers);
	}

	@GetMapping("/lockerDetails")
	public ResponseEntity<List<LockerDetailsDTO>> getLockerDetailsByOffice(@RequestParam String offCd) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		List<LockerDetailsDTO> lockerDetails = lockerService.getAllLockerDetailsByOffice(cmpCd, offCd);
		return ResponseEntity.ok(lockerDetails);
	}

}
