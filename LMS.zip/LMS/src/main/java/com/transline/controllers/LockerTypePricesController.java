package com.transline.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.AuthUtils;
import com.transline.dtos.LockerTypeDTO;
import com.transline.dtos.LockerTypePricesDTO;
import com.transline.entities.LockerTypePrices;
import com.transline.servicesImp.LockerTypePricesService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/lockerTypePrices")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related locker type details")
public class LockerTypePricesController {

	private static final Logger logger = LoggerFactory.getLogger(LockerTypePricesController.class);

	@Autowired
	private LockerTypePricesService lockerTypePrices;

	@PostMapping
	@Operation(summary = "Create locker type details", description = "Add locker type details in LMS")
	public ResponseEntity<LockerTypePricesDTO> createLockerTypeDtls(@Valid @RequestBody LockerTypePricesDTO dto) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		return ResponseEntity.status(HttpStatus.CREATED).body(lockerTypePrices.createLockerTypeDtls(dto, cmpCd));
	}

	@GetMapping("/{id}")
	@Operation(summary = "Get locker type by ID", description = "Retrieve a locker type by their ID")
	public ResponseEntity<LockerTypePricesDTO> getLockerTypeDtlsById(@PathVariable Long id) {
		return ResponseEntity.ok(this.lockerTypePrices.getLockerTypeDtlsById(id));
	}

	@GetMapping
	@Operation(summary = "Get all locker type details", description = "Retrieve a list of all locker type details")
	public ResponseEntity<List<LockerTypePricesDTO>> getAllLockerTypeDtls() {
		return ResponseEntity.ok(this.lockerTypePrices.getAllLokerType());
	}

	@GetMapping("/lockerType/{lockerTypeId}")
	@Operation(summary = "Get locker type prices", description = "Retrieve price details of locker type")
	public ResponseEntity<LockerTypePricesDTO> getLockerTypePrices(@PathVariable("lockerTypeId") Long lockerTypeId) {
		return ResponseEntity.ok(lockerTypePrices.getCurrentPrices(lockerTypeId));
	}

	@PutMapping("/{id}")
	@Operation(summary = "Update locker type details", description = "Update an existing locker type details by their ID")
	public ResponseEntity<LockerTypePricesDTO> updateLockerTypeDtls(@RequestBody LockerTypePricesDTO dtlsDTO,
			@PathVariable Long id) {
		LockerTypePricesDTO updatedDtls = lockerTypePrices.updatedLockerTypeDtls(dtlsDTO, id);
		return ResponseEntity.ok(updatedDtls);
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Delete locker type details", description = "Delete a locker type details by their ID")
	public ResponseEntity<ApiResponse> deleteLockerTypeDtls(@PathVariable Long id) {
		this.lockerTypePrices.deleteLockertypeDtls(id);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Locker type details deleted successfully", true),
				HttpStatus.OK);
	}

}
