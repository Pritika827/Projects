package com.transline.controllers;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.transline.AuthUtils;
import com.transline.dtos.CustomerDTO;
import com.transline.dtos.LockerDTO;
import com.transline.dtos.NewCustomerDTO;
import com.transline.dtos.UploadsDto;
import com.transline.entities.Customer;
import com.transline.exceptions.DuplicateEntryException;
import com.transline.exceptions.DuplicatePanOrAadharException;
import com.transline.servicesImp.CustomerService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/customer")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related customer ")
public class CustomerController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	private CustomerService customerService;

	@PostMapping(consumes = "multipart/form-data")
	@Operation(summary = "Create customer with document upload", description = "Add a new customer and upload associated documents")
	public ResponseEntity<?> createCustomer(@Valid @ModelAttribute NewCustomerDTO dto) {
		logger.info("Received request to create customer with documents.");
		try {
			String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
			CustomerDTO createdCustomer = customerService.createCustomer(cmpCd, dto);
			return ResponseEntity.status(HttpStatus.CREATED).body(createdCustomer);
		} catch (DuplicateEntryException ex) {
			logger.error("Duplicate entry error", ex);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
		} catch (Exception e) {
			logger.error("Error parsing customer JSON", e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body("An unexpected error occurred while processing the request.");
		}
	}

	@GetMapping("/{id}")
	@Operation(summary = "Get customer by ID", description = "Retrieve a customer by their ID")
	public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable Long id) {
		return ResponseEntity.ok(this.customerService.getCustomerById(id));
	}

	@GetMapping
	@Operation(summary = "Get all customer details", description = "Retrieve a list of all customer details")
	public ResponseEntity<List<CustomerDTO>> getAllCustomerDetails(
			@RequestParam(required = false, defaultValue = "") String contactNo) {
		if (!contactNo.isEmpty()) {
			System.out.println("Received contactNo: " + contactNo);

			List<CustomerDTO> customers = customerService.getCustomerByContactNo(contactNo);
			if (customers != null && !customers.isEmpty()) {
				System.out.println("Customer retrieved: " + customers.get(0));
				return ResponseEntity.ok(customers);
			} else {
				System.out.println("Customer not found for contactNo: " + contactNo);
				return ResponseEntity.notFound().build();
			}
		} else {
			return ResponseEntity.ok(this.customerService.getAllCustomer());
		}
	}

	@PutMapping("/{id}")
	@Operation(summary = "Update customer details", description = "Update an existing customer details by their ID")
	public ResponseEntity<CustomerDTO> updateCustomerDetails(@RequestBody CustomerDTO customerDTO,
			@PathVariable Long id) {
		CustomerDTO updateCustomer = customerService.updateCustomer(customerDTO, id);
		return ResponseEntity.ok(updateCustomer);
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Delete locker type details", description = "Delete a locker type details by their ID")
	public ResponseEntity<ApiResponse> deleteCustomer(@PathVariable Long id) {
		this.customerService.deleteCustomer(id);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Customer deleted successfully", true), HttpStatus.OK);
	}

	@GetMapping("/allCustomers")
	public ResponseEntity<Map<String, Object>> getCustomers() {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		String offCd = AuthUtils.getCurrentUser().getOffCd();
		Map<String, Object> response = customerService.getCustomerDetails(cmpCd, offCd);
		return ResponseEntity.ok(response);
	}
		
	/*
	@GetMapping("/updateSensitiveData")
	public ResponseEntity updateSensitiveData() {
		List<Customer> list=customerService.updateCustomersSensitiveData();		
		return ResponseEntity.ok("updatedRecords : "+list.size());
	}
	*/
}
