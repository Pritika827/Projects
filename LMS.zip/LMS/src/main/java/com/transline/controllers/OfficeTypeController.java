package com.transline.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.transline.AuthUtils;
import com.transline.dtos.OffTypeDetailsDTO;
import com.transline.dtos.OfficeTypeDTO;
import com.transline.entities.OfficeType;
import com.transline.servicesImp.OfficeTypeServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/offtypes")
@CrossOrigin(origins = "http://localhost:5173",allowedHeaders = "*",allowCredentials = "true")
public class OfficeTypeController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OfficeTypeController.class);

    @Autowired
    private OfficeTypeServiceImpl officeTypeServiceImpl;
    
    @GetMapping
    public List<OffTypeDetailsDTO> getOfficeTypeDetails() {
    	String cmpCd=AuthUtils.getCurrentUser().getCmpCd();
        return officeTypeServiceImpl.getOfficeTypeDetails(cmpCd);
    }
    

//	@PostMapping
//	public ResponseEntity<OfficeType> createOrUpdateOfficeType(@Valid @RequestBody	 OfficeTypeDTO officeType) {
//		logger.info("office type" + officeType);				
//		OfficeType savedOfficeType = officeTypeService.insertOfficeType(officeType);
//		return ResponseEntity.status(HttpStatus.CREATED).body(savedOfficeType);
//	}
	
//	@GetMapping("/office-type/{cmpCd}/{officeType}")
//    public ResponseEntity<Optional<String>> getOfficeType(@PathVariable String cmpCd, @PathVariable String offType) {
//        Optional<String> officeTypeObj = Optional.ofNullable(officeTypeService.findByCmpCdAndOfficeType(cmpCd, offType));
//        return ResponseEntity.ok(officeTypeObj);
//    }

}


//// Retrieve OfficeType by composite key
//@GetMapping("/{cmpCd}/{offTypeCode}")
//public ResponseEntity<OfficeType> getOfficeType(@PathVariable String cmpCd, @PathVariable String offTypeCode) {
//  OffTypeId id = new OffTypeId();
//  id.setCmpCd(cmpCd);
//  id.setOffCd(offTypeCode);
//  Optional<OfficeType> officeType = officeTypeService.getOfficeType(id);
//  return officeType.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
//}
//
//// Delete OfficeType by composite key
//@DeleteMapping("/{cmpCd}/{offTypeCode}")
//public ResponseEntity<Void> deleteOfficeType(@PathVariable String cmpCd, @PathVariable String offTypeCode) {
//  OffTypeId id = new OffTypeId();
//  id.setCmpCd(cmpCd);
//  id.setOffCd(offTypeCode);
//  officeTypeService.deleteOfficeType(id);
//  return ResponseEntity.noContent().build();
//}
//
//// Retrieve OfficeTypes by description
//@GetMapping("/description/{offDesc}")
//public ResponseEntity<List<OfficeType>> getOfficeTypesByDescription(@PathVariable String offDesc) {
//  List<OfficeType> officeTypes = (List<OfficeType>) officeTypeService.findByOffDesc(offDesc);
//  return ResponseEntity.ok(officeTypes);
//}
//
//// Retrieve OfficeTypes by level
//@GetMapping("/level/{level}")
//public ResponseEntity<List<OfficeType>> getOfficeTypesByLevel(@PathVariable Integer level) {
//  List<OfficeType> officeTypes = officeTypeService.findByOffLevel(level);
//  return ResponseEntity.ok(officeTypes);
//}