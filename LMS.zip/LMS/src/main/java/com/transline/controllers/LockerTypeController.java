package com.transline.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.transline.AuthUtils;
import com.transline.dtos.LockerTypeDTO;
import com.transline.dtos.UpdateLockerTypeDTO;
import com.transline.security.User;
import com.transline.servicesImp.LockerTypeService;
import com.transline.utils.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/lockerType")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related locker type")
public class LockerTypeController {

	private static final Logger logger = LoggerFactory.getLogger(LockerTypeController.class);

	@Autowired
	private LockerTypeService lockerTypeService;

	@PostMapping
	@Operation(summary = "Create locker type", description = "Add a new locker type in LMS")
	public ResponseEntity<LockerTypeDTO> createLockerType(@Valid @RequestBody LockerTypeDTO dto) {
		User user = AuthUtils.getCurrentUser();
		LockerTypeDTO response = lockerTypeService.createLockerType(user.getCmpCd(), dto);
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}

	@GetMapping("/{id}")
	@Operation(summary = "Get locker type by ID", description = "Retrieve a locker type by their ID")
	public ResponseEntity<LockerTypeDTO> getLockerTypeById(@PathVariable Long id) {
		return ResponseEntity.ok(this.lockerTypeService.getLockerTypeById(id));
	}

	@GetMapping
	@Operation(summary = "Get all locker type", description = "Retrieve a list of all locker type")
	public ResponseEntity<List<LockerTypeDTO>> getAllLockerType() {
		return ResponseEntity.ok(this.lockerTypeService.getAllLockerType(AuthUtils.getCurrentUser().getCmpCd()));
	}

	@PutMapping("/{id}")
	@Operation(summary = "Update locker type", description = "Update an existing locker type by their ID")
	public ResponseEntity<LockerTypeDTO> updateLockerType(@RequestBody UpdateLockerTypeDTO lockerTypeDTO,
			@PathVariable Long id) {

		User user = AuthUtils.getCurrentUser();
		LockerTypeDTO updatedLockerType = lockerTypeService.updateLockerType(user.getCmpCd(), lockerTypeDTO);

		return ResponseEntity.ok(updatedLockerType);
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Delete locker type", description = "Delete a locker type by their ID")
	public ResponseEntity<ApiResponse> deleteLockerType(@PathVariable Long id) {
		this.lockerTypeService.deleteLockerType(id);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Locker Type deleted successfully", true),
				HttpStatus.OK);
	}

}
