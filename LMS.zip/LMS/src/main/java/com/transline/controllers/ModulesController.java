package com.transline.controllers;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.transline.enums.Modules;

import lombok.AllArgsConstructor;
import lombok.Data;

@RestController
@RequestMapping("/api/modules")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
public class ModulesController {

	@GetMapping
	public List<ModuleResponse> getAllModules() {
		return Arrays.stream(Modules.values()).map(module -> new ModuleResponse(module.name(), module.getCode()))
				.collect(Collectors.toList());
	}

	@AllArgsConstructor
	@Data
	public static class ModuleResponse {
		private String name;
		private int code;
	}
}
