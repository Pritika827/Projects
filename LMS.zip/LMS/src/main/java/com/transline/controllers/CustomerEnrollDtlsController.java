package com.transline.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.transline.AuthUtils;
import com.transline.dtos.CustomerDTO;
import com.transline.dtos.CustomerEnrollDtlsDTO;
import com.transline.servicesImp.CustomerEnrollDtlsServiceImpl;
import com.transline.servicesImp.CustomerService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/customerEnroll")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related customer enrollment ")
public class CustomerEnrollDtlsController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerEnrollDtlsController.class);

	@Autowired
	private CustomerEnrollDtlsServiceImpl serviceImpl;

	@PostMapping
	@Operation(summary = "Create customer enrollment", description = "Add a new customer enrollment and upload associated template")
	public ResponseEntity<CustomerEnrollDtlsDTO> createEnrollment(@Valid @RequestPart("customer") String customerJson,
			@RequestPart("template") MultipartFile templateFile) {

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			CustomerEnrollDtlsDTO dto = objectMapper.readValue(customerJson, CustomerEnrollDtlsDTO.class);

			String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
			String createdBy = AuthUtils.getCurrentUser().getUsername();

			dto.setCmpCd(cmpCd);
			dto.setCreatedBy(createdBy);

			CustomerEnrollDtlsDTO createdEnroll = serviceImpl.saveEnrollmentDetails(dto, cmpCd, templateFile);
			return ResponseEntity.status(HttpStatus.CREATED).body(createdEnroll);

		} catch (Exception e) {
			logger.error("Error parsing customer JSON", e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		}
	}

}
