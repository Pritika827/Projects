package com.transline.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.transline.AuthUtils;
import com.transline.dtos.CustomerDTO;
import com.transline.dtos.NomineeDTO;
import com.transline.servicesImp.NomineeServiceImpl;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/nominee")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
@Tag(name = "Locker Management", description = "Operations related nominee ")
public class NomineeController {

	private static final Logger logger = LoggerFactory.getLogger(NomineeController.class);

	@Autowired
	private NomineeServiceImpl nomineeServiceImpl;

	@PostMapping
	@Operation(summary = "Create nominee", description = "Add nominee in LMS")
	public ResponseEntity<NomineeDTO> createNominee(@Valid @RequestBody NomineeDTO dto) {
		String cmpCd = AuthUtils.getCurrentUser().getCmpCd();
		NomineeDTO savedNominee = nomineeServiceImpl.createNominee(dto, cmpCd);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedNominee);
	}

	@GetMapping("{id}")
	@Operation(summary = "Get nominee by ID", description = "Retrieve a nominee by their ID")
	public ResponseEntity<NomineeDTO> getNomineeById(@PathVariable Long id) {
		return ResponseEntity.ok(this.nomineeServiceImpl.getNomineeById(id));
	}

	@GetMapping
	@Operation(summary = "Get all nominee details", description = "Retrieve a list of all nominee details")
	public ResponseEntity<List<NomineeDTO>> getAllNomineeDetails() {
		return ResponseEntity.ok(this.nomineeServiceImpl.getAllNominee());
	}

	@PutMapping("/{id}")
	@Operation(summary = "Update nominee details", description = "Update an existing nominee details by their ID")
	public ResponseEntity<NomineeDTO> updateNomineeDetails(@RequestBody NomineeDTO dto, @PathVariable Long id) {
		NomineeDTO updateNominee = nomineeServiceImpl.updateNominee(dto, id);
		return ResponseEntity.ok(updateNominee);
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Delete nominee details", description = "Delete a nominee details by their ID")
	public ResponseEntity<ApiResponse> deleteNominee(@PathVariable Long id) {
		this.nomineeServiceImpl.deleteNominee(id);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Nominee deleted successfully", true), HttpStatus.OK);
	}

}
