package com.transline.controllers;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.transline.AuthUtils;
import com.transline.dtos.NewCompanyDTO;
import com.transline.dtos.NewOfficeTypeDTO;
import com.transline.entities.OfficeType;
import com.transline.exceptions.ErrorResponse;
import com.transline.security.User;
import com.transline.servicesImp.CompanyService;
import com.transline.servicesImp.OfficeTypeServiceImpl;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:5173", allowedHeaders = "*", allowCredentials = "true")
public class AdminController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private CompanyService companyService;

	@Autowired
	private OfficeTypeServiceImpl officeTypeService;	
	
	
	@PostMapping(path = "/company", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> createCompany(@Valid @RequestBody NewCompanyDTO dto) {
		User user = AuthUtils.getCurrentUser();
		if (!"TTPLS".equalsIgnoreCase(user.getCmpCd()) || !user.getUserType().equalsIgnoreCase("A")) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN)
					.body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(), "Operation Not Allowed"));
		}
		logger.info("Received DTO: {}", dto.toString());
		if (companyService.isAlreadyExists(dto.getCmpCd())) {
			logger.warn("Company with CmpCd {} already exists", dto.getCmpCd());
			return ResponseEntity.badRequest()
					.body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(), "CmpCd Already Exists"));
		}
		try {
			Map<String, String> savedCompany = companyService.insertCompany(dto);
			return ResponseEntity.status(HttpStatus.CREATED).body(savedCompany);
		} catch (Exception e) {
			logger.error("Error creating company: ", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ErrorResponse(
					HttpStatus.INTERNAL_SERVER_ERROR.value(), "An error occurred while creating the company"));
		}
	}
	
	@GetMapping(path = "/company")
	public ResponseEntity<List<Map<String, Object>>> getCompanies() {
		List<Map<String, Object>> list = companyService.getCompanyList();
		return ResponseEntity.status(HttpStatus.CREATED).body(list);
	}

	@PostMapping(path = "/company/{cmpCd}/offTypes")
	public ResponseEntity<OfficeType> createOfficeType(@PathVariable String cmpCd,
			@Valid @RequestBody NewOfficeTypeDTO officeType) {
		logger.info("office type" + officeType);
		OfficeType savedOfficeType = officeTypeService.insertOfficeType(cmpCd, officeType);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedOfficeType);
	}

	@GetMapping(path = "/company/{cmpCd}/offTypes")
	public ResponseEntity<List<OfficeType>> getOfficeTypes(@PathVariable String cmpCd) {
		List<OfficeType> list = officeTypeService.getOfficeTypes(cmpCd);
		return ResponseEntity.status(HttpStatus.CREATED).body(list);
	}
}
