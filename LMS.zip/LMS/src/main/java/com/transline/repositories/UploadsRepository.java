package com.transline.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.transline.entities.UploadedFile;

@Repository
public interface UploadsRepository extends JpaRepository<UploadedFile, Integer> {

	List<UploadedFile> findByRefIdAndRefType(String refId, String refType);

}
