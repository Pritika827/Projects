package com.transline.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.transline.entities.LoginSession;

@Repository
public interface LoginSessionRepository extends JpaRepository<LoginSession, Long> {

}
