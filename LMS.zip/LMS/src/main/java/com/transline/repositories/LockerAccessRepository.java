package com.transline.repositories;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Repository;

import com.transline.entities.Locker;
import com.transline.entities.LockerAccess;

@Repository
public interface LockerAccessRepository extends JpaRepository<LockerAccess, Long> {

	List<LockerAccess> findTop5ByLockerOrderByAccessTimeInDesc(Locker locker);

	@Query("SELECT COUNT(la) FROM LockerAccess la WHERE CAST(la.accessTimeIn AS DATE) = CAST(GETDATE() AS DATE)")
	long countTodayAccessDetails();

	@Query("SELECT la FROM LockerAccess la WHERE CAST(la.accessTimeIn AS DATE) = CAST(GETDATE() AS DATE)")
	List<LockerAccess> findTodayAccessDetails();

	@Query("SELECT l FROM LockerAccess l WHERE  CAST(accessTimeIn AS DATE) BETWEEN :fromDate AND :toDate")
	List<LockerAccess> findAllByAccessTimeBetween(@Param("fromDate") LocalDate fromDate,
			@Param("toDate") LocalDate toDate);

	@Query("SELECT COUNT(l) FROM LockerAccess l WHERE l.locker.id=:lockerId AND "
			+ "l.customer.id=:customerId AND l.accessTimeIn BETWEEN :startOfYear AND :endOfYear")
	Long countAccessEntriesInFinancialYear(@Param("lockerId") Long lockerId, @Param("customerId") Long customerId,
			@Param("startOfYear") LocalDateTime startOfYear, @Param("endOfYear") LocalDateTime endOfYear);

}
