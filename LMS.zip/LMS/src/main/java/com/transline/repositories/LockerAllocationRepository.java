package com.transline.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.transline.dtos.CustomerNamesDTO;
import com.transline.entities.Customer;
import com.transline.entities.Locker;
import com.transline.entities.LockerAllocationMst;

@Repository
public interface LockerAllocationRepository extends JpaRepository<LockerAllocationMst, Long> {
	LockerAllocationMst findByLocker(Locker locker);

	@Query("SELECT l.locker.lockerNo, l.offCd, o.offName FROM LockerAllocationMst l "
			+ "JOIN Office o ON l.cmpCd = o.cmpCd AND l.offCd=o.offCd "
			+ "WHERE l.accessKey = :accessKey AND l.cmpCd=o.cmpCd AND l.offCd=o.offCd")
	List<Object[]> findLockerDetailsByAccessKey(@Param("accessKey") String accessKey);

	boolean existsByAccessKey(String accessKey);

	@Query("SELECT new com.transline.dtos.CustomerNamesDTO(c.id, c.fullName FROM LockerAllocationMst"
			+ " a JOIN a.customer c WHERE a.cmpCd=:cmpCd AND a.locker.id = :lockerId ")
	List<CustomerNamesDTO> getCustomersByLockerId(String cmpCd, @Param("lockerId") Long lockerId);

}
