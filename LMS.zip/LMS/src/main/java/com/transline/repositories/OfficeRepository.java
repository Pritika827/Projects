package com.transline.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.transline.dtos.OfficeListItemDTO;
import com.transline.dtos.OfficeTypeDetailDTO;
import com.transline.entities.Office;

@Repository
public interface OfficeRepository extends JpaRepository<Office, Long> {

	@Query("SELECT MAX(o.offCd) FROM Office o WHERE o.cmpCd=:cmpCd AND o.offCd LIKE :prefix%")
	String getMaxOffCd(String cmpCd, String prefix);

	Optional<Office> findByCmpCdAndOffCd(String cmpCd, String offCd);

	List<Office> findByCmpCd(String cmpCd);

	@Query("SELECT o.offName FROM Office o WHERE o.cmpCd=:cmpCd AND o.offCd=:offCd")
	Optional<String> getOffName(String cmpCd, String offCd);

	@Query("SELECT o.offCd,o.offName FROM Office o WHERE o.cmpCd=:cmpCd")
	List<String[]> getAllOfficeCodeAndName(String cmpCd);

	@Query("SELECT b.offCd FROM Office a JOIN Office b ON(a.cmpCd=b.cmpCd) "
			+ "WHERE a.cmpCd=:cmpCd AND a.offCd=:offCd AND b.path LIKE CONCAT(a.path,'%') AND b.workingStatus IN :workingStatus")
	List<String> getOfficeHierarchyCode(String cmpCd, String offCd, List<String> workingStatus);

	@Query("SELECT b.offCd, b.offName FROM Office a JOIN Office b ON(a.cmpCd=b.cmpCd) "
			+ "WHERE a.cmpCd=:cmpCd AND a.offCd=:offCd AND b.path LIKE CONCAT(a.path,'%') AND b.workingStatus IN :workingStatus")
	List<Object[]> getOfficeHierarchyCodeAndName(String cmpCd, String offCd, List<String> workingStatus);

	@Query("SELECT b.offCd,b.offName, b.officeType.offType, b.officeType.offDesc,b.workingStatus, b.ctlCd, p.offName FROM Office a "
			+ "JOIN FETCH Office b ON(a.cmpCd=b.cmpCd) JOIN Office p ON(b.cmpCd=p.cmpCd AND b.ctlCd=p.offCd)"
			+ "WHERE a.cmpCd=:cmpCd AND a.offCd=:offCd AND b.path LIKE CONCAT(a.path,'%') AND b.workingStatus IN :workingStatus")
	List<Object[]> getOfficeHierarchyDetail(String cmpCd, String offCd, List<String> workingStatus);

	@Query("SELECT b.offName AS offName, b.email AS email, b.phoneNo AS phoneNo, b.offAddress AS offAddress, b.officeType.offDesc AS offType, p.offName as ctlName FROM Office a "
			+ "JOIN FETCH Office b ON(a.cmpCd=b.cmpCd) JOIN Office p ON(b.cmpCd=p.cmpCd AND b.ctlCd=p.offCd)"
			+ "WHERE a.cmpCd=:cmpCd AND a.offCd=:offCd AND b.path LIKE CONCAT(a.path,'%') AND b.workingStatus IN :workingStatus")
	List<OfficeListItemDTO> getOfficeListReport(String cmpCd, String offCd, List<String> workingStatus);

	boolean existsByCmpCdAndOffName(String cmpCd, String offName);

	@Query(value = "SELECT o.id,o.off_cd AS offCd, o.off_name AS offName, ot.off_type AS officeType "
			+ "FROM office o JOIN office_type ot ON o.office_type_id = ot.id "
			+ "WHERE o.cmp_cd = :cmpCd", nativeQuery = true)
	List<Object[]> findOfficeDetailsByCmpCd(@Param("cmpCd") String cmpCd);

	boolean existsByCmpCdAndOffNameAndIdNot(String cmpCd, String offName, Long offId);

	boolean existsByOffName(String offName);

}
