package com.transline.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.transline.dtos.OfficeTypeDTO;
import com.transline.entities.ModuleMst;
import com.transline.entities.OfficeType;

@Repository
public interface ModuleMstRepository extends JpaRepository<ModuleMst, Long> {

	@Query("SELECT m.moduleId,m.status FROM ModuleMst m WHERE m.cmpCd=:cmpCd")
	List<Object[]> getModuleIdWithStatus(@Param("cmpCd") String cmpCd);
}
