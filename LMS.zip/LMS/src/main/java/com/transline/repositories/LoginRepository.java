package com.transline.repositories;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.transline.dtos.OfficeTypeDTO;
import com.transline.entities.Login;
import com.transline.entities.OfficeType;
import com.transline.entities.ids.LoginId;

@Repository
public interface LoginRepository extends JpaRepository<Login, Long> {

	Login findByCmpCdAndUserName(String cmpCd, String userName);

	@Query("SELECT l.name FROM Login l WHERE l.cmpCd = :cmpCd AND l.userName = :userName")
	String findNameByCmpCdAndUserName(@Param("cmpCd") String cmpCd, @Param("userName") String userName);

	@Query("SELECT r.roleType FROM Login l JOIN l.roleMst r WHERE l.cmpCd = :cmpCd AND l.userName = :userName")
	String findRoleTypeByCmpCdAndUserName(@Param("cmpCd") String cmpCd, @Param("userName") String userName);

//	boolean existsByUserName(String userName);

	boolean existsByEmail(String email);

	boolean existsByMobileNo(String mobileNo);

	Optional<Login> findByEmail(String email);

	@Query("SELECT CASE WHEN COUNT(l) > 0 THEN TRUE ELSE FALSE END FROM Login l WHERE "
			+ "SUBSTRING(l.userName, 1, LENGTH(l.userName) - 1) = :userName")
	boolean existsByUserName(@Param("userName") String userName);

}
