package com.transline.repositories;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.transline.entities.LockerReq;

@Repository
public interface LockerReqRepository extends JpaRepository<LockerReq, Long> {

	boolean existsByEmailIdAndOffCd(String emailId, String offCd);

	@Query("SELECT lr FROM LockerReq lr WHERE CAST(reqDate AS DATE) BETWEEN :fromDate AND :toDate")
	List<LockerReq> findAllByReqDateBetween(@Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate);

	@Query("SELECT lr FROM LockerReq lr WHERE CAST(lr.reqDate AS DATE) > :fromDate")
	List<LockerReq> findAllByReqDateAfter(LocalDate fromDate);

	@Query("SELECT lr FROM LockerReq lr WHERE CAST(lr.reqDate AS DATE) < :toDate")
	List<LockerReq> findAllByReqDateBefore(LocalDate toDate);

}
