package com.transline.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.transline.dtos.LockerAllocateFreezeDetailDTO;
import com.transline.dtos.LockerAllocationDetailsDTO;
import com.transline.dtos.LockerCustomerDTO;
import com.transline.dtos.LockerDetailsDTO;
import com.transline.dtos.LockerFreezeDetailDTO;
import com.transline.dtos.LockerUnAllocationDetailDTO;
import com.transline.entities.Locker;
import com.transline.entities.LockerType;
import com.transline.enums.LockerStatus;

@Repository
public interface LockerRepository extends JpaRepository<Locker, Long> {

	@Query("SELECT a FROM Locker a WHERE a.cmpCd=:cmpCd AND a.offCd=:offCd")
	List<Locker> getLockersByOfficeCode(String cmpCd, String offCd);

	@Query("SELECT a FROM Locker a WHERE a.cmpCd=:cmpCd AND a.offCd IN :officeCodes")
	List<Locker> getLockersByOfficeCodes(String cmpCd, List<String> officeCodes);

	@Query("SELECT a FROM Locker a WHERE a.cmpCd=:cmpCd AND a.offCd=:offCd AND (a.lockerNo=:lockerNo OR a.location=:location)")
	Optional<Locker> getByLockerNoOrLocation(String cmpCd, String offCd, String lockerNo, String location);

	@Query("SELECT l.id, l.lockerNo FROM Locker l WHERE l.cmpCd = :cmpCd AND l.offCd = :offCd AND "
			+ "l.lockerType.id = :lockerTypeId AND l.status = com.transline.enums.LockerStatus.AVL")
	List<Object[]> getLockerNoAndIdByCmpCdAndLockerType(@Param("cmpCd") String cmpCd, @Param("offCd") String offCd,
			@Param("lockerTypeId") Long lockerTypeId);


	Locker findByLockerNoAndOffCd(String lockerNo, String offCd);

	@Query("SELECT COUNT(l) FROM Locker l WHERE l.cmpCd = :cmpCd AND l.offCd = :offCd")
	Long countTotalLockers(String cmpCd, String offCd);

	@Query("SELECT COUNT(l) FROM Locker l WHERE l.cmpCd = :cmpCd AND l.offCd = :offCd AND l.status = com.transline.enums.LockerStatus.ASG")
	Long countAllocatedLockers(String cmpCd, String offCd);

	@Query("SELECT COUNT(l) FROM Locker l WHERE l.cmpCd = :cmpCd AND l.offCd = :offCd AND l.status = com.transline.enums.LockerStatus.AVL")
	Long countUnAllocatedLockers(String cmpCd, String offCd);

	@Query("SELECT COUNT(l) FROM Locker l WHERE l.cmpCd = :cmpCd AND l.offCd = :offCd AND l.status = com.transline.enums.LockerStatus.FREEZE")
	Long countFreezeLockers(String cmpCd, String offCd);

	@Query("SELECT COUNT(l) FROM Locker l WHERE l.cmpCd = :cmpCd AND l.offCd = :offCd "
			+ "AND (l.status = com.transline.enums.LockerStatus.AVL OR l.status = com.transline.enums.LockerStatus.FREEZE)")
	Long countAllocatedFreezeLockers(String cmpCd, String offCd);

	@Query("SELECT new com.transline.dtos.LockerAllocationDetailsDTO(l.id,o.offName,l.lockerNo,"
			+ "l.status,lt.type,lt.dimension, lam.allocatedAt FROM Locker l JOIN Office o ON "
			+ "l.offCd = o.offCd JOIN LockerType lt ON l.lockerType.id = lt.id JOIN "
			+ "LockerAllocationMst lam ON lam.locker.id = l.id WHERE l.cmpCd = :cmpCd "
			+ "AND l.offCd = :offCd AND l.status = com.transline.enums.LockerStatus.ASG ")
	List<LockerAllocationDetailsDTO> findAllocatedLockers(String cmpCd, String offCd);

	@Query("SELECT new com.transline.dtos.LockerUnAllocationDetailDTO l.id,o.offName,l.lockerNo,"
			+ "l.status,lt.type,lt.dimension,l.remarks,l.freezeDate FROM Locker l JOIN Office o "
			+ "ON l.offCd = o.offCd JOIN LockerType lt ON l.lockerType.id = lt.id WHERE "
			+ "l.cmpCd = :cmpCd AND l.offCd = :offCd AND l.status = com.transline.enums.LockerStatus.AVL")
	List<LockerUnAllocationDetailDTO> findUnAllocatedLockers(String cmpCd, String offCd);

//	@Query("""
//		    SELECT new com.transline.dtos.LockerFreezeDetailDTO
//		    (l.id,o.offName,l.lockerNo,l.status,lt.type,lt.dimension,l.remarks,l.freezeDate)
//		    FROM Locker l JOIN Office o ON l.offCd = o.offCd 
//		    JOIN LockerType lt ON l.lockerType.id = lt.id
//		    WHERE l.cmpCd = :cmpCd AND l.offCd = :offCd AND l.status = com.transline.enums.LockerStatus.FREEZE
//		""")
//	List<LockerFreezeDetailDTO> findFreezeLockers(String cmpCd, String offCd);

	@Query("SELECT new com.transline.dtos.LockerAllocateFreezeDetailDTO l.id,o.offName,l.lockerNo,"
			+ "l.status,lt.type,lt.dimension,lam.allocatedAt,l.remarks,l.freezeDate FROM Locker l "
			+ "JOIN Office o ON l.offCd = o.offCd JOIN LockerType lt ON l.lockerType.id = lt.id JOIN"
			+ " LockerAllocationMst lam ON lam.locker.id = l.id WHERE l.cmpCd = :cmpCd AND "
			+ "l.offCd = :offCd AND (l.status = com.transline.enums.LockerStatus.ASG OR "
			+ "l.status = com.transline.enums.LockerStatus.FREEZE")
	List<LockerAllocateFreezeDetailDTO> findAllocatedFreezeLockers(String cmpCd, String offCd);

	@Query("SELECT l.offCd, SUM(CASE WHEN l.status = 'AVL' THEN 1 ELSE 0 END) AS availableCount,"
			+ "SUM(CASE WHEN l.status = 'ASG' THEN 1 ELSE 0 END) AS assignedCount, "
			+ "SUM(CASE WHEN l.status = 'UMT' THEN 1 ELSE 0 END) AS underMaintenanceCount,"
			+ "SUM(CASE WHEN l.status= 'FREEZE' THEN 1 ELSE 0 END) AS freezeCount"
			+ "FROM Locker l WHERE l.offCd = :offCd GROUP BY l.offCd ")
	List<Object[]> countLockersByStatus(@Param("offCd") String offCd);

	@Query("SELECT a.lockerNo FROM Locker a WHERE a.cmpCd = :cmpCd AND a.offCd = :offCd")
	List<String> getLockerNumbersByOfficeCode(@Param("cmpCd") String cmpCd, @Param("offCd") String offCd);

	@Query("SELECT new com.transline.dtos.LockerDetailsDTO(a.id, a.lockerNo) "
			+ "FROM Locker a WHERE a.cmpCd = :cmpCd AND a.offCd = :offCd")
	List<LockerDetailsDTO> getLockerDetailsByOfficeCode(@Param("cmpCd") String cmpCd, @Param("offCd") String offCd);

	long countByLockerTypeAndStatus(LockerType lockerType, LockerStatus status);

	Locker findFirstByLockerTypeAndStatus(LockerType lockerType, LockerStatus status);

	@Query("SELECT COUNT(l) FROM Locker l WHERE l.status = com.transline.enums.LockerStatus.AVL AND l.lockerType.id = :lockerTypeId")
	long countAvailableLockers(@Param("lockerTypeId") Long lockerTypeId);

	List<Locker> findByStatus(LockerStatus status);

	@Query("SELECT COUNT(l) FROM Locker l WHERE l.status = :status AND l.lockerType.id = :lockerTypeId")
	long countAvailableLockersByLockerTypeId(@Param("status") LockerStatus status,
			@Param("lockerTypeId") Long lockerTypeId);

	@Query("SELECT l, la.allocatedAt FROM Locker l LEFT JOIN LockerAllocationMst la ON "
			+ "l.id = la.locker.id WHERE l.cmpCd = :cmpCd AND l.offCd IN :officeCodes")
	List<Object[]> getLockersWithAllocationDetails(String cmpCd, List<String> officeCodes);

	@Query("SELECT l FROM Locker l WHERE l.cmpCd = :cmpCd AND l.offCd = :offCd")
	List<Locker> getLockersByOffCd(String cmpCd, String offCd);
}
