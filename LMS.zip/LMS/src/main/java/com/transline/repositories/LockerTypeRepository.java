package com.transline.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.transline.entities.LockerType;

@Repository
public interface LockerTypeRepository extends JpaRepository<LockerType, Long> {

	List<LockerType> findByCmpCd(String cmpCd);

	@Query("SELECT a.id,a.type FROM LockerType a WHERE a.cmpCd=:cmpCd")
	List<Object[]> getLockerIdAndName(String cmpCd);

	@Query("SELECT a.id, a.type, a.dimension FROM LockerType a WHERE a.cmpCd = :cmpCd")
	List<Object[]> getLockerIdAndNameWithDimension(String cmpCd);

}