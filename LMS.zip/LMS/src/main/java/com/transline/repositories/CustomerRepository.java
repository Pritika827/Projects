package com.transline.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.transline.entities.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

	@Query("SELECT c FROM Customer c WHERE c.cmpCd = :cmpCd AND c.contactNo = :contactNo")
	List<Customer> getCustomerByContactNo(@Param("cmpCd") String cmpCd, @Param("contactNo") String contactNo);

	@Query("SELECT c FROM Customer c WHERE c.cmpCd = :cmpCd AND c.offCd = :offCd")
	List<Customer> findAllByCompanyAndOffice(String cmpCd, String offCd);

	@Query("SELECT COUNT(c) FROM Customer c WHERE c.cmpCd = :cmpCd AND c.offCd = :offCd")
	long countByCompanyAndOffice(String cmpCd, String offCd);

	boolean existsByCmpCdAndPanNo(String cmpCd, String panNo);

	boolean existsByCmpCdAndAdharNo(String cmpCd, String adharNo);

	boolean existsByPanNoOrAdharNo(String panNo, String adharNo);

}
