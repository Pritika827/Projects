package com.transline.repositories;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.transline.dtos.LockerTypePricesDTO;
import com.transline.entities.LockerTypePrices;

@Repository
public interface LockerTypePricesRepository extends JpaRepository<LockerTypePrices, Long> {

	@Query("SELECT a FROM LockerTypePrices a WHERE a.cmpCd=:cmpCd AND a.lockerType.id=:lockerTypeId "
			+ "AND ((CURRENT_TIMESTAMP >= a.startDate AND a.endDate IS NULL) OR "
			+ "(CURRENT_TIMESTAMP BETWEEN a.startDate AND a.endDate)) ORDER BY a.startDate")
	List<LockerTypePrices> getCurrentPrices(String cmpCd, Long lockerTypeId);

	Optional<LockerTypePrices> findByCmpCdAndLockerTypeIdAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
			String cmpCd, Long lockerTypeId, LocalDateTime startDate, LocalDateTime endDate);
}
