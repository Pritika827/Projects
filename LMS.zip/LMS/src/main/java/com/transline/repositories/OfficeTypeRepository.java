package com.transline.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.transline.dtos.OffTypeDetailsDTO;
import com.transline.dtos.OfficeTypeDTO;
import com.transline.entities.OfficeType;
import com.transline.entities.ids.OffTypeId;

@Repository
public interface OfficeTypeRepository extends JpaRepository<OfficeType, Long> {

	Optional<OfficeType> findByCmpCdAndOffType(String cmpCd, String offType);

	@Query("SELECT o.id FROM OfficeType o WHERE o.cmpCd = ?1 AND o.offType = ?2")
	Optional<String> isAlreadyExists(String cmpCd, String offType);

	List<OfficeType> findByCmpCd(String cmpCd);

	@Query("SELECT o.offType, o.offDesc ,o.offLevel FROM OfficeType o WHERE o.cmpCd = :cmpCd")
	List<Object[]> getOffTypeAndOffDescCmpCd(@Param("cmpCd") String cmpCd);

}
