package com.transline.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.transline.entities.Nominee;

@Repository
public interface NomineeRepository extends JpaRepository<Nominee, Long> {

	long countByLockerIdAndCustomerId(Long lockerId, Long customerId);

	boolean existsByAdharNo(String adharNo);
}
