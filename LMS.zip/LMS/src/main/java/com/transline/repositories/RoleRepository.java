package com.transline.repositories;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.transline.entities.RoleMst;

@Repository
public interface RoleRepository extends JpaRepository<RoleMst, Long> {

	Optional<RoleMst> findByCmpCdAndRoleType(String cmpCd, String roleType);

	@Query("SELECT r.id, r.roleType FROM RoleMst r where cmpCd=:cmpCd")
	List<Object[]> findIdAndRoleType(@Param(value = "cmpCd") String cmpCd);
}
