package com.transline;

import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;
import static org.springframework.security.config.http.SessionCreationPolicy.STATELESS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
//import com.transline.enums.Permission;
import com.transline.security.JwtAuthenticationEntryPoint;
import com.transline.security.JwtAuthenticationFilter;
import com.transline.servicesImp.CustomUserDetailServices;

import io.jsonwebtoken.io.IOException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

	@Autowired
	private JwtAuthenticationEntryPoint point;

	@Autowired
	private JwtAuthenticationFilter filter;

	@Autowired
	private UserDetailsService userDetailsService;

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

		http
		.csrf(csrf -> csrf.disable()).authorizeRequests()
		.requestMatchers("/auth/login").permitAll()
		.requestMatchers("/api/**").authenticated()
//               .requestMatchers("/api/office/secure-endpoint").hasRole("ADMIN")
//               
//               .requestMatchers("/api/**").hasAnyRole("ADMIN", "AUTHORIZED_USER","NORMAL_USER_")
//               
//               .requestMatchers(HttpMethod.GET, "/api/**").hasAnyAuthority(Permission.ADMIN_READ.getPermission(), Permission.AUTHORIZED_USER_READ.getPermission(), Permission.NORMAL_USER_READ.getPermission())
//               .requestMatchers(HttpMethod.POST, "/api/**").hasAnyAuthority(Permission.ADMIN_CREATE.getPermission(), Permission.AUTHORIZED_USER_CREATE.getPermission(), Permission.NORMAL_USER_CREATE.getPermission())
//               .requestMatchers(HttpMethod.PUT, "/api/**").hasAnyAuthority(Permission.ADMIN_UPDATE.getPermission(), Permission.AUTHORIZED_USER_UPDATE.getPermission(), Permission.NORMAL_USER_UPDATE.getPermission())
//               .requestMatchers(HttpMethod.DELETE, "/api/**").hasAnyAuthority(Permission.ADMIN_DELETE.getPermission(), Permission.AUTHORIZED_USER_DELETE.getPermission(),Permission.NORMAL_USER_UPDATE.getPermission())
				.and().exceptionHandling(ex -> ex.authenticationEntryPoint(point))
				.sessionManagement(session -> session.sessionCreationPolicy(STATELESS))
				.authenticationProvider(doDaoAuthenticationProvider())
				.addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class);

//				 .logout(logout ->logout.logoutUrl("/auth/logout")
//                     .addLogoutHandler(logoutHandler())
//                     .logoutSuccessHandler(new CustomLogoutSuccessHandler()));

		return http.build();
	}	
	
	@Bean
	public PasswordEncoder passwordEncoder() {
//		return new BCryptPasswordEncoder();
		return NoOpPasswordEncoder.getInstance();
	}

	@Bean
	public DaoAuthenticationProvider doDaoAuthenticationProvider() {
		DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
		daoAuthenticationProvider.setUserDetailsService(userDetailsService);
		daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());
		return daoAuthenticationProvider;
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration builder) throws Exception {
		return builder.getAuthenticationManager();
	}
	
//	@Bean
//	public CustomAuthenticationProvider customAuthenticationProvider() {
//		return new CustomAuthenticationProvider(userDetailServices, passwordEncoder);
//	}
	
}


	
//	 public FilterRegistrationBean coresFilter() {
//	        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//
//	        CorsConfiguration corsConfiguration = new CorsConfiguration();
//	        corsConfiguration.setAllowCredentials(true);
//	        corsConfiguration.addAllowedOriginPattern("*");
//	        corsConfiguration.addAllowedHeader("Authorization");
//	        corsConfiguration.addAllowedHeader("Content-Type");
//	        corsConfiguration.addAllowedHeader("Accept");
//	        corsConfiguration.addAllowedMethod("POST");
//	        corsConfiguration.addAllowedMethod("GET");
//	        corsConfiguration.addAllowedMethod("DELETE");
//	        corsConfiguration.addAllowedMethod("PUT");
//	        corsConfiguration.addAllowedMethod("OPTIONS");
//	        corsConfiguration.setMaxAge(3600L);
//
//	        source.registerCorsConfiguration("/**", corsConfiguration);
//
//	        FilterRegistrationBean bean = new FilterRegistrationBean(new CorsFilter((CorsConfigurationSource) source));
//
//	        bean.setOrder(-110);
//
//	        return bean;
//	    }
	
//	@Bean
//	public WebMvcConfigurer corsConfigurer() {
//	    return new WebMvcConfigurer() {
//	        @Override
//	        public void addCorsMappings(CorsRegistry registry) {
//	            registry.addMapping("/**")
//	                    .allowedOrigins("*")
//	                    .allowedMethods("*")
//	                    .allowedHeaders("*")
//	                    .allowCredentials(false);
//	        }
//	    };
//	}
	
//	 public void addCorsMappings(CorsRegistry registry) {
//	        registry.addMapping("/**")
//	                .allowedOrigins("*")  // Allows all origins. Adjust as necessary for security.
//	                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")  // Allows specific methods
//	                .allowedHeaders("*")  // Allows all headers
//	                .allowCredentials(true);  // If you need to send cookies or authentication information
//	    }


