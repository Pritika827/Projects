package com.transline.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.transline.entities.Company;
import com.transline.entities.Login;
import com.transline.entities.Office;
import com.transline.entities.RoleMst;
import com.transline.enums.Modules;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
public class User implements UserDetails {
	private String cmpCd;
	private String cmpName;
	private Long offId;
	private String offCd;
	private String offName;
	private String offType;
	private Long offTypeId;
	private Long id;

	private String userName;

	private String name;

	private String pwd;

	private String status;

	private boolean disabled;

	private boolean blocked;

	private boolean expired;

	private boolean credentialExpired;

	private String userType;// N->Normal, A-> Authorised, W-> WebService User

	private boolean defaultUser;

	private String accessRights;
	private String roleAccessRights;
	private String modAccessRights;

	private String email;

	private String mobileNo;

	private String custodianName;

	public User(Login login, String modAccessRights) {
		this.modAccessRights = modAccessRights;
		// this.roleAccessRights = login.getRoleMst().getAccessRights();
		this.roleAccessRights = "1111111111111111111111111111";
		this.accessRights = login.getAccessRights();
		this.userName = login.getUserName();
		this.name = login.getName();
		this.cmpCd = login.getCmpCd();
		this.offCd = login.getOffice().getOffCd();
		this.offName = login.getOffice().getOffName();
		this.userType = login.getUserType();
		this.custodianName = login.getCustodianName();
		this.email = login.getEmail();
		this.mobileNo = login.getMobileNo();
		// this.defaultUser=login.isDefaultUser();
		this.credentialExpired = login.isCredentialExpired();
		this.blocked = login.isBlocked();
		this.expired = login.isExpired();
		this.pwd = login.getPwd();
		this.offType = login.getOffice().getOfficeType().getOffType();
		this.offTypeId = login.getOffice().getOfficeType().getId();
		this.id = login.getId();
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		String userAccessRights = this.getAccessRights();
		String roleAccessRights = this.getRoleAccessRights();
		String modAccessRights = this.modAccessRights;

		int length = modAccessRights.length();
		for (int i = roleAccessRights.length() - 1; i < length; i++)
			roleAccessRights += "0";
		for (int i = userAccessRights.length() - 1; i < length; i++)
			userAccessRights += "0";
		ArrayList list = new ArrayList();
		for (int i = 0; i < length; i++) {
			if (modAccessRights.charAt(i) == '1' && roleAccessRights.charAt(i) == '1'
					&& userAccessRights.charAt(i) == '1') {
				list.add(new SimpleGrantedAuthority(Modules.fromCode(i + 1).name().toString()));
			}
		}
//		return roleMsts.stream().map(role -> new SimpleGrantedAuthority("ROLE_" + role.getName()))
//				.collect(Collectors.toSet());
		return list;
	}

//	 @Enumerated(EnumType.STRING)
//	  private com.transline.enums.RoleType roleType;

//	  @Override
//	  public Collection<? extends GrantedAuthority> getAuthorities() {
//			System.out.println("Authorities: " + getRole());
//	    return role.getAuthorities();
//	  }
//	

	public String getCmpCd() {
		return this.cmpCd;
	}

	public String getOffCd() {
		return this.offCd;
	}

	@Override
	public String getUsername() {
		return this.userName;
	}

	@Override
	public boolean isAccountNonExpired() {
		return !this.expired;
	}

	@Override
	public boolean isAccountNonLocked() {
		return !this.blocked;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return !this.credentialExpired;
	}

	@Override
	public boolean isEnabled() {
		return !this.disabled;
	}

	@Override
	public String getPassword() {
		return this.pwd;
	}

}
