package com.transline.audit;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import com.transline.AuthUtils;

import java.util.Optional;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

	@Override
	public Optional<String> getCurrentAuditor() {
		if (AuthUtils.isAuthenticated()) {
			return Optional.of(AuthUtils.getCurrentUser().getUsername());
		}
		return Optional.of("system");
	}
}