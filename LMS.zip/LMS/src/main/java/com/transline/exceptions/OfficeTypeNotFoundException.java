package com.transline.exceptions;

public class OfficeTypeNotFoundException extends RuntimeException {

	public OfficeTypeNotFoundException() {
		super("OfficeType not found for the given cmpCd and officeType");
	}

	public OfficeTypeNotFoundException(String message) {
		super(message);
	}

	public OfficeTypeNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public OfficeTypeNotFoundException(Throwable cause) {
		super(cause);
	}
}
