package com.transline.exceptions;

public class DataNotSave extends RuntimeException {
	public DataNotSave(String message,Exception e) {
		super(message,e);
	}
	
	public DataNotSave(String message) {
		super(message);
	}
}
