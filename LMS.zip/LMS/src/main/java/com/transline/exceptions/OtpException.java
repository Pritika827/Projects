package com.transline.exceptions;

public class OtpException extends RuntimeException {

	public OtpException(String message) {
		super(message);
	}
}
