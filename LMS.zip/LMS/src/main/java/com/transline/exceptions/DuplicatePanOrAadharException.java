package com.transline.exceptions;

public class DuplicatePanOrAadharException extends RuntimeException {
    public DuplicatePanOrAadharException(String message) {
        super(message);
    }
}
