package com.transline.exceptions;

public class LockerAlreadyAllocatedException extends RuntimeException {
    public LockerAlreadyAllocatedException(String message) {
        super(message);
    }
}
