package com.transline.exceptions;

public class LockerNoAlreadyExist extends RuntimeException {
	public LockerNoAlreadyExist(String message) {
		super(message);
	}
}
