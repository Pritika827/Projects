package com.transline.exceptions;

public class DuplicateOfficeNameException extends RuntimeException {
    public DuplicateOfficeNameException(String message) {
        super(message);
    }
}
