package com.transline.exceptions;

public class LockerLocationAlreadyExist extends RuntimeException {
	public LockerLocationAlreadyExist(String message) {
		super(message);
	}
}
