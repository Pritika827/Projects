package com.transline.exceptions;

public class NomineeException extends RuntimeException {
	public NomineeException(String message) {
		super(message);
	}
}
