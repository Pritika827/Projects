package com.transline;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.transline.security.User;

@Component
public class AuthUtils {
	public static User getCurrentUser() {
		return ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal());
	}

	public static boolean isAuthenticated() {
		return SecurityContextHolder.getContext().getAuthentication() != null;
	}
}