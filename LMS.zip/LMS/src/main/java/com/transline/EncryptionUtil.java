package com.transline;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.security.SecureRandom;
import java.util.Base64;

public class EncryptionUtil {

	private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
	private static final byte[] KEY = "MySuperSecretKey".getBytes();

	public static String encrypt(String data) {
		if (data == null) {
			return null;
		}
		try {
			byte[] iv = new byte[16];
			SecureRandom secureRandom = new SecureRandom();
			secureRandom.nextBytes(iv);

			SecretKey secretKey = new SecretKeySpec(KEY, "AES");
			IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);

			byte[] encryptedData = cipher.doFinal(data.getBytes());
			String ivBase64 = Base64.getEncoder().encodeToString(iv);
			String encryptedBase64 = Base64.getEncoder().encodeToString(encryptedData);
			String res = ivBase64 + ":" + encryptedBase64;
			return res;

		} catch (Exception e) {
			throw new RuntimeException("Error while encrypting data", e);
		}
	}

	public static String decrypt(String encryptedDataWithIv) {
		if (encryptedDataWithIv == null || !encryptedDataWithIv.contains(":")) {
			System.out.println("Received Data: " + encryptedDataWithIv);
			throw new IllegalArgumentException(
					"Invalid encrypted data format. Expected format: ivBase64:encryptedBase64");
		}

		try {
			String[] parts = encryptedDataWithIv.split(":");
			if (parts.length != 2) {
				throw new IllegalArgumentException(
						"Invalid encrypted data format. Expected two parts separated by ':'.");
			}

			String ivBase64 = parts[0];
			String encryptedBase64 = parts[1];
			byte[] iv = Base64.getDecoder().decode(ivBase64);
			byte[] encryptedData = Base64.getDecoder().decode(encryptedBase64);
			SecretKey secretKey = new SecretKeySpec(KEY, "AES");
			IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
			byte[] decryptedData = cipher.doFinal(encryptedData);
			return new String(decryptedData);

		} catch (Exception e) {
			throw new RuntimeException("Error while decrypting data", e);
		}
	}
	

    public static String encrypt2(String attribute) {
        if (attribute == null) {
            return null;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES");
            SecretKey key = new javax.crypto.spec.SecretKeySpec(KEY, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptedValue = cipher.doFinal(attribute.getBytes());
            return Base64.getEncoder().encodeToString(encryptedValue); // Convert encrypted bytes to base64 string
        } catch (Exception e) {
            throw new RuntimeException("Error encrypting value", e);
        }
    }

    public static String decrypt2(String dbData) {
        if (dbData == null) {
            return null;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES");
            SecretKey key = new javax.crypto.spec.SecretKeySpec(KEY, "AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptedValue = cipher.doFinal(Base64.getDecoder().decode(dbData)); // Decrypt the base64 string
            return new String(decryptedValue);
        } catch (Exception e) {
            throw new RuntimeException("Error decrypting value", e);
        }
    }
    

}
