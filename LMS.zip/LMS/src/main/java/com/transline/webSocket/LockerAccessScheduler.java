package com.transline.webSocket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.transline.entities.LockerAccess;
import com.transline.repositories.LockerAccessRepository;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Component
public class LockerAccessScheduler {

	@Autowired
	private LockerAccessRepository accessRepository;

	private final LockerAccessWebSocketHandler webSocketHandler = new LockerAccessWebSocketHandler();

	private final Map<Long, Long> lastNotifiedAccessTimes = new HashMap<>();

	@Scheduled(fixedRate = 10000)
	public void checkLockerAccessTime() {
		List<LockerAccess> allAccess = accessRepository.findAll();
		List<String> twoMinMessages = new ArrayList<>();
		List<String> threeMinMessages = new ArrayList<>();
		List<String> fiveMinMessages = new ArrayList<>();

		for (LockerAccess access : allAccess) {
			if (access.getAccessTimeIn() != null) {
				LocalDateTime currentTime = LocalDateTime.now();
				Duration duration = Duration.between(access.getAccessTimeIn(), currentTime);
				long minutes = duration.toMinutes();

				Long lastNotifiedTime = lastNotifiedAccessTimes.get(access.getLocker().getId());

				String statusMessage = null;
				if (minutes >= 2 && minutes < 3) {
					if (lastNotifiedTime == null || lastNotifiedTime < 2) {
						statusMessage = "Access time exceeded 2 minutes for locker no "
								+ access.getLocker().getLockerNo();
						if (statusMessage != null) {
							twoMinMessages.add(statusMessage);
							lastNotifiedAccessTimes.put(access.getLocker().getId(), 2L);
						}
					}
				} else if (minutes >= 3 && minutes < 5) {
					if (lastNotifiedTime == null || lastNotifiedTime < 3) {
						statusMessage = "Access time exceeded 3 minutes for locker no "
								+ access.getLocker().getLockerNo();
						if (statusMessage != null) {
							threeMinMessages.add(statusMessage);
							lastNotifiedAccessTimes.put(access.getLocker().getId(), 3L);
						}
					}
				} else if (minutes == 5) {
					if (lastNotifiedTime == null || lastNotifiedTime < 5) {
						statusMessage = "Access time exceeded 5 minutes for locker no "
								+ access.getLocker().getLockerNo();
						if (statusMessage != null) {
							fiveMinMessages.add(statusMessage);
							lastNotifiedAccessTimes.put(access.getLocker().getId(), 5L);
						}
					}
				}
			}
		}

		if (!twoMinMessages.isEmpty() || !threeMinMessages.isEmpty() || !fiveMinMessages.isEmpty()) {
			webSocketHandler.sendStatusUpdate(twoMinMessages, threeMinMessages, fiveMinMessages);
		}
	}
}

//if (minutes >= 30 && minutes < 45) {
//statusMessage = "Access time exceeded 30 minutes for locker no " + access.getLocker().getLockerNo();
//}
//else if (minutes >= 45 && minutes < 60) {
//statusMessage = "Access time exceeded 45 minutes for locker no " + access.getLocker().getLockerNo();
//}
//else if (minutes == 60) {
//statusMessage = "Access time exceeded 1 hour for locker no " + access.getLocker().getLockerNo();
//}
