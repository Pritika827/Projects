package com.transline.webSocket;

import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import java.io.IOException;
import java.util.Collections;
import java.util.Set;
import java.util.List;
import java.util.concurrent.CopyOnWriteArraySet;

public class LockerAccessWebSocketHandler extends TextWebSocketHandler {

	private static final Set<WebSocketSession> sessions = new CopyOnWriteArraySet<>();

	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		sessions.add(session);
	}

	@Override
	public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
		sessions.remove(session);
	}

	public void sendStatusUpdate(List<String> twoMinMessages, List<String> threeMinMessages,
			List<String> fiveMinMessages) {
		if (!twoMinMessages.isEmpty()) {
			for (WebSocketSession session : sessions) {
				try {
					for (String message : twoMinMessages) {
						session.sendMessage(new TextMessage(message));
					}
					// session.sendMessage(new TextMessage("2-minutes exceeded messages:"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		if (!threeMinMessages.isEmpty()) {
			for (WebSocketSession session : sessions) {
				try {
					for (String message : threeMinMessages) {
						session.sendMessage(new TextMessage(message));
					}
					// session.sendMessage(new TextMessage("3-minutes exceeded messages:"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		if (!fiveMinMessages.isEmpty()) {
			for (WebSocketSession session : sessions) {
				try {
					for (String message : fiveMinMessages) {
						session.sendMessage(new TextMessage(message));
					}
					// session.sendMessage(new TextMessage("5-minutes exceeded messages:"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}

//    public void sendStatusUpdate(Long lockerId, String message) {
//        // Send message to all connected clients
//        for (WebSocketSession session : sessions) {
//            try {
//                session.sendMessage(new TextMessage(message));
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
