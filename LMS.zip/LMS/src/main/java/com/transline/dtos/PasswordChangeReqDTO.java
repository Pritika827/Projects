package com.transline.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PasswordChangeReqDTO {

	private String newPassword;
	private String confirmPassword;
}
