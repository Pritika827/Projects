package com.transline.dtos;

import java.util.List;

import com.transline.entities.Customer;
import com.transline.entities.Locker;
import com.transline.entities.LockerAccess;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OtpVerificationResDTO {

	private String message;
	private Locker locker;
	private CustomerDTO customer;
	private List<LockerAccessDTO> lastAccessEntries; 
	private Long tfentries;

}
