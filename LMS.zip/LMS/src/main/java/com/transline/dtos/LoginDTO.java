package com.transline.dtos;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginDTO {
	private Long id;

	private String cmpCd;

	private String userName;

	private String name;

	private String pwd;
	
	private String confirmPwd;

	private String status;

	@NotNull(message = "Office id is required")
	private Long officeId;

	private boolean disabled;

	private boolean blocked;

	private boolean expired;

	private boolean credentialExpired;

	private String userType;// N->Normal, A-> Authorised, W-> WebService User

	//private boolean defaultUser;

	private Long roleId;
	
	//private String CRMuserType;

	private String accessRights;

	@NotBlank(message = "Email ID is required")
	@Email(message = "Email should be valid")
	private String email;

	@NotBlank(message = "Contact number is required")
	@Pattern(regexp = "\\d{10}", message = "Contact number must be a 10-digit number")
	private String mobileNo;

	private String custodianName;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime passwordUpdatedDate;

}
