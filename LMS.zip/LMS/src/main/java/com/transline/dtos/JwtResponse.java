package com.transline.dtos;

import org.springframework.security.core.userdetails.UserDetails;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class JwtResponse {

	private String token;
	private String expirationTime;
	
	private String fullName;
	private String roleType;
//	private String email;
//	private String username;
	//private String role;
	
	
	//token,username
}
