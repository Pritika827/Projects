package com.transline.dtos;

import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.transline.utils.CustomLocalDateTimeDeserializer;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LockerAccessDTO {

	private Long id;

	private String cmpCd;

	@NotNull(message = "Customer id is required")
	private Long custId;

	@NotNull(message = "Locker id is required")
	private Long lockerId;

	private String lockerNo;

	private String customerName;

//	@NotNull(message = "Access time is required")
	@JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime accessTimeIn;

	@JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime accessTimeOut;
	
	private String accessTimeInFormatted; 
    private String accessTimeOutFormatted; 
    
    private String accessTimeInDate; 
    private String accessTimeOutDate; 

	public LockerAccessDTO(Long id, String cmpCd, String lockerNo, String customerName,
			@NotNull(message = "Access time is required") LocalDateTime accessTimeIn, LocalDateTime accessTimeOut) {
		super();
		this.id = id;
		this.cmpCd = cmpCd;
		this.lockerNo = lockerNo;
		this.customerName = customerName;
		this.accessTimeIn = accessTimeIn;
		this.accessTimeOut = accessTimeOut;
	}

	
	public LockerAccessDTO(Long id, String cmpCd, Long custId, Long lockerId, String lockerNo, String customerName,
			LocalDateTime accessTimeIn, LocalDateTime accessTimeOut) {
		this.id = id;
		this.cmpCd = cmpCd;
		this.custId = custId;
		this.lockerId = lockerId;
		this.lockerNo = lockerNo;
		this.customerName = customerName;
		this.accessTimeIn = accessTimeIn;
		this.accessTimeOut = accessTimeOut;
	}
    
	public LockerAccessDTO(Long id, String cmpCd, Long custId, Long lockerId, String lockerNo, String customerName,
			String accessTimeInFormatted, String accessTimeOutFormatted) {
		this.id = id;
		this.cmpCd = cmpCd;
		this.custId = custId;
		this.lockerId = lockerId;
		this.lockerNo = lockerNo;
		this.customerName = customerName;
		this.accessTimeInFormatted = accessTimeInFormatted;
		this.accessTimeOutFormatted = accessTimeOutFormatted;
	}
	
	public LockerAccessDTO(Long id, String cmpCd, Long custId, Long lockerId, String lockerNo, String customerName,
			LocalDateTime accessTimeIn, LocalDateTime accessTimeOut,String accessTimeInFormatted, String accessTimeOutFormatted) {
		this.id = id;
		this.cmpCd = cmpCd;
		this.custId = custId;
		this.lockerId = lockerId;
		this.lockerNo = lockerNo;
		this.customerName = customerName;
		this.accessTimeIn = accessTimeIn;
		this.accessTimeOut = accessTimeOut;
		this.accessTimeInFormatted = accessTimeInFormatted;
		this.accessTimeOutFormatted = accessTimeOutFormatted;
	}

}
