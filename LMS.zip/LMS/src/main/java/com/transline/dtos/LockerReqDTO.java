package com.transline.dtos;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.transline.entities.LockerType;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LockerReqDTO {

	private Long id;
	private String cmpCd;
	private String offCd;
	private String fullName;
	
	@NotBlank(message = "Email ID is required")
	@Email(message = "Email should be valid")
	private String emailId;
	
	@NotBlank(message = "Contact number is required")
	@Pattern(regexp = "\\d{10}", message = "Contact number must be a 10-digit number")
	private String contactNo;
	private Long lockerTypeId;
	private String currentAdd;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime reqDate=LocalDateTime.now();
	
	private String OffName;
	private String LockerType;
}
