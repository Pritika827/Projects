package com.transline.dtos;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.transline.enums.LockerStatus;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LockerDTO {

	private Long id;

	private String offCd;
	
	private String offName;

	private String lockerNo;

	private Long lockerTypeId;
	
	private String lockerType;

	private String location;
	
	private LockerStatus status;
	
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime freezeDate;

	private String comment;
	
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime allocatedAt;
	
	private String dimension;

	public LockerDTO(Long id, String lockerNo) {
		super();
		this.id = id;
		this.lockerNo = lockerNo;
	}
	
	
}
