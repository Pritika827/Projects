package com.transline.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OfficeTypeDetailDTO {
	private Long id;
	private String offCd;
	private String offName;
	private String officeType;

}
