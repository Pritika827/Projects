package com.transline.dtos;

import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NewFileDTO {
	@NotNull
	private String fileType;
	@NotNull
	private MultipartFile file;
	
   // private String filePath;
}
