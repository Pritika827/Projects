package com.transline.dtos;

import java.util.List;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NewOfficeTypeDTO {	
	
	@NotNull
	private String offType;	

	@NotNull
	private String offDesc;

	@NotNull
	private Integer offLevel;	
}
