package com.transline.dtos;

import io.micrometer.common.lang.NonNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoleDto {
	private Long id;

	private String cmpCd;

	@NonNull
	private String roleType;

	@NonNull
	private String roleDesc;

	@NonNull
	private String accessRights;
}