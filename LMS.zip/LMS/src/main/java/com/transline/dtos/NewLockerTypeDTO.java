//package com.transline.dtos;
//
//import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.Pattern;
//import jakarta.validation.constraints.Size;
//import lombok.Data;
//
//@Data
//public class NewLockerTypeDTO {
//	
//	private long id;
//	@NotBlank
//	private String lockerType;
//	
//	@NotBlank
//	@Size(max = 255, message = "Description cannot exceed 255 characters")
//	private String description;
//
//	@NotBlank(message = "Provide proper dimension")
//	@Pattern(regexp = "^\\d+\\s*[xX]\\s*\\d+\\s*[xX]\\s*\\d+$", message = "Dimensions should be a number with up to two decimal places.")
//	private String dimension;	
//	
//	private long avlLockerCount;
//}
