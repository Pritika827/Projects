package com.transline.dtos;

import java.time.LocalDateTime;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.transline.entities.Customer;
import com.transline.entities.Locker;
import com.transline.enums.LockerStatus;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LockerAllocationMstDTO {

	private Long id;
	private String cmpCd;
	private String offCd;
	
//	@NotNull(message = "Allocated date is required and not allow null")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime allocatedAt=LocalDateTime.now();

//	@NotNull(message = "Release date is required and not allow null ")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime releasedAt;

//	private String accessKey;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime expiringDate;

//	@NotBlank(message = "Status is required ")
//	@Pattern(regexp = "^(A|E|C)$", message = "Status would be active(A), expired(E) , cancle(C) else Invalid status")
	
	private LockerStatus status;

	@NotNull(message = "Provide locker id")
	private Long lockerId;

	@NotNull(message = "Provide customer id")
	private Long custId;
	
	private String secondaryCustomers;// [1232][9787][8675]

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime startDate;

	private String billingCycle;

	private String rentAmt;
	
//	@NotNull(message = "Agreement doc is required")	
//	private MultipartFile agreementDoc;	

//	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
//	private LocalDateTime freezeDate;
//
//	private String remarks;
	
	//locker No, billing cycle(monthly,quatery,yearly), rent starting date, 
	//ac no ac type, doc , custodian Id, rules opratable by(one/two/any)


}
