package com.transline.dtos;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class LoginSessionDTO {
	private Long id;
	private String cmpCd;
	private String offCd;
	private String userId;
	private String ipAddress;
	private LocalDateTime loginTime;

}
