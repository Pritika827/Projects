package com.transline.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LockerSizeDTO {

	//only for get
	//locker type
	private Long id;
	private String type;
	private String size; //dimension
	
	//locker type dtls
	private String rentPyUrban;
	private String rentPyRural;
	private String regFee;

}
