package com.transline.dtos;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NomineeDTO {

	private Long id;
	
//	@NotNull(message = "Locker ID is required")
	private Long lockerId;

//	@NotNull(message = "Customer ID is required")
	private Long customerId;

	@NotBlank(message = "Nominee name is required")
	private String nomineeName;

	@NotBlank(message = "Relationship is required")
	private String relationship;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime dob;

	private String phoneNo;

	@NotNull(message = "Address is required")
	private String address;

//	@NotBlank(message = "Voter id is required")
//	private String voterId;

	@NotBlank(message = "Aadhar number is required")
	@Size(min = 12, max = 12, message = "Aadhar number must be exactly 12 digits")
	private String adharNo;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime addedDate = LocalDateTime.now();

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime updatedDate;
}