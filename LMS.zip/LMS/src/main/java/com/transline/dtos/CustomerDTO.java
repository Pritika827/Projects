
package com.transline.dtos;

import java.util.List;
import java.util.Set;

import com.transline.entities.UploadedFile;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDTO {

	private Long id;
	private String cmpCd;
	private String offCd;
	
	private String offName;
	@NotNull
	private String fullName;

	@NotNull
	private String fatherName;
	
	@NotBlank(message = "Gender is required")
	@Pattern(regexp = "Male|Female|Other", message = "Gender must be Male, Female, or Other")
	private String gender;

	@NotBlank(message = "Marital status is required")
	@Pattern(regexp = "Single|Married|Divorced|Widowed", message = "Marital status must be Single, Married, Divorced, or Widowed")
	private String maritalStatus;

	@NotBlank(message = "PAN number is required")
	@Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]", message = "PAN number must be in valid format (e.g., ABCDE1234F)")
	private String panNo;

	@NotBlank(message = "Aadhar number is required")
	@Pattern(regexp = "\\d{12}", message = "Aadhar number must be a 12-digit number")
	private String adharNo;

	@NotBlank(message = "Contact number is required")
	@Pattern(regexp = "\\d{10}", message = "Contact number must be a 10-digit number")
	private String contactNo;

	@NotBlank(message = "Email ID is required")
	@Email(message = "Email should be valid")
	private String emailId;
	
//	@NotBlank(message = "Account number is required")
//	@Size(min = 8, max = 16, message = "Account number must be between 8 and 16 characters")
//	@Pattern(regexp = "\\d+", message = "Account number must contain only digits")	
	private String accountNo;

	private String currentAddress;
	
	private String permanentAddress;
	
	
//	@Pattern(regexp = "Individual|Joint", message = "Account type must be Individual, Joint")
//	private String accountType;
//
//	@NotBlank(message = "ID Proof type is required")
//	private String idProofType;
//
//	@NotBlank(message = "ID Proof number is required")
//	@Size(min = 5, max = 20, message = "ID Proof number must be between 5 and 20 characters")
//	private String idProofNo;
//	
//	private List<Long> uploadedFiles; 
	
	//private String allocatedLockerNo;
}

