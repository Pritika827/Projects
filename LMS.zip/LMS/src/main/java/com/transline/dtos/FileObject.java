package com.transline.dtos;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileObject {	
	private String fileType;
	private String fileName;
	private String fileDesc;
	private MultipartFile file;
}
