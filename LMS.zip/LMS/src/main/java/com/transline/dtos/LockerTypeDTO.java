package com.transline.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LockerTypeDTO {

	private Long id;

	@NotBlank
	private String type;

	@Size(max = 255, message = "Remarks cannot exceed 255 characters")
	private String description;

	@NotBlank(message = "Provide proper dimension")
	@Pattern(regexp = "^\\d+\\s*[xX]\\s*\\d+$", message = "Dimensions should be a number with up to two decimal places.")
	private String dimension;

	private long avlLockerCount;
	
//	@NotBlank(message = "Security level is required")
//	@Pattern(regexp = "^(B|M|H|S)$", message = "Security will Basic(B), Moderate(M), High(H), Smart(S).")
//	private String securityLevel;

//	@Size(max = 255, message = "Remarks cannot exceed 255 characters")
//	private String securityDescription;
}
