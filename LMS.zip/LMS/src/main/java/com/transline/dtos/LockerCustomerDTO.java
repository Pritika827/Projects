package com.transline.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LockerCustomerDTO {
	  private String lockerNo;
	    private String customerName;
	    private Long customerId;
}
