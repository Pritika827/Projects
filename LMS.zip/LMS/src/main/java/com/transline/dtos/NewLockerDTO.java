package com.transline.dtos;

import com.transline.enums.LockerStatus;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class NewLockerDTO {
	@NotBlank
	private String lockerNo;

	@NotBlank
	private String location;	
	
//	private LockerStatus status;
}
