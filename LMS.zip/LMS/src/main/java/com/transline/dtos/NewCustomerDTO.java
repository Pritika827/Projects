
package com.transline.dtos;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewCustomerDTO {

	@NotNull
	private String offCd;
	
	@NotNull
	private String fullName;

	@NotNull
	private String fatherName;
	
	@NotBlank(message = "Gender is required")
	@Pattern(regexp = "Male|Female|Other", message = "Gender must be Male, Female, or Other")
	private String gender;

	@NotBlank(message = "Marital status is required")
	@Pattern(regexp = "Single|Married|Divorced|Widowed", message = "Marital status must be Single, Married, Divorced, or Widowed")
	private String maritalStatus;
	
	@NotBlank
	private String currentAddress;
	
	@NotBlank
	private String permanentAddress;

	
	@NotBlank(message = "PAN number is required")
	@Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]$", message = "PAN number must be in valid format (e.g., ABCDE1234F)")
	private String panNo;


	@NotBlank(message = "Aadhar number is required")
	@Pattern(regexp = "\\d{12}", message = "Aadhar number must be a 12-digit number")
	private String adharNo;

	@NotBlank(message = "Contact number is required")
	@Pattern(regexp = "\\d{10}", message = "Contact number must be a 10-digit number")
	private String contactNo;

	@NotBlank(message = "Email ID is required")
	@Email(message = "Email should be valid")
	private String emailId;
	
//	@NotNull
//	@Size(min = 8, max = 16, message = "Account number must be between 8 and 16 characters")
//	@Pattern(regexp = "\\d+", message = "Account number must contain only digits")
	private String accountNo;
		
	@NotNull(message = "Signature File is required")	
	private MultipartFile signature;
	
	@NotNull(message = "photo File is required")	
	private MultipartFile photo;

	@NotNull(message = "ID Proof type is required")
	private String idProofType;

	@NotNull(message = "ID Proof File is required")	
	private MultipartFile idProofFile;	
	
	@NotNull(message = "Address Proof type is required")
	private String addressProofType;

	@NotNull(message = "Address Proof File is required")	
	private MultipartFile addressProofFile;	
	
	private String allocatedLockerNo;
}

