package com.transline.dtos;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OfficeTypeDTO implements Serializable {

	private String offTypeId;

	@NotNull
	@Size(min = 2, max = 10)
	private String cmpCd;

	@NotNull
	@Size(min = 2, max = 2)
	private String offType;

	@NotNull
	@Size(min = 2, max = 20)
	private String offDesc;

	@NotNull
	@Digits(integer = 2, fraction = 0)
	private Integer offLevel;

	private List<String> roles;

	
}
