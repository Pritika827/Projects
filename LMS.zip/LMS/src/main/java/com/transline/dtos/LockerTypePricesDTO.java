package com.transline.dtos;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonFormat;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LockerTypePricesDTO {

    private Long id;
    
    @NotNull(message = "Locker Type ID is required")
    private Long lockerTypeId;
    
    @NotBlank(message = "Rent in Urban area is required")
    @Pattern(regexp = "^[0-9]+$", message = "Rent in Urban must be a number")
    private String rentForUrban;

    @NotBlank(message = "Rent in Rural area is required")
    @Pattern(regexp = "^[0-9]+$", message = "Rent in Rural must be a number")
    private String rentForRural;

    @NotBlank(message = "Registration fee is required")
    @Pattern(regexp = "^[0-9]+$", message = "Registration Fee must be a number")
    private String regFee;
    
    @NotNull(message = "Start Date is required")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime startDate;

    @NotNull(message = "End Date is required")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime endDate;

	public LockerTypePricesDTO(Long id,
			@NotBlank(message = "Rent in Urban area is required") @Pattern(regexp = "^[0-9]+$", message = "Rent in Urban must be a number") String rentForUrban,
			@NotBlank(message = "Rent in Rural area is required") @Pattern(regexp = "^[0-9]+$", message = "Rent in Rural must be a number") String rentForRural,
			@NotBlank(message = "Registration fee is required") @Pattern(regexp = "^[0-9]+$", message = "Registration Fee must be a number") String regFee) {
		super();
		this.id = id;
		this.rentForUrban = rentForUrban;
		this.rentForRural = rentForRural;
		this.regFee = regFee;
	}
    
    
   
}
