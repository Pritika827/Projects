package com.transline.dtos;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class NewCompanyDTO {
	
	@NotBlank(message = "Provide max 10 digits code")
    private String cmpCd;
	
	@NotBlank(message = "company code is required")
    private String cmpName;
	
	@NotBlank(message = "company address is required")
    private String cmpAdd;
	
	@NotBlank(message = "company city is required")
    private String city;
	
	@NotBlank(message = "state is required")
    private String state;
    
  //  @NotBlank(message = "company website is required")
//    @Pattern(
//            regexp = "^(https?:\\/\\/)?([\\w-]+\\.)+\\w{2,}(\\/\\S*)?$",
//            message = "Please provide a valid URL, starting with http:// or https://"
//        )
    private String website;
    
    private String cmpLogo;
    
    @NotBlank(message = "company email is required")
    @Email(message = "Enter valid email id")
    private String email;
    
    @NotBlank(message = "company phone no is required")
    @Pattern(regexp = "^\\+?[0-9]*$", message = "Invalid phone number format")
    private String phn1;
    
    @Pattern(regexp = "^\\+?[0-9]*$", message = "Invalid phone number format")
    private String phn2;
    
    @Pattern(regexp = "^\\+?[0-9]*$", message = "Fax no. should be 10 digit no. and alphabets are not allow")
    private String faxNo;
    
//    @NotBlank(message = "status is required")
//    @Pattern(regexp = "^(T|F)$", message = "status should be true(T) or false(F)")
//    private String status;     
    
    @NotNull    
    @Valid
    private NewOfficeDTO office_info;
}
