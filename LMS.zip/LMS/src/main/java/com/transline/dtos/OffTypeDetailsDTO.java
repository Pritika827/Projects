package com.transline.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OffTypeDetailsDTO {
	private String offType;
	private String offDesc;
	private Integer offLevel;
}
