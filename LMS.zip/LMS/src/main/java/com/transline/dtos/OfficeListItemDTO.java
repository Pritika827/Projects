package com.transline.dtos;

public interface OfficeListItemDTO {
	String getOffName();
	String getOffAddress();
	String getCtlName();
	String getOffType();
	String getEmail();
	String getPhoneNo();
}
