package com.transline.dtos;

import java.util.List;
import com.transline.entities.Locker;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LockerAllocatedDTO {

	private Long totalLockers;
	private Long lockers;
	private List<LockerAllocationDetailsDTO> allocatedLockerDetails;
}
