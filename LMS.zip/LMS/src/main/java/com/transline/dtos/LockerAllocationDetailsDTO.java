package com.transline.dtos;

import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.transline.enums.LockerStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LockerAllocationDetailsDTO {
	private Long id;
	private String offName;
	private String lockerNo;
	private LockerStatus status;
	private String type;
	private String dimension;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime allocatedAt;
}