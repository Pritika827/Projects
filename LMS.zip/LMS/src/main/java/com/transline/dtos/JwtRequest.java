package com.transline.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class JwtRequest {
	@NotNull
	@Size(min=2,max = 10)
	private String cmpCd;
	
	@NotNull
	@Size(min=4,max = 20)
	private String userName;
	
	@NotNull
	@Size(min=3,max = 50)
	private String password;	
}
