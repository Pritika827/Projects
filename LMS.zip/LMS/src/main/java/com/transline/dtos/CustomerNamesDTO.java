package com.transline.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CustomerNamesDTO {
	private Long id;
	private String fullName;
}
