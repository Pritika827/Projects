package com.transline.dtos;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NewLockerRequestDTO {
	@NotBlank
	private String offCd;
	
	@NotNull
	private Long lockerTypeId;
		
	private List<@Valid NewLockerDTO> lockers;
}
