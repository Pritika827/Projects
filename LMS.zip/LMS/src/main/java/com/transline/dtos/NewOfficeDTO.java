package com.transline.dtos;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
public class NewOfficeDTO {
    
	@NotNull
    private String offName; 
	
	@NotNull
    private String offType; 

	@NotNull
    private String offAddress; 

	@NotNull
 //   @Pattern(regexp = "^(HO|[A-Z0-9]{5})$", message = "Invalid control code format")
    private String ctlCd; 
	
	@NotNull
    @Email(message = "Invalid email format")
    private String email; 
	
    @Pattern(regexp = "^\\+?[0-9]*$", message = "Invalid phone number format")
    private String phoneNo; 

    private String contactPerson; 
  
    @NotNull
    @Pattern(regexp = "^(RO|WO|RWO)$", message = "Invalid working status format")
    private String workingStatus;
    
    @NotNull
    private String auPassword;
       
    @NotNull
    private String nuPassword;
}
