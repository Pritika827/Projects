package com.transline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LockerManagementSystemTests {

	@Test
	void contextLoads() {
	}

}
