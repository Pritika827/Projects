//package com.transline;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import com.transline.entities.Driver;
//import com.transline.repository.DriverRepository;
//
//@SpringBootTest
//@RunWith(SpringRunner.class)
//public class DriverRepositoryTest {
//
//	@Autowired
//	private DriverRepository driverRepository;
//
//	@Test
//	public void testSaveDriver() {
//		Driver driver = new Driver();
//		driver.setName("Test Driver");
//		// Set other fields as necessary
//
//		Driver savedDriver = driverRepository.save(driver);
//		assertNotNull(savedDriver.getDriverId()); // Ensure the ID is generated
//	}
//}
