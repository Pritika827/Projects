package com.transline.service;

import java.util.List;

import com.transline.entities.AttachmentType;

public interface AttachmentTypeService {

	AttachmentType saveAttachmentType(AttachmentType attachmentType);

	List<AttachmentType> getAllAttachmentTypes();

	AttachmentType getAttachmentTypeById(Integer attachmentId);

	AttachmentType updaAttachmentType(AttachmentType attachmentType, Integer attachmentId);

	void deleteAttachement(Integer attachmentId);

}
