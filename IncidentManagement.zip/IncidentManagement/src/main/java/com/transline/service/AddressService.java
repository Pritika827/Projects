package com.transline.service;

import java.util.List;

import com.transline.entities.Address;

public interface AddressService {

	Address saveAddress(Address address);

	List<Address> getAllAddress();

	Address getSingleAddress(Integer addressId);

	Address updateAddress(Address address, Integer addressId);

	void deleteAddress(Integer addressId);

}
