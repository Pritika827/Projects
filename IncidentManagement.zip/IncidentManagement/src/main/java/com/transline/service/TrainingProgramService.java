package com.transline.service;

import java.util.List;

import com.transline.entities.TrainingProgram;

public interface TrainingProgramService {
	
	TrainingProgram saveTrainingProgram(TrainingProgram trainingProgram);

	List<TrainingProgram> getAllTrainingProgramDetail();

	TrainingProgram getSingleTrainingProgram(Integer programId);

	TrainingProgram updateTrainingProgram(TrainingProgram trainingProgram, Integer programId);

	void deleteTrainingProgram(Integer programId);

}
