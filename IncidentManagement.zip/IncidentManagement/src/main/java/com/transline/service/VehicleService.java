package com.transline.service;

import java.util.List;

import com.transline.entities.VehicleMst;

public interface VehicleService {

	VehicleMst saveVehicle(VehicleMst vehicleMst);

	List<VehicleMst> getAllVehicle();

	VehicleMst getSingleVehicle(Integer vehicleId);

	VehicleMst updateVehicle(VehicleMst vehicleMst, Integer vehicleId);

	void deleteVehicle(Integer vehicleId);

}
