package com.transline.service;

import java.util.List;

import com.transline.entities.Staffs;

public interface StaffService {

	Staffs saveStaff(Staffs staff);

	List<Staffs> getAllStaffDetails();

	Staffs getStaff(Integer staffId);

	Staffs updateStaff(Staffs staff, Integer staffId);

	void deleteStaff(Integer staffId);
}
