package com.transline.service;

import java.util.List;

import com.transline.entities.Witness;

public interface WitnessService {

	Witness saveWitness(Witness witness, String incidentId, Integer addressId);

	List<Witness> getAllWitness();

	Witness getSingleWitness(Integer witnessId);

	Witness updatedWitness(Witness witness, Integer witnessId);

	void deleteWitness(Integer witnessId);

	// get witness by incident id
	List<Witness> getWitnessByIncident(String incidentId);
	
	
}
