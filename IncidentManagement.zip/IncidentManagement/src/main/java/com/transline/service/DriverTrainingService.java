package com.transline.service;

public interface DriverTrainingService {
	// public void addCourseToStudent(Long studentId, Long courseId)
//	public void addDriverToTrainingProgram(Integer driverId, Integer programId);

	void addStaffToTrainingProgram(Integer staffId, Integer programId);
}
