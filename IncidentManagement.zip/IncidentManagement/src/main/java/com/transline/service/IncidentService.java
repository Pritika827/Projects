package com.transline.service;

import java.util.List;

import com.transline.entities.Incident;
import com.transline.utils.AccidentType;
import com.transline.utils.IncidentResponse;

public interface IncidentService {

	// create
	public Incident createIncident(Incident incident, Integer vehicleId, Integer driverId, Integer addressId);

	// update
	Incident updateIncident(Incident incident, String incidentId);

	// delete
	void deleteIncident(String incidentId);

	// get single incident
	Incident getSingleIncident(String incidentId);

	// get all incident + sort by incident id(asc,desc)
	// List<Incident> getAllIncident(Integer pageNumber, Integer pageSize);
	IncidentResponse getAllIncident(Integer pageNumber, Integer pageSize, String sortBy,String sortDir);

	// get all incidents by vehicle Id
	List<Incident> getIncidentsByVehicle(Integer vehicleId);

	// get all incidents by driver Id
	List<Incident> getIncidentsByStaff(Integer staffId);

	// get all incidents by address Id
	List<Incident> getIncidentsByLocation(Integer addressId);

	// search incident
	List<Incident> searchAccidentType(AccidentType keyword);

}
