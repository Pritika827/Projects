package com.transline.service;

import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.transline.entities.Attachment;

public interface AttachmentService {
//	Attachment saveAttachment(Attachment attachment);

	Attachment getAttachmentById(int id);

	Iterable<Attachment> getAllAttachments();

	void deleteAttachmentById(int id);

//	Attachment updateAttachment(int attachmentId, Attachment attachment);

	Attachment updateAttachmentWithFile(int attachmentId, Attachment attachment, MultipartFile file);

	Attachment saveAttachmentWithFile(Attachment attachment, MultipartFile file);
}
