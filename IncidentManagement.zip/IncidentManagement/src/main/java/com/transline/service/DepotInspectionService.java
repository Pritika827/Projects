package com.transline.service;

import java.util.List;

import com.transline.entities.DepotInspection;

public interface DepotInspectionService {

	DepotInspection saveDepotInspection(DepotInspection depotInspection);

	List<DepotInspection> getAllDepotInspection();

	DepotInspection getDepotInspectionById(Integer depotId);

	DepotInspection updateDepotInspection(DepotInspection depotInspection, Integer depotId);

	void deleteDepotInspection(Integer depotId);

}
