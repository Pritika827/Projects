package com.transline.entities;

public class Accident_Report_Form2 {
//checkbox
//displayPosition
	//form it or type
}
