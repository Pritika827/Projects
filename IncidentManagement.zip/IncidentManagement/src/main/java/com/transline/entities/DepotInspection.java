package com.transline.entities;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "depot_inspections")
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DepotInspection {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer depotId;

	private String depot;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-mm-yyyy")
	private Date inspDate; // inspectionDate

	private Boolean crewCounsel; // counsellingOfCrewByDM

	private Boolean policeCounsel; // counsellingByDelhiTrafficPolice

	private Boolean driverProfile; // maintainingDriversProfile

	// private Integer refresherCourse; // numOfDriversSentToRefresherCourse

	private String gpsStatus; // presentStatusOfGPSDevicesFittedWithBuses

	// private Boolean roadSafetyWeek; // observanceOfRoadSafetyWeek

	private Boolean audioWorks; // audioInWorkingCondition

	private Boolean videoWorks; // videoInWorkingCondition

	private Boolean bannerDisplayed; // displayOfNecessaryBanner

	private Boolean drivingCheck; // checkingOfDrivingHabitsOfDrivers

	private Boolean recordMaintained; // maintainingCompleteRecord

	//private String comp_code;
}
