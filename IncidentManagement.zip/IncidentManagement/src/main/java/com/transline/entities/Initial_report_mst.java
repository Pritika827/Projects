package com.transline.entities;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Initial_report_mst")
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Initial_report_mst {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long uniqueId;

	private Long driverId;

	private LocalDate date;

	private LocalTime time;

	private String accidentType;

	private String accidentLocation;

	private String remark;
}
