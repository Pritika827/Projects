package com.transline.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "Victims")
@Data
public class Victim {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int victimId;
	private String name;
	private int age;
	private String bloodGroup;

	@OneToOne
	@JoinColumn(name = "vmr_id")
	private VictimMedicalReport victimMedicalReport;

	@ManyToOne
	@JoinColumn(name = "incident_id")
	private Incident incident;
	private String idProof;

}