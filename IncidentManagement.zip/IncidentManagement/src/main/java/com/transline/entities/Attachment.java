package com.transline.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "Attachments")
@Data
public class Attachment extends Auditable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int attachmentId;
	private String attachmentType;

//	@ManyToOne
//	@JoinColumn(name = "ref_id")
//	private Incident incident;	//(don't fetch value)
	
	private String ref_id;//(table PK)

	private String filePath;
	
	private String fileDescription;
	
	private String fileSize;

}