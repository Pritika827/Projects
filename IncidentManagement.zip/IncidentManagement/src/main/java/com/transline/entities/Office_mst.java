package com.transline.entities;


public class Office_mst extends Auditable{
	 private String officeId;
	 private String officeName;
	 private String address;
	 private String comp_code;
}
