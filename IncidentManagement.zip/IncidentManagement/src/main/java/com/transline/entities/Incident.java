package com.transline.entities;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.tranline.annotatios.GeneratedIncidentId;
import com.transline.utils.AccidentType;
import com.transline.utils.IncidentIdGenerator;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "Incidents")
@Data
public class Incident extends Auditable {
	
	@Id
	@GeneratedIncidentId
	private String incidentId;

	@ManyToOne
	@JoinColumn(name = "vehicle_id")
	private VehicleMst vehicle;

	@ManyToOne
	@JoinColumn(name = "staff_id")
	private Staffs staff;

	@ManyToOne
	@JoinColumn(name = "address_id")
	private Address address;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime incidentDateTime;

	private String description;
	private String severity;
	private String status;

	@Enumerated(EnumType.STRING)
	private AccidentType accidentType;

//	@OneToMany(mappedBy = "incident")	
//	private Set<Witness> witnesses=new HashSet<>();

	@PrePersist
	private void prePersist() {
		if (this.incidentId == null) {
			this.incidentId = IncidentIdGenerator.generateIncidentId();
		}
	}
	
	//private String comp_code;
}