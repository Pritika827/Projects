package com.transline.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.transline.utils.StaffType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Staffs")
@Data
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
//@Audited
public class Staffs extends Auditable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer staffId;
	private String name;
	private String licenseNumber;
	private String vehicleNo;
	private int age;
	private String bloodGroup;
	
	private StaffType staffType;
	@ManyToMany
	@JoinTable(
		name = "staff_training_map", 
		joinColumns = @JoinColumn(name = "staff_id"), 
		inverseJoinColumns = @JoinColumn(name = "program_id")
	)
	@JsonIgnoreProperties("staff")
	private List<TrainingProgram> trainings;
	
	//private String comp_code;
}
