//package com.transline.entities;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToMany;
//import jakarta.persistence.Table;
//import lombok.Data;
//import lombok.Getter;
//import lombok.Setter;
//
//@Entity
//@Table(name = "Driver_Trainings")
//@Data
//@Setter
//@Getter
//public class DriverTraining {
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int trainingId;
//
////	@ManyToOne
////	@JoinColumn(name = "driver_id")
////	private Driver driver;
//
////	@ManyToMany(mappedBy = "driverTrainings")
////	private List<Driver> drivers=new ArrayList<>();
////	
////	@ManyToMany(mappedBy = "driverTrainings")
////	private List<TrainingProgram> programs=new ArrayList<>();
//
////	@ManyToOne
////	@JoinColumn(name = "program_id")
////	private TrainingProgram program;
//
////	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-mm-yyyy")
////	private Date trainingDate;
////	private String remarks;
//
//}