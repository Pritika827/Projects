package com.transline.entities;

import java.sql.Date;
import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "Accident_Analysis_reports")
@Data
public class AccidentAnalysisReport extends Auditable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int analysisId;

	@ManyToOne
	@JoinColumn(name = "incident_id")
	private Incident incident;

	private String report;
	private String suggestions;
	private Date analysisDate;
	private String submittingDetailsTo;

}