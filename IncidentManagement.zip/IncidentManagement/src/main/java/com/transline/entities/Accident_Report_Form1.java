package com.transline.entities;

import java.time.LocalDate;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class Accident_Report_Form1 {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ref_no;
	
//	private String busNo;
	private LocalDate date;
	private String registerWith;
	private String accidentType;
	//private String depotId;
	private Integer noOfPassengersOnPlatform;
	
	private String driverName;
	private String staffNo;
	private String licenceNo;
	private String conductorName;	
	private String issuingAuthority;
	private String validityPeriod;
	private String vehicleDamageDescription;
	private String incidentTime;
	private String routeNo;
	private String dutyNo;
	private String incidentLocation;
	private String vehicleDirection;
	private String otherVehicleDirection;
	private Integer carSpeed;
	private Integer otherVehicleSpeed;
	private Boolean hornBlown;
	private Boolean brakesApplied;
	private String seasonDescription;
	private String roadConditions;
	private String lightsOn;
	private String ConditionOfStreetLight;
	private Boolean carNearRoad;
	private String conditionDescription;
	private Integer distanceToBusStop;
	private Integer distanceToTrafficSignal;
	private Integer vehicleSpeedAtTimeOfAccident;

	/*	 
	 Sno
Date 
Register with
Dpo
No. Of passengers on the plateform
Driver name
Staff no.
Licence no.
Carrier name
Issuing authority 
validity period
Was your car damaged?If yes, describe the loss ans nature
Write……….time……..route no………………duty no.

Bank location
Direction of your car
Direction of other vehicle
Speed of your car
Speed of other car
Was the horn blown?
Were the brakes applied?
Description of the season
Road conditions
What lights,if any were burning on your vehicle?
Road or street light treatment,good or bad
Was your car near the road?
If not, please describe the condition properly
Distance of bus stop from accident spot
Distance of the accident spot from the traffic signal
Speed of the bus at the Time of accident as per GPS tracking report(to be filled by the concerned depot)
	 */
}
