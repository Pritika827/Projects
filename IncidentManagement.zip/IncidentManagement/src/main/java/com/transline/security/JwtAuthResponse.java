package com.transline.security;

import lombok.Data;

@Data
public class JwtAuthResponse {

	private String token;
}
