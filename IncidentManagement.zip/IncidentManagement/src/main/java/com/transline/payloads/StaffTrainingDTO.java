package com.transline.payloads;

import java.sql.Date;

import com.transline.entities.Staffs;
import com.transline.entities.TrainingProgram;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StaffTrainingDTO {

	private int trainingId;

	private Staffs staff;

	private TrainingProgram program;

	private Date trainingDate;

	private String remarks;
}
