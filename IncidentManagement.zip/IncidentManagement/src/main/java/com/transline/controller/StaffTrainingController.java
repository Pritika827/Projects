package com.transline.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.service.DriverTrainingService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api")
@Tag(name = "Statf Training Management", description = "Operations related to staff training programs")
public class StaffTrainingController {

	@Autowired
	private DriverTrainingService driverTrainingService;

	@PostMapping("/staff/{staffId}/trainingProgram/{programId}")
	@Operation(summary = "Assign staff to training program", description = "Add a staff to a specified training program")
	public ResponseEntity<String> createDriverTraining(@PathVariable Integer staffId,
			@PathVariable Integer programId) {
		driverTrainingService.addStaffToTrainingProgram(staffId, programId);
		return ResponseEntity.ok("Staff added to training program");
	}

//return ResponseEntity.status(HttpStatus.CREATED)
//		.body(trainingProgramService.saveTrainingProgram(trainingProgram));
//}

//	@PostMapping("/staff/{driverId}/trainingProgram/{programId}")
//	public ResponseEntity<DriverTraining> createDriverTraining(
//			@RequestBody DriverTrainingDTO driverTraininDto,
//			@PathVariable Integer driverId,
//			@PathVariable Integer programId) {
//		DriverTraining createDriverTraining = this.driverTrainingService.createDriverTraining(driverTraininDto,
//				driverId, programId);
//		return ResponseEntity.status(HttpStatus.CREATED).body(createDriverTraining);
//	}

}
