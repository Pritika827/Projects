package com.transline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.entities.VehicleMst;
import com.transline.service.VehicleService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/vehicles")
@Tag(name = "Vehicle Management", description = "Operations related to vehicle management")
public class VehicleController {

	@Autowired
	private VehicleService vehicleService;

	@PostMapping
	@Operation(summary = "Create a new vehicle", description = "Add a new vehicle to the system")
	public ResponseEntity<VehicleMst> createVehicle(@RequestBody VehicleMst vehicleMst) {
		VehicleMst createdVehicle = vehicleService.saveVehicle(vehicleMst);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdVehicle);
	}

	@GetMapping("/{vehicleId}")
	@Operation(summary = "Get vehicle by ID", description = "Retrieve a vehicle by its ID")
	public ResponseEntity<VehicleMst> getSingleVehicle(@PathVariable Integer vehicleId) {
		VehicleMst vehicle = vehicleService.getSingleVehicle(vehicleId);
		return ResponseEntity.ok(vehicle);
	}

	@GetMapping
	@Operation(summary = "Get all vehicles", description = "Retrieve a list of all vehicles")
	public ResponseEntity<List<VehicleMst>> getAllVehicle() {
		List<VehicleMst> vehicles = vehicleService.getAllVehicle();
		return ResponseEntity.ok(vehicles);
	}

	@PutMapping("/{vehicleId}")
	@Operation(summary = "Update vehicle", description = "Update an existing vehicle by its ID")
	public ResponseEntity<VehicleMst> updateVehicle(@RequestBody VehicleMst vehicleMst,
			@PathVariable Integer vehicleId) {
		VehicleMst updatedVehicle = vehicleService.updateVehicle(vehicleMst, vehicleId);
		return ResponseEntity.ok(updatedVehicle);
	}

	@DeleteMapping("/{vehicleId}")
	@Operation(summary = "Delete vehicle", description = "Delete a vehicle by its ID")
	public ResponseEntity<ApiResponse> deleteVehicle(@PathVariable Integer vehicleId) {
		vehicleService.deleteVehicle(vehicleId);
		return ResponseEntity.ok(new ApiResponse("Vehicle deleted successfully", true));
	}
}
