package com.transline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.entities.TrainingProgram;
import com.transline.service.TrainingProgramService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/trainingPrograms")
@Tag(name = "Training Program Management", description = "Operations related to managing training programs")
public class TrainingProgramController {

	@Autowired
	private TrainingProgramService trainingProgramService;

	@PostMapping
	@Operation(summary = "Create a new training program", description = "Add a new training program to the system")
	public ResponseEntity<TrainingProgram> createTrainingProgram(@RequestBody TrainingProgram trainingProgram) {
		TrainingProgram createdProgram = trainingProgramService.saveTrainingProgram(trainingProgram);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdProgram);
	}

	@GetMapping("/{programId}")
	@Operation(summary = "Get training program by ID", description = "Retrieve a training program by its ID")
	public ResponseEntity<TrainingProgram> getSingleTrainingProgram(@PathVariable Integer programId) {
		TrainingProgram program = trainingProgramService.getSingleTrainingProgram(programId);
		return ResponseEntity.ok(program);
	}

	@GetMapping
	@Operation(summary = "Get all training programs", description = "Retrieve a list of all training programs")
	public ResponseEntity<List<TrainingProgram>> getAllTrainingPrograms() {
		List<TrainingProgram> programs = trainingProgramService.getAllTrainingProgramDetail();
		return ResponseEntity.ok(programs);
	}

	@PutMapping("/{programId}")
	@Operation(summary = "Update training program", description = "Update an existing training program by its ID")
	public ResponseEntity<TrainingProgram> updateTrainingProgram(@RequestBody TrainingProgram trainingProgram,
			@PathVariable Integer programId) {
		TrainingProgram updatedProgram = trainingProgramService.updateTrainingProgram(trainingProgram, programId);
		return ResponseEntity.ok(updatedProgram);
	}

	@DeleteMapping("/{programId}")
	@Operation(summary = "Delete training program", description = "Delete a training program by its ID")
	public ResponseEntity<ApiResponse> deleteTrainingProgram(@PathVariable Integer programId) {
		trainingProgramService.deleteTrainingProgram(programId);
		return ResponseEntity.ok(new ApiResponse("Training Program deleted successfully", true));
	}
}
