package com.transline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.entities.Address;
import com.transline.service.AddressService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/address")
@Tag(name = "Address Management", description = "Operations related to address management")
public class AddressController {

	@Autowired
	private AddressService addressService;

	@PostMapping
	@Operation(summary = "Create address", description = "Add a new address to the system")
	public ResponseEntity<Address> createAddress(@RequestBody Address address) {
		return ResponseEntity.status(HttpStatus.CREATED).body(addressService.saveAddress(address));
	}

	@GetMapping("/{addressId}")
	@Operation(summary = "Get address by ID", description = "Retrieve an address by its ID")
	public ResponseEntity<Address> getSingleAddress(@PathVariable Integer addressId) {
		return ResponseEntity.ok(addressService.getSingleAddress(addressId));
	}

	@GetMapping
	@Operation(summary = "Get all addresses", description = "Retrieve a list of all addresses")
	public ResponseEntity<List<Address>> getAllAddresses() {
		return ResponseEntity.ok(addressService.getAllAddress());
	}

	@PutMapping("/{addressId}")
	@Operation(summary = "Update address", description = "Update an existing address by its ID")
	public ResponseEntity<Address> updateAddress(@RequestBody Address address, @PathVariable Integer addressId) {
		return ResponseEntity.ok(this.addressService.updateAddress(address, addressId));
	}

	@DeleteMapping("/{addressId}")
	@Operation(summary = "Delete address", description = "Delete an address by its ID")
	public ResponseEntity<ApiResponse> deleteAddress(@PathVariable Integer addressId) {
		this.addressService.deleteAddress(addressId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Address deleted successfully", true), HttpStatus.OK);
	}

}
