package com.transline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.entities.AttachmentType;
import com.transline.service.AttachmentTypeService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/attachmentType")
@Tag(name = "Attachment Type Management", description = "Operations related to attachment type management")
public class AttachmentTypeController {

	@Autowired
	private AttachmentTypeService service;

	@PostMapping
	@Operation(summary = "Create attachment type", description = "Add a new attachment type to the system")
	public ResponseEntity<AttachmentType> createAttachmentType(@RequestBody AttachmentType attachmentType) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.saveAttachmentType(attachmentType));
	}

	@GetMapping("/{attachmentId}")
	@Operation(summary = "Get attachment type by ID", description = "Retrieve an attachment type by its ID")
	public ResponseEntity<AttachmentType> getAttachmentTypeById(@PathVariable Integer attachmentId) {
		return ResponseEntity.ok(service.getAttachmentTypeById(attachmentId));
	}

	@GetMapping
	@Operation(summary = "Get all attachment type", description = "Retrieve a list of all attachment type")
	public ResponseEntity<List<AttachmentType>> getAllstaff() {
		return ResponseEntity.ok(service.getAllAttachmentTypes());
	}

	@PutMapping("/{attachmentId}")
	@Operation(summary = "Update attachment type", description = "Update an existing attachment type by its ID")
	public ResponseEntity<AttachmentType> updateAttachmentType(@RequestBody AttachmentType attachmentType,
			@PathVariable Integer attachmentId) {
		return ResponseEntity.ok(this.service.updaAttachmentType(attachmentType, attachmentId));
	}

	@DeleteMapping("/{attachmentId}")
	@Operation(summary = "Delete attachment type", description = "Delete an attachment type by its ID")
	public ResponseEntity<ApiResponse> deleteAttachment(@PathVariable Integer attachmentId) {
		this.service.deleteAttachement(attachmentId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("attachment type deleted successfully", true), HttpStatus.OK);
	}
}
