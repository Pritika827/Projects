package com.transline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.entities.Staffs;
import com.transline.serviceImpl.StaffServiceImpl;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/staffs")
@Tag(name = "Staff Management", description = "Operations related to staff management")
public class StaffController {

	@Autowired
	private StaffServiceImpl staffService;

	@PostMapping
	@Operation(summary = "Create staff", description = "Add a new staff to the system")
	public ResponseEntity<Staffs> createDriver(@RequestBody Staffs staff) {
		return ResponseEntity.status(HttpStatus.CREATED).body(staffService.saveStaff(staff));
	}

	@GetMapping("/{staffId}")
	@Operation(summary = "Get staff by ID", description = "Retrieve a staff by their ID")
	public ResponseEntity<Staffs> getSingleDriver(@PathVariable Integer driverId) {
		return ResponseEntity.ok(staffService.getStaff(driverId));
	}

	@GetMapping
	@Operation(summary = "Get all staffs", description = "Retrieve a list of all staffs")
	public ResponseEntity<List<Staffs>> getAllDriver() {
		return ResponseEntity.ok(staffService.getAllStaffDetails());
	}

	@PutMapping("/{staffId}")
	@Operation(summary = "Update staff", description = "Update an existing staff's details by their ID")
	public ResponseEntity<Staffs> updateDriver(@RequestBody Staffs staff, @PathVariable Integer staffId) {
		return ResponseEntity.ok(this.staffService.updateStaff(staff, staffId));
	}

	@DeleteMapping("/{staffId}")
	@Operation(summary = "Delete staff", description = "Delete a staff by their ID")
	public ResponseEntity<ApiResponse> deleteDriver(@PathVariable Integer staffId) {
		this.staffService.deleteStaff(staffId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("staff deleted successfully", true), HttpStatus.OK);
	}

}
