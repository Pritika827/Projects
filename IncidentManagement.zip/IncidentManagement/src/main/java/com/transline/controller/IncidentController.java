package com.transline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.transline.entities.Incident;
import com.transline.service.IncidentService;
import com.transline.utils.AccidentType;
import com.transline.utils.ApiResponse;
import com.transline.utils.AppConstants;
import com.transline.utils.IncidentResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/incidents")
@Tag(name = "Incident Management", description = "Operations related to incident management")
public class IncidentController {

	@Autowired
	private IncidentService incidentService;

	// http://localhost:8082/api/incidents/vehicle/2/driver/4/location/1
	@PostMapping("/vehicle/{vehicleId}/driver/{driverId}/address/{addressId}")
	@Operation(summary = "Create new incident", description = "Create an incident for a given vehicle, driver, and location")
	public ResponseEntity<Incident> createIncident(@RequestBody Incident incident, @PathVariable Integer vehicleId,
			@PathVariable Integer driverId, @PathVariable Integer addressId) {
		Incident createdIncident = this.incidentService.createIncident(incident, vehicleId, driverId, addressId);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdIncident);
	}

	@PutMapping("{incidentId}")
	@Operation(summary = "Update incident", description = "Update an existing incident by its ID")
	public ResponseEntity<Incident> updateIncident(@RequestBody Incident incident, @PathVariable String incidentId) {
		Incident updatedIncident = this.incidentService.updateIncident(incident, incidentId);
		return ResponseEntity.ok(updatedIncident);
	}

	@DeleteMapping("{incidentId}")
	@Operation(summary = "Delete incident", description = "Delete an incident by its ID")
	public ResponseEntity<ApiResponse> deleteIncident(@PathVariable String incidentId) {
		this.incidentService.deleteIncident(incidentId);
		return ResponseEntity.ok(new ApiResponse("Incident successfully deleted", true));
	}

	@GetMapping("{incidentId}")
	@Operation(summary = "Get incident by ID", description = "Retrieve an incident by its ID")
	public ResponseEntity<Incident> getSingleIncident(@PathVariable String incidentId) {
		Incident incident = this.incidentService.getSingleIncident(incidentId);
		return ResponseEntity.ok(incident);
	}

	// http://localhost:8082/api/incidents?pageNumber=0&pageSize=6
// 	// http://localhost:8082/api/incidents?pageNumber=0&pageSize=5&sortBy=incidentId&sortDir=desc
	@GetMapping
	@Operation(summary = "Get all incidents", description = "Retrieve a list of all incidents with pagination and sorting")
	public ResponseEntity<IncidentResponse> getAllIncident(
			@RequestParam(value = "pageNumber", defaultValue = AppConstants.PAGE_NUMBER) Integer pageNumber,
			@RequestParam(value = "pageSize", defaultValue = AppConstants.PAGE_SIZE) Integer pageSize,
			@RequestParam(value = "sortBy", defaultValue = AppConstants.SORT_BY) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = AppConstants.SORT_DIR) String sortDir) {
		IncidentResponse incidentResponse = this.incidentService.getAllIncident(pageNumber, pageSize, sortBy, sortDir);
		return ResponseEntity.ok(incidentResponse);
	}

	@GetMapping("/vehicle/{vehicleId}")
	@Operation(summary = "Get incidents by vehicle", description = "Retrieve incidents associated with a specific vehicle")
	public ResponseEntity<List<Incident>> getIncidentByVehicle(@PathVariable Integer vehicleId) {
		List<Incident> incidents = this.incidentService.getIncidentsByVehicle(vehicleId);
		return ResponseEntity.ok(incidents);
	}

	@GetMapping("/staff/{staffId}")
	@Operation(summary = "Get incidents by staff", description = "Retrieve incidents associated with a specific staff")
	public ResponseEntity<List<Incident>> getIncidentByDriver(@PathVariable Integer staffId) {
		List<Incident> incidents = this.incidentService.getIncidentsByStaff(staffId);
		return ResponseEntity.ok(incidents);
	}

	@GetMapping("/address/{addressId}")
	@Operation(summary = "Get incidents by address", description = "Retrieve incidents associated with a specific address")
	public ResponseEntity<List<Incident>> getIncidentByLocation(@PathVariable Integer addressId) {
		List<Incident> incidents = this.incidentService.getIncidentsByLocation(addressId);
		return ResponseEntity.ok(incidents);
	}

	// http://localhost:8082/api/incidents/search/MINOR
	// keywords is enum data only
	@GetMapping("/search/{keywords}")
	@Operation(summary = "Search incidents by accident type", description = "Search incidents based on the type of accident (e.g., MINOR, MAJOR)")
	public ResponseEntity<List<Incident>> searchByAccidentType(@PathVariable AccidentType keywords) {
		List<Incident> result = this.incidentService.searchAccidentType(keywords);
		return ResponseEntity.ok(result);
	}
}
