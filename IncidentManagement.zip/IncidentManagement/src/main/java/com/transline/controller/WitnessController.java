package com.transline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.entities.Witness;
import com.transline.service.WitnessService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/witnesses")
@Tag(name = "Witness Management", description = "Operations related to managing witnesses")
public class WitnessController {

	@Autowired
	private WitnessService witnessService;

	// http://localhost:8082/api/witnesses/address/5/incident/15
	// Note: address one to one mapping
	@PostMapping("/address/{addressId}/incident/{incidentId}")
	@Operation(summary = "Create a new witness", description = "Add a new witness to the system")
	public ResponseEntity<Witness> createWitness(@RequestBody Witness witness, @PathVariable Integer addressId,
			@PathVariable String incidentId) {
		Witness createdWitness = witnessService.saveWitness(witness, incidentId, addressId);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdWitness);
	}

	@GetMapping("/{witnessId}")
	@Operation(summary = "Get witness by ID", description = "Retrieve a witness by their ID")
	public ResponseEntity<Witness> getSingleWitness(@PathVariable Integer witnessId) {
		Witness witness = witnessService.getSingleWitness(witnessId);
		return ResponseEntity.ok(witness);
	}

	@GetMapping
	@Operation(summary = "Get all witnesses", description = "Retrieve a list of all witnesses")
	public ResponseEntity<List<Witness>> getAllWitness() {
		List<Witness> witnesses = witnessService.getAllWitness();
		return ResponseEntity.ok(witnesses);
	}

	@PutMapping("/{witnessId}")
	@Operation(summary = "Update witness", description = "Update an existing witness by their ID")
	public ResponseEntity<Witness> updateWitness(@RequestBody Witness witness, @PathVariable Integer witnessId) {
		Witness updatedWitness = witnessService.updatedWitness(witness, witnessId);
		return ResponseEntity.ok(updatedWitness);
	}

	@DeleteMapping("/{witnessId}")
	@Operation(summary = "Delete witness", description = "Delete a witness by their ID")
	public ResponseEntity<ApiResponse> deleteWitness(@PathVariable Integer witnessId) {
		witnessService.deleteWitness(witnessId);
		return ResponseEntity.ok(new ApiResponse("Witness deleted successfully", true));
	}
}
