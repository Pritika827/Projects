package com.transline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transline.entities.DepotInspection;
import com.transline.service.DepotInspectionService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/api/depotInspection")
public class DepotInspectionController {

	@Autowired
	private DepotInspectionService service;

	@PostMapping
	@Operation(summary = "Create depot inspection", description = "Add a new depot inspection to the system")
	public ResponseEntity<DepotInspection> createdepotInspection(@RequestBody DepotInspection depotInspection) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.saveDepotInspection(depotInspection));
	}

	@GetMapping("{depotId}")
	@Operation(summary = "Get depot by ID", description = "Retrieve a depot inspection by their ID")
	public ResponseEntity<DepotInspection> getSingleDepotInspection(@PathVariable Integer depotId) {
		return ResponseEntity.ok(service.getDepotInspectionById(depotId));
	}

	@GetMapping
	@Operation(summary = "Get all depot inspection", description = "Retrieve a list of all depot inspection")
	public ResponseEntity<List<DepotInspection>> getAllDepotInspection() {
		return ResponseEntity.ok(service.getAllDepotInspection());
	}

	@PutMapping("/{depotId}")
	@Operation(summary = "Update depot inspection", description = "Update an existing depot inspection's details by their ID")
	public ResponseEntity<DepotInspection> updateDepotInspection(@RequestBody DepotInspection depotInspection,
			@PathVariable Integer depotId) {
		return ResponseEntity.ok(this.service.updateDepotInspection(depotInspection, depotId));
	}

	@DeleteMapping("/{depotId}")
	@Operation(summary = "Delete depot inspection", description = "Delete a depot inspection by their ID")
	public ResponseEntity<ApiResponse> deleteDepotInspection(@PathVariable Integer depotId) {
		this.service.deleteDepotInspection(depotId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("depot inspection deleted successfully", true),
				HttpStatus.OK);
	}

}
