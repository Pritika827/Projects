package com.transline.controller;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.transline.entities.Attachment;
import com.transline.service.AttachmentService;
import com.transline.utils.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/attachments")
@Tag(name = "Attachment Management", description = "Operations related to attachment management")
public class AttachmentController {

	@Autowired
	private AttachmentService attachmentService;

	@PostMapping
	@Operation(summary = "Create attachment", description = "Add a new attachment to the system")
	public ResponseEntity<Attachment> createAttachment(@RequestPart("attachment") String attachmentJson,
			@RequestPart("file") MultipartFile file) {

		ObjectMapper objectMapper = new ObjectMapper();
		try {
			// Convert JSON string to Attachment object
			Attachment attachment = objectMapper.readValue(attachmentJson, Attachment.class);

			// Save the attachment with the uploaded file
			Attachment savedAttachment = attachmentService.saveAttachmentWithFile(attachment, file);
			return new ResponseEntity<>(savedAttachment, HttpStatus.CREATED);
		} catch (IOException e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/{attachmentId}")
	@Operation(summary = "Get attachment by ID", description = "Retrieve an attachment by its ID")
	public ResponseEntity<Attachment> getAttachmentById(@PathVariable int attachmentId) {
		Optional<Attachment> attachment = Optional.ofNullable(attachmentService.getAttachmentById(attachmentId));
		return attachment.map(ResponseEntity::ok).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@GetMapping
	@Operation(summary = "Get all attachment", description = "Retrieve a list of all attachment")
	public ResponseEntity<Iterable<Attachment>> getAllAttachments() {
		Iterable<Attachment> attachments = attachmentService.getAllAttachments();
		return new ResponseEntity<>(attachments, HttpStatus.OK);
	}

	@PutMapping("/{attachmentId}")
	@Operation(summary = "Update attachment", description = "Update an existing attachment by its ID")
	public ResponseEntity<Attachment> updateAttachmentWithFile(@PathVariable int attachmentId,
			@RequestPart(value = "attachment", required = false) String attachmentJson,
			@RequestPart(value = "file", required = false) MultipartFile file) {

		ObjectMapper objectMapper = new ObjectMapper();
		try {
			// Convert JSON string to Attachment object
			Attachment attachment = objectMapper.readValue(attachmentJson, Attachment.class);

			// Update the attachment with the provided file
			Attachment updatedAttachment = attachmentService.updateAttachmentWithFile(attachmentId, attachment, file);
			return new ResponseEntity<>(updatedAttachment, HttpStatus.OK);
		} catch (IOException e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@DeleteMapping("/{attachmentId}")
	@Operation(summary = "Delete attachment", description = "Delete an attachment by its ID")
	public ResponseEntity<ApiResponse> deleteAttachment(@PathVariable int attachmentId) {
		attachmentService.deleteAttachmentById(attachmentId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Attachment deleted successfully", true), HttpStatus.OK);
	}

}
