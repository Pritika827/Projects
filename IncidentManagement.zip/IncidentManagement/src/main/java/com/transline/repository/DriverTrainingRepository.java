//package com.transline.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import com.transline.entities.DriverTraining;
//
//public interface DriverTrainingRepository extends JpaRepository<DriverTraining, Integer>{
//
//}
