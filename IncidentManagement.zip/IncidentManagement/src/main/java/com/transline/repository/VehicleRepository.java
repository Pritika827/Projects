package com.transline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transline.entities.VehicleMst;

public interface VehicleRepository extends JpaRepository<VehicleMst, Integer>{

}
