package com.transline.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transline.entities.Address;
import com.transline.entities.Incident;
import com.transline.entities.Staffs;
import com.transline.entities.VehicleMst;
import com.transline.utils.AccidentType;

public interface IncidentRespository extends JpaRepository<Incident, String> {

	List<Incident> findByVehicle(VehicleMst vehicleMst);

	List<Incident> findByStaff(Staffs driver);

	List<Incident> findByAddress(Address address);

	List<Incident> findByAccidentType(AccidentType accidentType);
}
