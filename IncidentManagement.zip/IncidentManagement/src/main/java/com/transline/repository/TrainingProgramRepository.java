package com.transline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transline.entities.TrainingProgram;
import com.transline.payloads.StaffTrainingDTO;

public interface TrainingProgramRepository extends JpaRepository<TrainingProgram, Integer> {

	StaffTrainingDTO save(StaffTrainingDTO driverTrainingDTO);

}
