package com.transline.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.transline.entities.AttachmentType;

@Repository
public interface AttachmentTypeRepository extends JpaRepository<AttachmentType, Integer>{

}
