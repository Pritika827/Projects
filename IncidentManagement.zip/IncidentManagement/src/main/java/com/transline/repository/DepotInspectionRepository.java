package com.transline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transline.entities.DepotInspection;

public interface DepotInspectionRepository extends JpaRepository<DepotInspection, Integer>{

}
