package com.transline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transline.entities.Staffs;

public interface StaffRepository extends JpaRepository<Staffs, Integer> {

}
