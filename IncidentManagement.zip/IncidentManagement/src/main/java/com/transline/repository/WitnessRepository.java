package com.transline.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transline.entities.Incident;
import com.transline.entities.Witness;

public interface WitnessRepository extends JpaRepository<Witness, Integer> {

	List<Witness> findByIncident(Incident incident);

}
