package com.transline.utils;

public enum AccidentType {
    INSIGNIFICANT,
    MINOR,
    MAJOR,
    FATAL
}