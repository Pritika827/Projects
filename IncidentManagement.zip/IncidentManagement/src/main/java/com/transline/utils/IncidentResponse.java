package com.transline.utils;

import java.util.List;

import com.transline.entities.Incident;

import lombok.Data;

@Data
public class IncidentResponse {

	private List<Incident> contents;
	private int pageNumber;
	private int pageSize;
	private long totalElements;
	private int totalPages;
	private boolean lastPage;

}
