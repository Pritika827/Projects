package com.transline.utils;

import java.lang.reflect.Field;

import com.tranline.annotatios.GeneratedIncidentId;

public class IncidentIdProcessor {

	public static void generateIncidentIdForObject(Object object) {
		Field[] fields = object.getClass().getDeclaredFields();

		for (Field field : fields) {
			if (field.isAnnotationPresent(GeneratedIncidentId.class)) {
				if (field.getType().equals(String.class)) {
					field.setAccessible(true);
					try {
						String incidentId = IncidentIdGenerator.generateIncidentId();
						field.set(object, incidentId);
					} catch (IllegalAccessException e) {
						throw new RuntimeException("Failed to set incident ID", e);
					}
				}
			}
		}
	}
}
