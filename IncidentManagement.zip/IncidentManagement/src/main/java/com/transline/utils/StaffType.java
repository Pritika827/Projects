package com.transline.utils;

public enum StaffType {
	DRIVER, CONDUCTOR
}