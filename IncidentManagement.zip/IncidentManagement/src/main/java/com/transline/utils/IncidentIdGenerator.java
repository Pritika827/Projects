package com.transline.utils;

import java.time.Year;
import java.util.concurrent.atomic.AtomicInteger;

//public class IncidentIdGenerator {
//
//	private static final AtomicInteger sequence = new AtomicInteger(1);
//	private static final String PREFIX = "DTC-";
//	private static final SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
//
//	public static String generateIncidentId() {
//		String year = yearFormat.format(new Date());
//		int sequenceNumber = sequence.getAndIncrement();
//		return String.format("%s%s-%05d", PREFIX, year, sequenceNumber);
//	}
//}



public class IncidentIdGenerator {

    private static final String PREFIX = "DTC";
    private static final AtomicInteger sequence = new AtomicInteger(0);

    public static String generateIncidentId() {
        int year = Year.now().getValue();
        int sequenceNumber = sequence.incrementAndGet();
        return String.format("%s%d%05d", PREFIX, year, sequenceNumber);
    }
}
