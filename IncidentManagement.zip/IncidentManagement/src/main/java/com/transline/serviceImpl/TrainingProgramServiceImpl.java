package com.transline.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.entities.TrainingProgram;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.TrainingProgramRepository;
import com.transline.service.TrainingProgramService;

@Service
public class TrainingProgramServiceImpl implements TrainingProgramService {

	@Autowired
	private TrainingProgramRepository trainingProgramRepository;

	@Override
	public TrainingProgram saveTrainingProgram(TrainingProgram trainingProgram) {
		return trainingProgramRepository.save(trainingProgram);
	}

	@Override
	public List<TrainingProgram> getAllTrainingProgramDetail() {
		return trainingProgramRepository.findAll();
	}

	@Override
	public TrainingProgram getSingleTrainingProgram(Integer programId) {
		return trainingProgramRepository.findById(programId).orElseThrow(() -> new ResourceNotFoundException(
				"Training Program with giver id not found on server!!" + programId));
	}

	@Override
	public TrainingProgram updateTrainingProgram(TrainingProgram trainingProgram, Integer programId) {
		TrainingProgram trainingProgram2 = this.trainingProgramRepository.findById(programId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"Training Program with given id is not found on server!!" + programId));
		trainingProgram2.setProgramName(trainingProgram2.getProgramName());
		trainingProgram2.setDescription(trainingProgram2.getDescription());
		trainingProgram2.setScheduledDate(trainingProgram.getScheduledDate());
		TrainingProgram updatedData = this.trainingProgramRepository.save(trainingProgram2);
		return updatedData;
	}

	@Override
	public void deleteTrainingProgram(Integer programId) {
		TrainingProgram trainingProgram = this.trainingProgramRepository.findById(programId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"Training Program with giver id not found on server!!" + programId));
		this.trainingProgramRepository.delete(trainingProgram);

	}

}
