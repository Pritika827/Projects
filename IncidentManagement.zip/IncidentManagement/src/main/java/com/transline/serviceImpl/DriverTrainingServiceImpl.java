package com.transline.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.entities.Staffs;
import com.transline.entities.TrainingProgram;
import com.transline.repository.StaffRepository;
import com.transline.repository.TrainingProgramRepository;
import com.transline.service.DriverTrainingService;

@Service
public class DriverTrainingServiceImpl implements DriverTrainingService {

	@Autowired
	private StaffRepository staffRepository;

	@Autowired
	private TrainingProgramRepository trainingProgramRepository;

	@Override
	public void addStaffToTrainingProgram(Integer staffId, Integer programId) {

		Optional<Staffs> staffOptional=staffRepository.findById(staffId);
		Optional<TrainingProgram> trainingProgramOptional=trainingProgramRepository.findById(programId);
		if(staffOptional.isPresent() && trainingProgramOptional.isPresent()) {
			Staffs staff=staffOptional.get();
		TrainingProgram trainingProgram=trainingProgramOptional.get();
		
		staff.getTrainings().add(trainingProgram);
		trainingProgram.getStaff().add(staff);
		
		staffRepository.save(staff);
		trainingProgramRepository.save(trainingProgram);
		
		}
				
		
//		Optional<Student> studentOptional = studentRepository.findById(studentId);
//        Optional<Course> courseOptional = courseRepository.findById(courseId);
//
//        if (studentOptional.isPresent() && courseOptional.isPresent()) {
//            Student student = studentOptional.get();
//            Course course = courseOptional.get();
//
//            student.getCourses().add(course);
//            course.getStudents().add(student);
//
//            studentRepository.save(student);
//            courseRepository.save(course);
//        }

	}

	

//	@Override
//	public DriverTraining createDriverTraining(DriverTrainingDTO driverTrainingDTO, Integer driverId,
//			Integer programId) {
//		Driver driver=this.driverRepository.findById(driverId).orElseThrow(
//				() -> new ResourceNotFoundException("Driver", "driver id", driverId));
//		TrainingProgram trainingProgram=this.trainingProgramRepository.findById(programId).orElseThrow(
//				() -> new ResourceNotFoundException("Training Program", "program id", programId));
//		java.util.Date utilPackageDate = new java.util.Date();
//		java.sql.Date sqlPackageDate = new java.sql.Date(utilPackageDate.getTime());
//		
//		DriverTraining driverTraining=new DriverTraining();
//		
//		driverTraining.setRemarks(driverTrainingDTO.getRemarks());
//		driverTraining.setDriver(driver);
//		driverTraining.setProgram(trainingProgram);
//		driverTraining.setTrainingDate(sqlPackageDate);
//		
//		DriverTraining record=this.driverTrainingRepository.save(driverTraining);
//		record.setTrainingId(driverTraining.getTrainingId());
//		record.setRemarks(driverTraining.getRemarks());
//		record.setDriver(driverTraining.getDriver());
//		record.setProgram(driverTraining.getProgram());
//		
//		return record;
//	}

}
