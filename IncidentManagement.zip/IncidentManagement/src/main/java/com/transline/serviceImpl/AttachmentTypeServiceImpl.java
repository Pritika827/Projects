package com.transline.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.entities.AttachmentType;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.AttachmentTypeRepository;
import com.transline.service.AttachmentTypeService;

@Service
public class AttachmentTypeServiceImpl implements AttachmentTypeService {

	@Autowired
	private AttachmentTypeRepository repository;

	@Override
	public AttachmentType saveAttachmentType(AttachmentType attachmentType) {
		return repository.save(attachmentType);
	}

	@Override
	public List<AttachmentType> getAllAttachmentTypes() {
		return repository.findAll();
	}

	@Override
	public AttachmentType getAttachmentTypeById(Integer attachmentId) {
		return repository.findById(attachmentId).orElseThrow(
				() -> new ResourceNotFoundException("attachment with giver id not found on server!!" + attachmentId));
	}

	@Override
	public AttachmentType updaAttachmentType(AttachmentType attachmentType, Integer attachmentId) {
		AttachmentType attachment = this.repository.findById(attachmentId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"attachment with given id is not found on server!!" + attachmentId));
		attachment.setAttachmentName(attachmentType.getAttachmentName());
		AttachmentType updated = this.repository.save(attachment);
		return updated;
	}

	@Override
	public void deleteAttachement(Integer attachmentId) {
		AttachmentType attachment = this.repository.findById(attachmentId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"attachment with given id is not found on server!!" + attachmentId));
		this.repository.delete(attachment);
	}

}
