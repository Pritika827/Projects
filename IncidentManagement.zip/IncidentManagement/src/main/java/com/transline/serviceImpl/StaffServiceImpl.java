package com.transline.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.entities.Staffs;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.StaffRepository;
import com.transline.service.StaffService;


@Service
public class StaffServiceImpl implements StaffService {

	@Autowired
	private StaffRepository staffrepository;

	@Override
	public Staffs saveStaff(Staffs staff) {
		//System.out.println("serviceImpl running ");
		return staffrepository.save(staff);
	}

	@Override
	public List<Staffs> getAllStaffDetails() {
		return staffrepository.findAll();
	}

	@Override
	public Staffs getStaff(Integer staffId) {
		return staffrepository.findById(staffId).orElseThrow(
				() -> new ResourceNotFoundException("Driver with giver id not found on server!!" + staffId));
	}

	@Override
	public Staffs updateStaff(Staffs staff, Integer staffId) {
		Staffs staff2 = this.staffrepository.findById(staffId).orElseThrow(
				() -> new ResourceNotFoundException("driver with given id is not found on server!!" + staffId));
		staff2.setName(staff.getName());
		staff2.setLicenseNumber(staff.getLicenseNumber());
		staff2.setVehicleNo(staff.getVehicleNo());
		staff2.setAge(staff.getAge());
		staff2.setBloodGroup(staff.getBloodGroup());
		Staffs updatedStaffs = this.staffrepository.save(staff2);
		return updatedStaffs;
	}

	@Override
	public void deleteStaff(Integer staffId) {
		Staffs staff = this.staffrepository.findById(staffId).orElseThrow(
				() -> new ResourceNotFoundException("driver with given id is not found on server!!" + staffId));
		this.staffrepository.delete(staff);
	}

}
