package com.transline.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.transline.entities.Address;
import com.transline.entities.Incident;
import com.transline.entities.Staffs;
import com.transline.entities.VehicleMst;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.AddressRepository;
import com.transline.repository.IncidentRespository;
import com.transline.repository.StaffRepository;
import com.transline.repository.VehicleRepository;
import com.transline.service.IncidentService;
import com.transline.utils.AccidentType;
import com.transline.utils.IncidentResponse;

@Service
public class IncidentServiceImpl implements IncidentService {

	@Autowired
	private IncidentRespository incidentRespository;

	@Autowired
	private VehicleRepository vehicleRepository;

	@Autowired
	private StaffRepository staffRepository;

	@Autowired
	private AddressRepository locationRepository;

	@Override
	public Incident createIncident(Incident incident, Integer vehicleId, Integer staffId, Integer addressId) {
		VehicleMst vehicleMst = this.vehicleRepository.findById(vehicleId)
				.orElseThrow(() -> new ResourceNotFoundException("VehicleMst", "Vehicle id", vehicleId));

		Staffs staff = this.staffRepository.findById(staffId)
				.orElseThrow(() -> new ResourceNotFoundException("staff", "staff id", staffId));

		Address address = this.locationRepository.findById(addressId)
				.orElseThrow(() -> new ResourceNotFoundException("Address", "address id", addressId));

		Incident incident2 = new Incident();
		incident2.setVehicle(vehicleMst);
		incident2.setStaff(staff);
		incident2.setAddress(address);
		incident2.setIncidentDateTime(incident.getIncidentDateTime());
		incident2.setDescription(incident.getDescription());
		incident2.setSeverity(incident.getSeverity());
		incident2.setStatus(incident.getStatus());
		incident2.setAccidentType(incident.getAccidentType());

		Incident record = this.incidentRespository.save(incident2);
		record.setVehicle(incident2.getVehicle());
		record.setStaff(incident2.getStaff());
		record.setAddress(incident2.getAddress());
		record.setIncidentDateTime(incident2.getIncidentDateTime());
		record.setDescription(incident2.getDescription());
		record.setSeverity(incident2.getSeverity());
		record.setStatus(incident2.getStatus());
		record.setAccidentType(incident2.getAccidentType());
		return record;
	}

//	@Override
//	public staffTraining createstaffTraining(staffTrainingDTO staffTrainingDTO, Integer staffId,
//			Integer programId) {
//		staff staff=this.staffRepository.findById(staffId).orElseThrow(
//				() -> new ResourceNotFoundException("staff", "staff id", staffId));
//		TrainingProgram trainingProgram=this.trainingProgramRepository.findById(programId).orElseThrow(
//				() -> new ResourceNotFoundException("Training Program", "program id", programId));
//		java.util.Date utilPackageDate = new java.util.Date();
//		java.sql.Date sqlPackageDate = new java.sql.Date(utilPackageDate.getTime());
//		staffTraining staffTraining=new staffTraining();	

//		staffTraining.setRemarks(staffTrainingDTO.getRemarks());
//		staffTraining.setstaff(staff);
//		staffTraining.setProgram(trainingProgram);
//		staffTraining.setTrainingDate(sqlPackageDate);

//		staffTraining record=this.staffTrainingRepository.save(staffTraining);
//		record.setTrainingId(staffTraining.getTrainingId());
//		record.setRemarks(staffTraining.getRemarks());
//		record.setstaff(staffTraining.getstaff());
//		record.setProgram(staffTraining.getProgram());
//		
//		return record;
//	
	@Override
	public Incident updateIncident(Incident incident, String incidentId) {
		Incident incident2 = this.incidentRespository.findById(incidentId)
				.orElseThrow(() -> new ResourceNotFoundException("Incident", " incident id", incidentId));

		incident2.setIncidentDateTime(incident.getIncidentDateTime());
		incident2.setDescription(incident.getDescription());
		incident2.setSeverity(incident.getSeverity());
		incident2.setStatus(incident.getStatus());
		incident2.setAccidentType(incident.getAccidentType());

		Incident updatedIncident = this.incidentRespository.save(incident2);
		updatedIncident.setIncidentDateTime(updatedIncident.getIncidentDateTime());
		updatedIncident.setDescription(updatedIncident.getDescription());
		updatedIncident.setSeverity(updatedIncident.getSeverity());
		updatedIncident.setStatus(updatedIncident.getStatus());
		updatedIncident.setAccidentType(updatedIncident.getAccidentType());

		return updatedIncident;
	}

	@Override
	public void deleteIncident(String incidentId) {
		Incident incident = this.incidentRespository.findById(incidentId)
				.orElseThrow(() -> new ResourceNotFoundException("Incident", "incident id", incidentId));
		this.incidentRespository.delete(incident);
	}

	@Override
	public Incident getSingleIncident(String incidentId) {
		return incidentRespository.findById(incidentId)
				.orElseThrow(() -> new ResourceNotFoundException("Incident", "incident id", incidentId));
	}

	@Override
	public IncidentResponse getAllIncident(Integer pageNumber, Integer pageSize, String sortBy, String sortDir) {

		Sort sort = (sortDir.equalsIgnoreCase("asc")) ? sort = Sort.by(sortBy).ascending()
				: Sort.by(sortBy).descending();

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<Incident> pageIncident = this.incidentRespository.findAll(pageable);
		List<Incident> allIncident = pageIncident.getContent();

		List<Incident> incidents = allIncident.stream().map(incident -> {
			Incident list = new Incident();
			list.setIncidentId(incident.getIncidentId());
			list.setVehicle(incident.getVehicle());
			list.setStaff(incident.getStaff());
			list.setAddress(incident.getAddress());
			list.setIncidentDateTime(incident.getIncidentDateTime());
			list.setDescription(incident.getDescription());
			list.setSeverity(incident.getSeverity());
			list.setStatus(incident.getStatus());
			list.setAccidentType(incident.getAccidentType());
			list.setCreatedAt(incident.getCreatedAt());
			list.setCreatedBy(incident.getCreatedBy());
			list.setLastModifiedAt(incident.getLastModifiedAt());
			list.setLastModifiedBy(incident.getLastModifiedBy());
			return list;
		}).collect(Collectors.toList());

		IncidentResponse incidentResponse = new IncidentResponse();
		incidentResponse.setContents(incidents);
		incidentResponse.setPageNumber(pageIncident.getNumber());
		incidentResponse.setPageSize(pageIncident.getSize());
		incidentResponse.setTotalElements(pageIncident.getTotalElements());
		incidentResponse.setTotalPages(pageIncident.getTotalPages());
		incidentResponse.setLastPage(pageIncident.isLast());

		return incidentResponse;
	}

	@Override
	public List<Incident> getIncidentsByVehicle(Integer vehicleId) {
		VehicleMst vehicleMst = this.vehicleRepository.findById(vehicleId)
				.orElseThrow(() -> new ResourceNotFoundException("VehicleMst", "Vehicle id", vehicleId));
		List<Incident> incidents = this.incidentRespository.findByVehicle(vehicleMst);

		List<Incident> allincident = incidents.stream().map(incident -> {
			Incident list = new Incident();
			list.setIncidentId(incident.getIncidentId());
			list.setVehicle(incident.getVehicle());
			list.setStaff(incident.getStaff());
			list.setAddress(incident.getAddress());
			list.setIncidentDateTime(incident.getIncidentDateTime());
			list.setDescription(incident.getDescription());
			list.setSeverity(incident.getSeverity());
			list.setStatus(incident.getStatus());
			list.setAccidentType(incident.getAccidentType());
			list.setCreatedAt(incident.getCreatedAt());
			list.setCreatedBy(incident.getCreatedBy());
			list.setLastModifiedAt(incident.getLastModifiedAt());
			list.setLastModifiedBy(incident.getLastModifiedBy());
			return list;
		}).collect(Collectors.toList());

		return allincident;

	}

	@Override
	public List<Incident> getIncidentsByStaff(Integer staffId) {
		Staffs staff = this.staffRepository.findById(staffId)
				.orElseThrow(() -> new ResourceNotFoundException("staff", "staff id", staffId));

		List<Incident> incidents = this.incidentRespository.findByStaff(staff);

		List<Incident> allincident = incidents.stream().map(incident -> {
			Incident list = new Incident();
			list.setIncidentId(incident.getIncidentId());
			list.setVehicle(incident.getVehicle());
			list.setStaff(incident.getStaff());
			list.setAddress(incident.getAddress());
			list.setIncidentDateTime(incident.getIncidentDateTime());
			list.setDescription(incident.getDescription());
			list.setSeverity(incident.getSeverity());
			list.setStatus(incident.getStatus());
			list.setAccidentType(incident.getAccidentType());
			list.setCreatedAt(incident.getCreatedAt());
			list.setCreatedBy(incident.getCreatedBy());
			list.setLastModifiedAt(incident.getLastModifiedAt());
			list.setLastModifiedBy(incident.getLastModifiedBy());
			return list;
		}).collect(Collectors.toList());

		return allincident;

	}

	@Override
	public List<Incident> getIncidentsByLocation(Integer addressId) {
		Address address = this.locationRepository.findById(addressId)
				.orElseThrow(() -> new ResourceNotFoundException("Address", "address id", addressId));

		List<Incident> incidents = this.incidentRespository.findByAddress(address);

		List<Incident> allincident = incidents.stream().map(incident -> {
			Incident list = new Incident();
			list.setIncidentId(incident.getIncidentId());
			list.setVehicle(incident.getVehicle());
			list.setStaff(incident.getStaff());
			list.setAddress(incident.getAddress());
			list.setIncidentDateTime(incident.getIncidentDateTime());
			list.setDescription(incident.getDescription());
			list.setSeverity(incident.getSeverity());
			list.setStatus(incident.getStatus());
			list.setAccidentType(incident.getAccidentType());
			list.setCreatedAt(incident.getCreatedAt());
			list.setCreatedBy(incident.getCreatedBy());
			list.setLastModifiedAt(incident.getLastModifiedAt());
			list.setLastModifiedBy(incident.getLastModifiedBy());
			return list;
		}).collect(Collectors.toList());

		return allincident;

	}

	public List<Incident> searchAccidentType(AccidentType keyword) {
		List<Incident> incidents = this.incidentRespository.findByAccidentType(keyword);

		List<Incident> allincident = incidents.stream().map(incident -> {
			Incident list = new Incident();
			list.setIncidentId(incident.getIncidentId());
			list.setVehicle(incident.getVehicle());
			list.setStaff(incident.getStaff());
			list.setAddress(incident.getAddress());
			list.setIncidentDateTime(incident.getIncidentDateTime());
			list.setDescription(incident.getDescription());
			list.setSeverity(incident.getSeverity());
			list.setStatus(incident.getStatus());
			list.setAccidentType(incident.getAccidentType());
			list.setCreatedAt(incident.getCreatedAt());
			list.setCreatedBy(incident.getCreatedBy());
			list.setLastModifiedAt(incident.getLastModifiedAt());
			list.setLastModifiedBy(incident.getLastModifiedBy());
			return list;
		}).collect(Collectors.toList());

		return allincident;
	}

}
