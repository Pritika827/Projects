package com.transline.serviceImpl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.transline.entities.Attachment;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.AttachmentRepository;
import com.transline.service.AttachmentService;
import com.transline.utils.ShortUniqueIdGenerator;

@Service
public class AttachmentServiceImpl implements AttachmentService {

	private static final String UPLOAD_DIR = "uploads/";

	@Autowired
	private AttachmentRepository attachmentRepository;

//	@Override
//	public Attachment saveAttachment(Attachment attachment) {
//		return attachmentRepository.save(attachment);
//	}

	@Override
	public Attachment getAttachmentById(int attachmentId) {
		return attachmentRepository.findById(attachmentId).orElseThrow(
				() -> new ResourceNotFoundException("attachment with giver id not found on server!!" + attachmentId));
	}

	@Override
	public Iterable<Attachment> getAllAttachments() {
		return attachmentRepository.findAll();
	}

	@Override
	public void deleteAttachmentById(int attachmentId) {
		Attachment attachment = this.attachmentRepository.findById(attachmentId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"attachment with given id is not found on server!!" + attachmentId));
		this.attachmentRepository.deleteById(attachmentId);
	}

	@Override
	public Attachment updateAttachmentWithFile(int attachmentId, Attachment attachment, MultipartFile file) {
		// Find existing attachment
		Attachment existingAttachment = attachmentRepository.findById(attachmentId).orElseThrow(
				() -> new ResourceNotFoundException("Attachment with given id not found on server: " + attachmentId));

		// Update fields from the input attachment object
		existingAttachment.setAttachmentType(attachment.getAttachmentType());
		existingAttachment.setRef_id(attachment.getRef_id());
		existingAttachment.setFileDescription(attachment.getFileDescription());
		existingAttachment.setFileSize(attachment.getFileSize());

		// Handle file upload if a new file is provided
		if (file != null && !file.isEmpty()) {
			try {
				String uniqueFilename = ShortUniqueIdGenerator.generateShortUniqueId()
						+ getFileExtension(file.getOriginalFilename());
				Path filePath = Paths.get(UPLOAD_DIR + uniqueFilename);

				Files.createDirectories(filePath.getParent());
				Files.write(filePath, file.getBytes());

				// Update attachment with new file details
				existingAttachment.setFilePath(filePath.toString());
				existingAttachment.setFileSize(String.valueOf(file.getSize()));
				existingAttachment.setFileDescription(file.getOriginalFilename());
			} catch (IOException e) {
				throw new RuntimeException("Failed to store file", e);
			}
		}

		return attachmentRepository.save(existingAttachment);
	}

	@Override
	public Attachment saveAttachmentWithFile(Attachment attachment, MultipartFile file) {
		if (file != null && !file.isEmpty()) {
			try {
				// Generate a unique file name using ShortUniqueIdGenerator
				String shortUniqueId = ShortUniqueIdGenerator.generateShortUniqueId();
				String fileExtension = getFileExtension(file.getOriginalFilename());
				String fileName = shortUniqueId + fileExtension;

				Path filePath = Paths.get(UPLOAD_DIR + fileName);

				// Create directories if not exist
				Files.createDirectories(filePath.getParent());

				// Save file to filesystem
				Files.write(filePath, file.getBytes());

				// Update attachment details
				attachment.setFilePath(filePath.toString());
				attachment.setFileSize(String.valueOf(file.getSize()));
				attachment.setFileDescription("Uploaded file: " + file.getOriginalFilename());

			} catch (IOException e) {
				throw new RuntimeException("Failed to store file", e);
			}
		}
		return attachmentRepository.save(attachment);
	}

	private String getFileExtension(String filename) {
		int dotIndex = filename.lastIndexOf(".");
		return dotIndex >= 0 ? filename.substring(dotIndex) : "";
	}
}
