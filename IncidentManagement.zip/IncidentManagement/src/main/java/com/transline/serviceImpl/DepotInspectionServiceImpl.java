package com.transline.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.entities.DepotInspection;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.DepotInspectionRepository;
import com.transline.service.DepotInspectionService;

@Service
public class DepotInspectionServiceImpl implements DepotInspectionService {

	@Autowired
	private DepotInspectionRepository repository;

	@Override
	public DepotInspection saveDepotInspection(DepotInspection depotInspection) {
		return repository.save(depotInspection);
	}

	@Override
	public List<DepotInspection> getAllDepotInspection() {
		return repository.findAll();
	}

	@Override
	public DepotInspection getDepotInspectionById(Integer depotId) {
		return repository.findById(depotId).orElseThrow(
				() -> new ResourceNotFoundException("Depot inspection with giver id not found on server!!" + depotId));

	}

	@Override
	public DepotInspection updateDepotInspection(DepotInspection depotInspection, Integer depotId) {
		DepotInspection inspection = this.repository.findById(depotId).orElseThrow(
				() -> new ResourceNotFoundException("Depot inspection with giver id not found on server!!" + depotId));
		inspection.setDepot(depotInspection.getDepot());
		inspection.setCrewCounsel(depotInspection.getCrewCounsel());
		inspection.setPoliceCounsel(depotInspection.getPoliceCounsel());
		inspection.setDriverProfile(depotInspection.getDriverProfile());
		inspection.setGpsStatus(depotInspection.getGpsStatus());
		inspection.setAudioWorks(depotInspection.getAudioWorks());
		inspection.setVideoWorks(depotInspection.getVideoWorks());
		inspection.setBannerDisplayed(depotInspection.getBannerDisplayed());
		inspection.setDrivingCheck(depotInspection.getDrivingCheck());
		inspection.setRecordMaintained(depotInspection.getRecordMaintained());
		DepotInspection updatedRecord = this.repository.save(inspection);
		return updatedRecord;

	}

	@Override
	public void deleteDepotInspection(Integer depotId) {
		DepotInspection depotInspection = this.repository.findById(depotId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"Depot inspection  with given id is not found on server!!" + depotId));
		this.repository.delete(depotInspection);
	}

}
