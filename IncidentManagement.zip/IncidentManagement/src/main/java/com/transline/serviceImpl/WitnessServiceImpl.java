package com.transline.serviceImpl;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.entities.Address;
import com.transline.entities.Incident;
import com.transline.entities.Witness;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.AddressRepository;
import com.transline.repository.IncidentRespository;
import com.transline.repository.WitnessRepository;
import com.transline.service.WitnessService;

@Service
public class WitnessServiceImpl implements WitnessService {

	@Autowired
	private WitnessRepository witnessRepository;

	@Autowired
	private IncidentRespository incidentRespository;

	@Autowired
	private AddressRepository locationRepository;

	@Override
	public Witness saveWitness(Witness witness, String incidentId, Integer addressId) {

		Incident incident = this.incidentRespository.findById(incidentId)
				.orElseThrow(() -> new ResourceNotFoundException("Incident", " incident id", incidentId));

		Address address = this.locationRepository.findById(addressId)
				.orElseThrow(() -> new ResourceNotFoundException("Address", "address id", addressId));

		Witness witness2 = new Witness();
		witness2.setName(witness.getName());
		witness2.setAge(witness.getAge());
		witness2.setBloodGroup(witness.getBloodGroup());
		witness2.setAddress(address);
		witness2.setStatement(witness.getStatement());
		witness2.setIdProof(witness.getStatement());
		witness2.setIncident(incident);

		Witness record = this.witnessRepository.save(witness2);
		record.setName(witness2.getName());
		record.setAge(witness2.getAge());
		record.setBloodGroup(witness2.getBloodGroup());
		record.setAddress(witness2.getAddress());
		record.setStatement(witness2.getStatement());
		record.setIdProof(witness2.getIdProof());
		record.setIncident(incident);

		return record;
	}

	@Override
	public List<Witness> getAllWitness() {
		return witnessRepository.findAll();
	}

	@Override
	public Witness getSingleWitness(Integer witnessId) {
		return witnessRepository.findById(witnessId).orElseThrow(
				() -> new ResourceNotFoundException("Witness with giver id not found on server!!" + witnessId));
	}

	@Override
	public Witness updatedWitness(Witness witness, Integer witnessId) {
		Witness witness2 = this.witnessRepository.findById(witnessId).orElseThrow(
				() -> new ResourceNotFoundException("Witness with giver id not found on server!!" + witnessId));
	//	witness2.setAddress(witness.getAddress());
		witness2.setAge(witness.getAge());
		witness2.setBloodGroup(witness.getBloodGroup());
		witness2.setIdProof(witness.getIdProof());
		witness2.setName(witness.getName());
		witness2.setStatement(witness.getStatement());
		Witness updatedWitness = this.witnessRepository.save(witness2);
		return updatedWitness;
	}

	@Override
	public void deleteWitness(Integer witnessId) {
		Witness witness = this.witnessRepository.findById(witnessId).orElseThrow(
				() -> new ResourceNotFoundException("Witness with giver id not found on server!!" + witnessId));
		this.witnessRepository.delete(witness);
	}

	@Override
	public List<Witness> getWitnessByIncident(String incidentId) {
		Incident incident = this.incidentRespository.findById(incidentId)
				.orElseThrow(() -> new ResourceNotFoundException("Incident", " incident id", incidentId));

		List<Witness> witnesses=this.witnessRepository.findByIncident(incident);
		List<Witness> allWitness=witnesses.stream().map(
				witness->{
					Witness list=new Witness();
					list.setName(witness.getName());
					list.setAge(witness.getAge());
					list.setBloodGroup(witness.getBloodGroup());
					list.setAddress(witness.getAddress());
					list.setStatement(witness.getStatement());
					list.setIdProof(witness.getIdProof());
					list.setIncident(witness.getIncident());
					return list;
				}).collect(Collectors.toList());
		return allWitness;
	}
	/*@Override
	public List<Incident> getIncidentsByLocation(Integer addressId) {
		Address address = this.locationRepository.findById(addressId)
				.orElseThrow(() -> new ResourceNotFoundException("Address", "address id", addressId));

		List<Incident> incidents = this.incidentRespository.findByAddress(address);

		List<Incident> allincident = incidents.stream().map(incident -> {
			Incident list = new Incident();
			list.setIncidentId(incident.getIncidentId());
			list.setVehicle(incident.getVehicle());
			list.setDriver(incident.getDriver());
			list.setAddress(incident.getAddress());
			list.setIncidentDateTime(incident.getIncidentDateTime());
			list.setDescription(incident.getDescription());
			list.setSeverity(incident.getSeverity());
			list.setStatus(incident.getStatus());
			list.setAccidentType(incident.getAccidentType());
			list.setCreatedAt(incident.getCreatedAt());
			list.setCreatedBy(incident.getCreatedBy());
			list.setLastModifiedAt(incident.getLastModifiedAt());
			list.setLastModifiedBy(incident.getLastModifiedBy());
			return list;
		}).collect(Collectors.toList());

		return allincident;

	}*/

}
