package com.transline.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.entities.Address;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.AddressRepository;
import com.transline.service.AddressService;

@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	private AddressRepository addressRepository;

	@Override
	public Address saveAddress(Address address) {
		return addressRepository.save(address);
	}

	@Override
	public List<Address> getAllAddress() {
		return addressRepository.findAll();
	}

	@Override
	public Address getSingleAddress(Integer addressId) {
		return addressRepository.findById(addressId).orElseThrow(
				() -> new ResourceNotFoundException("address with giver id not found on server!!" + addressId));
	}

	@Override
	public Address updateAddress(Address address, Integer addressId) {
		Address address2 = this.addressRepository.findById(addressId).orElseThrow(
				() -> new ResourceNotFoundException("address with giver id not found on server!!" + addressId));
		address2.setCity(address.getCity());
		address2.setCountry(address.getCountry());
		address2.setLine1(address.getLine1());
		address2.setLine2(address.getLine2());
		address2.setState(address.getState());
		address2.setZipCode(address.getZipCode());
		Address updatedaddress = this.addressRepository.save(address2);
		return updatedaddress;
	}

	@Override
	public void deleteAddress(Integer addressId) {
		Address address = this.addressRepository.findById(addressId).orElseThrow(
				() -> new ResourceNotFoundException("address with giver id not found on server!!" + addressId));
		addressRepository.delete(address);
	}

}
