package com.transline.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transline.entities.VehicleMst;
import com.transline.exceptions.ResourceNotFoundException;
import com.transline.repository.VehicleRepository;
import com.transline.service.VehicleService;

@Service
public class VehicleServiceImpl implements VehicleService {

	@Autowired
	private VehicleRepository vehicleRepository;

	@Override
	public VehicleMst saveVehicle(VehicleMst vehicleMst) {
		return vehicleRepository.save(vehicleMst);
	}

	@Override
	public List<VehicleMst> getAllVehicle() {
		return vehicleRepository.findAll();
	}

	@Override
	public VehicleMst getSingleVehicle(Integer vehicleId) {
		return vehicleRepository.findById(vehicleId).orElseThrow(
				() -> new ResourceNotFoundException("Vehicle with giver id not found on server!!" + vehicleId));
	}

	@Override
	public VehicleMst updateVehicle(VehicleMst vehicleMst, Integer vehicleId) {
		VehicleMst vehicleMst2 = this.vehicleRepository.findById(vehicleId).orElseThrow(
				() -> new ResourceNotFoundException("Vehicle with giver id not found on server!!" + vehicleId));
		vehicleMst2.setVehicleModel(vehicleMst.getVehicleModel());
		vehicleMst2.setVehicleNo(vehicleMst.getVehicleNo());
		vehicleMst2.setVehicleOwner(vehicleMst.getVehicleOwner());
		VehicleMst updatedVehicle = this.vehicleRepository.save(vehicleMst2);
		return updatedVehicle;
	}

	@Override
	public void deleteVehicle(Integer vehicleId) {
		VehicleMst vehicleMst = this.vehicleRepository.findById(vehicleId).orElseThrow(
				() -> new ResourceNotFoundException("Vehicle with giver id not found on server!!" + vehicleId));
		this.vehicleRepository.delete(vehicleMst);
	}
}
