package com.transline.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transline.entities.Witness;

public interface WitnessRepository extends JpaRepository<Witness, Integer>{

}
