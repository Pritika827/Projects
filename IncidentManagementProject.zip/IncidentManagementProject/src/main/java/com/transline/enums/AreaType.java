package com.transline.enums;

public enum AreaType {
	URBAN, RURAL
}
