package com.transline.enums;

public enum Zone {
	NORTH, EAST, WEST, SOUTH
}
