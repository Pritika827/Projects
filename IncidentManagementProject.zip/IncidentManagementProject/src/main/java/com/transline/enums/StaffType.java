package com.transline.enums;

public enum StaffType {
	DRIVER, CONDUCTOR
}
