package com.transline.enums;

public enum Region {
	DELHI, NCR
}