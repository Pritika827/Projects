package com.transline.enums;

public enum AccidentType {
    INSIGNIFICANT,
    MINOR,
    MAJOR,
    FATAL
}