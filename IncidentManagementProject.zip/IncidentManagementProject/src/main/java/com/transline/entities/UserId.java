package com.transline.entities;

import java.io.Serializable;

public class UserId implements Serializable{
	private String cmpCd;
	private String userId;
}
