package com.transline.entities;

import java.io.Serializable;

public class UserEmail implements Serializable{
	private String cmpCd;
	private String email;
}
